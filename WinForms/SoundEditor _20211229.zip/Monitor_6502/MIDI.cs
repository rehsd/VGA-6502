﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PureMidi.CoreMmSystem.MidiIO;
using PureMidi.CoreMmSystem.MidiIO.Data;
using PureMidi.CoreMmSystem.MidiIO.Definitions;
using PureMidi.CoreMmSystem.MidiIO.DeviceInfo;

namespace Monitor_6502
{
    public partial class MIDI : Form
    {
        bool currentlyMonitoring = false;
        private InputDevice currentInputDevice;
        private OutputDevice currentOutptDevice;
        //static private NumericUpDown nudLcourse;
        //static private NumericUpDown nudLfine;
        //static private NumericUpDown nudRcourse;
        //static private NumericUpDown nudRfine;
        //static private Button btnAddToSequence;
        static private int currentTonePeriod;
        static private SoundForm parentFrm;
        static DateTime timeStart;

        public MIDI(SoundForm myParent)
        {
            InitializeComponent();
            parentFrm =myParent;
        }

        //public MIDI(NumericUpDown Lcourse, NumericUpDown Lfine, NumericUpDown Rcourse, NumericUpDown Rfine, Button addButton )
        //{
        //    InitializeComponent();
        //    nudLcourse = Lcourse;
        //    nudLfine = Lfine;
        //    nudRcourse = Rcourse;
        //    nudRfine = Rfine;
        //    btnAddToSequence = addButton;
        //}

        private void openButton_Click(object sender, EventArgs e)
        {
            if (!currentlyMonitoring)
            {
                if (inputDevicesComboBox.SelectedIndex > 0 && outputDevicesComboBox.SelectedIndex > 0)
                {
                    //start monitoring
                    eventsListBox.Items.Clear();
                    currentInputDevice = new InputDevice(inputDevicesComboBox.SelectedIndex - 1);
                    currentInputDevice.OnMidiEvent += OnMidiEventHandle;
                    currentInputDevice.Start();

                    if (outputDevicesComboBox.SelectedIndex > 0)
                    {
                        currentOutptDevice = new OutputDevice(outputDevicesComboBox.SelectedIndex - 1);
                    }
                    openButton.Text = "&Close";
                    currentlyMonitoring = true;
                }
                else
                {
                    MessageBox.Show("You must choose an input and output device.");
                }

            }
            else
            {
                //stop monitoring
                currentInputDevice.Dispose();
                currentOutptDevice.Dispose();
                openButton.Text = "&Open";
            }
        }
        private void OnMidiEventHandle(MidiEvent ev)
        {
            if (ev.MidiEventType == EMidiEventType.Short)
            {
                currentOutptDevice.Send(ev);
                SafeSetText(eventsListBox, GetShortMessageDescription(ev));
            }
        }

        private static int GetMaxVisibleItems(ListBox lb)
        {
            return lb.Size.Height / lb.ItemHeight;
        }

        private delegate void SetTextCallback(ListBox tb, string text);

        private void SafeSetText(ListBox lb, string text)
        {
            if (lb.InvokeRequired)
            {
                var d = new SetTextCallback(SafeSetText);
                Invoke(d, new object[] { lb, text });

            }
            else
            {
                if (lb.Items.Count == GetMaxVisibleItems(lb))
                {
                    lb.Items.RemoveAt(lb.Items.Count - 1);
                }
                lb.Items.Insert(0, text);
            }
        }

        private delegate void AddMIDINoteToSequence(int tone, int duration);

        static private void SafeAddToneToSequence(int tone, int duration)
        {
            var d = new AddMIDINoteToSequence(parentFrm.SafeAddMIDINoteToSequence);
            parentFrm.Invoke(d, new object[] { tone, duration });
        }

        private static string GetShortMessageDescription(MidiEvent ev)
        {
            string retVal;
            var shortType = ev.Status & 0xF0;
            switch (shortType)
            {
                case 0x80:
                    retVal = "Stop " + GetKeyName(ev.AllData[1]);   // + " Velo=" + ev.AllData[2];
                    int iTest = (int)DateTime.Now.Subtract(timeStart).TotalMilliseconds / 20;
                    int iHold=0;
                    if (iTest < 256)
                    {
                        iHold = iTest;
                    }
                    else
                    {
                        iHold = 255;
                    }
                    SafeAddToneToSequence(currentTonePeriod, iHold);
                    break;
                case 0x90:
                    timeStart = DateTime.Now;
                    retVal = "Start: " + GetKeyName(ev.AllData[1]); // + " Velo=" + ev.AllData[2];
                    if (ev.AllData[2] == 0) retVal += " (mute)";
                    break;
                //case 0xA0:
                //    retVal = "PollyAftertouch " + GetKeyName(ev.AllData[1]) + " Val=" + ev.AllData[2];
                //    break;
                //case 0xB0:
                //    retVal = "CNTL " + ((ControllerType)ev.AllData[1]) + " Val=" + ev.AllData[2];
                //    break;
                //case 0xC0:
                //    retVal = "ProgramChange ";// + GetGeneralMidiInstrumentName(ev.AllData[1]);
                //    break;
                default:
                    retVal = "unknown";
                    break;
            }

            return retVal;
        }

        private static string GetKeyName(byte val)
        {
            var noteNum = val % 12;
            string retVal = string.Empty;
            switch (noteNum)
            {
                case 0:
                    retVal = "C";
                    break;
                case 1:
                    retVal = "C#";
                    break;
                case 2:
                    retVal = "D";
                    break;
                case 3:
                    retVal = "D#";
                    break;
                case 4:
                    retVal = "E";
                    break;
                case 5:
                    retVal = "F";
                    break;
                case 6:
                    retVal = "F#";
                    break;
                case 7:
                    retVal = "G";
                    break;
                case 8:
                    retVal = "G#";
                    break;
                case 9:
                    retVal = "A";
                    break;
                case 10:
                    retVal = "A#";
                    break;
                case 11:
                    retVal = "B";     //"H/B"
                    break;
            }

            int tp = GetKeyTonePeriod(val);
            byte tCourse = (byte)((currentTonePeriod >> 8) & 15);
            byte tFine = (byte)(currentTonePeriod & 255);
            return retVal + (val / 12) + "(" + val + ") " + tp.ToString() + "  " + tCourse.ToString() + ":" + tFine.ToString();
        }

        private static Int16 GetKeyTonePeriod(byte val)
        {
            //key 57 = A4 (AKM320 MIDI keyboard)
            byte A4 = (byte)57;
            Int16 retVal = 0;
            //retVal = (short)(440 * ((2 ^ (1 / 12)) ^ (val - A4)));
            retVal = (short)(440 * Math.Pow(Math.Pow((double)2, (double)1 / (double)12), (double)(val - A4)));
            //=INT(2000000/(16*D74))
            retVal = ((short)(2000000 / (16 * retVal)));
            currentTonePeriod = retVal;
            return retVal;
        }

        private void MIDI_Load(object sender, EventArgs e)
        {
            inputDevicesComboBox.Items.Add("Select input device");
            outputDevicesComboBox.Items.Add("Select output device");
            var inp = MidiInInfo.Informations;
            foreach (var midiInInfo in inp)
            {
                inputDevicesComboBox.Items.Add(midiInInfo);
            }

            var outp = MidiOutInfo.Informations;
            foreach (var midiOutInfo in outp)
            {
                outputDevicesComboBox.Items.Add(midiOutInfo);
            }
            if(inputDevicesComboBox.Items.Count > 1)
            {
                inputDevicesComboBox.SelectedIndex = 1;
                outputDevicesComboBox.SelectedIndex = 1;
            }
        }
    }
}
