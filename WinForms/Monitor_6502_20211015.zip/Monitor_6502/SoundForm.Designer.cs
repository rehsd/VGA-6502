﻿
namespace Monitor_6502
{
    partial class SoundForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nudTonePeriodFineLA = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.nudTonePeriodCourseLA = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.nudNoisePeriodL1 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodCourseL1 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodFineL1 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.chkContL1 = new System.Windows.Forms.CheckBox();
            this.chkAttL1 = new System.Windows.Forms.CheckBox();
            this.chkHoldL1 = new System.Windows.Forms.CheckBox();
            this.chkAltL1 = new System.Windows.Forms.CheckBox();
            this.startButton = new System.Windows.Forms.Button();
            this.stopButton = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.connectionSpeedLabel = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.connectionStatusPictureBox = new System.Windows.Forms.PictureBox();
            this.PortsCombo = new System.Windows.Forms.ComboBox();
            this.ConnectButton = new System.Windows.Forms.Button();
            this.nudTonePeriodCourseLB = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineLB = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseLC = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineLC = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseLD = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineLD = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseLE = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineLE = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseLF = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineLF = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseRF = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineRF = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseRE = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineRE = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseRD = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineRD = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseRC = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineRC = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseRB = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineRB = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodCourseRA = new System.Windows.Forms.NumericUpDown();
            this.nudTonePeriodFineRA = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.nudNoisePeriodL2 = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodCourseL2 = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodFineL2 = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.chkContL2 = new System.Windows.Forms.CheckBox();
            this.chkAttL2 = new System.Windows.Forms.CheckBox();
            this.chkAltL2 = new System.Windows.Forms.CheckBox();
            this.chkHoldL2 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboVolFixedVarLF = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarLE = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarLD = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarLC = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarLB = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarLA = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.noiseLF = new System.Windows.Forms.CheckBox();
            this.toneLF = new System.Windows.Forms.CheckBox();
            this.noiseLE = new System.Windows.Forms.CheckBox();
            this.toneLE = new System.Windows.Forms.CheckBox();
            this.noiseLD = new System.Windows.Forms.CheckBox();
            this.toneLD = new System.Windows.Forms.CheckBox();
            this.noiseLC = new System.Windows.Forms.CheckBox();
            this.toneLC = new System.Windows.Forms.CheckBox();
            this.noiseLB = new System.Windows.Forms.CheckBox();
            this.toneLB = new System.Windows.Forms.CheckBox();
            this.noiseLA = new System.Windows.Forms.CheckBox();
            this.toneLA = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.nudVolumeLA = new System.Windows.Forms.NumericUpDown();
            this.nudVolumeLB = new System.Windows.Forms.NumericUpDown();
            this.nudVolumeLC = new System.Windows.Forms.NumericUpDown();
            this.nudVolumeLD = new System.Windows.Forms.NumericUpDown();
            this.nudVolumeLE = new System.Windows.Forms.NumericUpDown();
            this.nudVolumeLF = new System.Windows.Forms.NumericUpDown();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cboVolFixedVarRF = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarRE = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarRD = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarRC = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarRB = new System.Windows.Forms.ComboBox();
            this.cboVolFixedVarRA = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.noiseRF = new System.Windows.Forms.CheckBox();
            this.nudVolumeRA = new System.Windows.Forms.NumericUpDown();
            this.toneRF = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.noiseRE = new System.Windows.Forms.CheckBox();
            this.nudVolumeRB = new System.Windows.Forms.NumericUpDown();
            this.toneRE = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.noiseRD = new System.Windows.Forms.CheckBox();
            this.nudVolumeRC = new System.Windows.Forms.NumericUpDown();
            this.toneRD = new System.Windows.Forms.CheckBox();
            this.nudVolumeRD = new System.Windows.Forms.NumericUpDown();
            this.noiseRC = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.toneRC = new System.Windows.Forms.CheckBox();
            this.nudVolumeRE = new System.Windows.Forms.NumericUpDown();
            this.noiseRB = new System.Windows.Forms.CheckBox();
            this.toneRB = new System.Windows.Forms.CheckBox();
            this.nudVolumeRF = new System.Windows.Forms.NumericUpDown();
            this.noiseRA = new System.Windows.Forms.CheckBox();
            this.toneRA = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.enableUpdateButtonTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.nudNoisePeriodR2 = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodCourseR2 = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodFineR2 = new System.Windows.Forms.NumericUpDown();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.chkContR2 = new System.Windows.Forms.CheckBox();
            this.chkAttR2 = new System.Windows.Forms.CheckBox();
            this.chkAltR2 = new System.Windows.Forms.CheckBox();
            this.chkHoldR2 = new System.Windows.Forms.CheckBox();
            this.label43 = new System.Windows.Forms.Label();
            this.nudNoisePeriodR1 = new System.Windows.Forms.NumericUpDown();
            this.label44 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodCourseR1 = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.nudEnvelopePeriodFineR1 = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.chkContR1 = new System.Windows.Forms.CheckBox();
            this.chkAttR1 = new System.Windows.Forms.CheckBox();
            this.chkAltR1 = new System.Windows.Forms.CheckBox();
            this.chkHoldR1 = new System.Windows.Forms.CheckBox();
            this.chkHex = new System.Windows.Forms.CheckBox();
            this.AddToSequenceButton = new System.Windows.Forms.Button();
            this.dgvSequence = new System.Windows.Forms.DataGridView();
            this.command1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.command2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.command3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.command4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseLADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseLBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseLCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseLDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseLEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseLFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineLADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineLBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineLCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineLDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineLEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineLFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeLADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeLBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeLCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeLDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeLEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeLFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseRADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseRBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseRCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseRDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodCourseRFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineRADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineRBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineRCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineRDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tonePeriodFineRFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeRADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeRBDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeRCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeRDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeREDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.volumeRFDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noisePeriodL1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodFineL1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enableLeft1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enableRight1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enableLeft2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.enableRight2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noisePeriodR1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodFineR1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noisePeriodL2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodFineL2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noisePeriodR2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopePeriodFineR2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.holdTicksDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SequenceDataSet = new System.Data.DataSet();
            this.dataTable1 = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.dataColumn3 = new System.Data.DataColumn();
            this.dataColumn4 = new System.Data.DataColumn();
            this.dataColumn5 = new System.Data.DataColumn();
            this.dataColumn6 = new System.Data.DataColumn();
            this.dataColumn7 = new System.Data.DataColumn();
            this.dataColumn8 = new System.Data.DataColumn();
            this.dataColumn9 = new System.Data.DataColumn();
            this.dataColumn10 = new System.Data.DataColumn();
            this.dataColumn11 = new System.Data.DataColumn();
            this.dataColumn12 = new System.Data.DataColumn();
            this.dataColumn13 = new System.Data.DataColumn();
            this.dataColumn14 = new System.Data.DataColumn();
            this.dataColumn15 = new System.Data.DataColumn();
            this.dataColumn16 = new System.Data.DataColumn();
            this.dataColumn17 = new System.Data.DataColumn();
            this.dataColumn18 = new System.Data.DataColumn();
            this.dataColumn19 = new System.Data.DataColumn();
            this.dataColumn20 = new System.Data.DataColumn();
            this.dataColumn21 = new System.Data.DataColumn();
            this.dataColumn22 = new System.Data.DataColumn();
            this.dataColumn23 = new System.Data.DataColumn();
            this.dataColumn24 = new System.Data.DataColumn();
            this.dataColumn25 = new System.Data.DataColumn();
            this.dataColumn26 = new System.Data.DataColumn();
            this.dataColumn27 = new System.Data.DataColumn();
            this.dataColumn28 = new System.Data.DataColumn();
            this.dataColumn29 = new System.Data.DataColumn();
            this.dataColumn30 = new System.Data.DataColumn();
            this.dataColumn31 = new System.Data.DataColumn();
            this.dataColumn32 = new System.Data.DataColumn();
            this.dataColumn33 = new System.Data.DataColumn();
            this.dataColumn34 = new System.Data.DataColumn();
            this.dataColumn35 = new System.Data.DataColumn();
            this.dataColumn36 = new System.Data.DataColumn();
            this.dataColumn37 = new System.Data.DataColumn();
            this.dataColumn38 = new System.Data.DataColumn();
            this.dataColumn39 = new System.Data.DataColumn();
            this.dataColumn40 = new System.Data.DataColumn();
            this.dataColumn41 = new System.Data.DataColumn();
            this.dataColumn42 = new System.Data.DataColumn();
            this.dataColumn43 = new System.Data.DataColumn();
            this.dataColumn44 = new System.Data.DataColumn();
            this.dataColumn45 = new System.Data.DataColumn();
            this.dataColumn46 = new System.Data.DataColumn();
            this.dataColumn47 = new System.Data.DataColumn();
            this.dataColumn48 = new System.Data.DataColumn();
            this.dataColumn49 = new System.Data.DataColumn();
            this.dataColumn50 = new System.Data.DataColumn();
            this.dataColumn51 = new System.Data.DataColumn();
            this.dataColumn52 = new System.Data.DataColumn();
            this.dataColumn53 = new System.Data.DataColumn();
            this.dataColumn54 = new System.Data.DataColumn();
            this.dataColumn55 = new System.Data.DataColumn();
            this.dataColumn56 = new System.Data.DataColumn();
            this.dataColumn57 = new System.Data.DataColumn();
            this.dataColumn58 = new System.Data.DataColumn();
            this.dataColumn59 = new System.Data.DataColumn();
            this.dataColumn60 = new System.Data.DataColumn();
            this.dataColumn61 = new System.Data.DataColumn();
            this.ExpandDataViewButton = new System.Windows.Forms.Button();
            this.label27 = new System.Windows.Forms.Label();
            this.nudDelay = new System.Windows.Forms.NumericUpDown();
            this.SaveButton = new System.Windows.Forms.Button();
            this.LoadButton = new System.Windows.Forms.Button();
            this.PlayButton = new System.Windows.Forms.Button();
            this.CreateAssemblyButton = new System.Windows.Forms.Button();
            this.midiButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRA)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineL2)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLF)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRF)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineR2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineR1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSequence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SequenceDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDelay)).BeginInit();
            this.SuspendLayout();
            // 
            // nudTonePeriodFineLA
            // 
            this.nudTonePeriodFineLA.Location = new System.Drawing.Point(216, 76);
            this.nudTonePeriodFineLA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineLA.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineLA.Name = "nudTonePeriodFineLA";
            this.nudTonePeriodFineLA.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineLA.TabIndex = 3;
            this.nudTonePeriodFineLA.Value = new decimal(new int[] {
            221,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(204, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 34);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tone Period\r\nFine (0-255)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 79);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "L1:  Channel A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(102, 25);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 34);
            this.label4.TabIndex = 6;
            this.label4.Text = "Tone Period\r\nCourse (0-15)";
            // 
            // nudTonePeriodCourseLA
            // 
            this.nudTonePeriodCourseLA.Location = new System.Drawing.Point(122, 76);
            this.nudTonePeriodCourseLA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseLA.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseLA.Name = "nudTonePeriodCourseLA";
            this.nudTonePeriodCourseLA.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseLA.TabIndex = 2;
            this.nudTonePeriodCourseLA.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 60);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 34);
            this.label5.TabIndex = 8;
            this.label5.Text = "Noise Period\r\n(0-31)";
            // 
            // nudNoisePeriodL1
            // 
            this.nudNoisePeriodL1.Location = new System.Drawing.Point(26, 97);
            this.nudNoisePeriodL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudNoisePeriodL1.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.nudNoisePeriodL1.Name = "nudNoisePeriodL1";
            this.nudNoisePeriodL1.Size = new System.Drawing.Size(60, 22);
            this.nudNoisePeriodL1.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(116, 60);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 34);
            this.label6.TabIndex = 10;
            this.label6.Text = "Env Period\r\nCourse (0-255)";
            // 
            // nudEnvelopePeriodCourseL1
            // 
            this.nudEnvelopePeriodCourseL1.Location = new System.Drawing.Point(118, 97);
            this.nudEnvelopePeriodCourseL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodCourseL1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodCourseL1.Name = "nudEnvelopePeriodCourseL1";
            this.nudEnvelopePeriodCourseL1.Size = new System.Drawing.Size(50, 22);
            this.nudEnvelopePeriodCourseL1.TabIndex = 39;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(222, 60);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 34);
            this.label7.TabIndex = 12;
            this.label7.Text = "Env Period\r\nFine (0-255)";
            // 
            // nudEnvelopePeriodFineL1
            // 
            this.nudEnvelopePeriodFineL1.Location = new System.Drawing.Point(226, 97);
            this.nudEnvelopePeriodFineL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodFineL1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodFineL1.Name = "nudEnvelopePeriodFineL1";
            this.nudEnvelopePeriodFineL1.Size = new System.Drawing.Size(46, 22);
            this.nudEnvelopePeriodFineL1.TabIndex = 40;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(318, 60);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(150, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Envelope Shape/Cycle";
            // 
            // chkContL1
            // 
            this.chkContL1.AutoSize = true;
            this.chkContL1.Location = new System.Drawing.Point(318, 97);
            this.chkContL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkContL1.Name = "chkContL1";
            this.chkContL1.Size = new System.Drawing.Size(59, 21);
            this.chkContL1.TabIndex = 41;
            this.chkContL1.Text = "Cont";
            this.chkContL1.UseVisualStyleBackColor = true;
            // 
            // chkAttL1
            // 
            this.chkAttL1.AutoSize = true;
            this.chkAttL1.Location = new System.Drawing.Point(382, 97);
            this.chkAttL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAttL1.Name = "chkAttL1";
            this.chkAttL1.Size = new System.Drawing.Size(47, 21);
            this.chkAttL1.TabIndex = 42;
            this.chkAttL1.Text = "Att";
            this.chkAttL1.UseVisualStyleBackColor = true;
            // 
            // chkHoldL1
            // 
            this.chkHoldL1.AutoSize = true;
            this.chkHoldL1.Location = new System.Drawing.Point(486, 97);
            this.chkHoldL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkHoldL1.Name = "chkHoldL1";
            this.chkHoldL1.Size = new System.Drawing.Size(59, 21);
            this.chkHoldL1.TabIndex = 44;
            this.chkHoldL1.Text = "Hold";
            this.chkHoldL1.UseVisualStyleBackColor = true;
            // 
            // chkAltL1
            // 
            this.chkAltL1.AutoSize = true;
            this.chkAltL1.Location = new System.Drawing.Point(434, 97);
            this.chkAltL1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAltL1.Name = "chkAltL1";
            this.chkAltL1.Size = new System.Drawing.Size(46, 21);
            this.chkAltL1.TabIndex = 43;
            this.chkAltL1.Text = "Alt";
            this.chkAltL1.UseVisualStyleBackColor = true;
            // 
            // startButton
            // 
            this.startButton.Enabled = false;
            this.startButton.Location = new System.Drawing.Point(750, 16);
            this.startButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(114, 39);
            this.startButton.TabIndex = 45;
            this.startButton.Text = "&Update";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.Enabled = false;
            this.stopButton.Location = new System.Drawing.Point(870, 16);
            this.stopButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(106, 39);
            this.stopButton.TabIndex = 46;
            this.stopButton.Text = "&Stop";
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 113);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "L1:  Channel B";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 147);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 17);
            this.label12.TabIndex = 23;
            this.label12.Text = "L1:  Channel C";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 181);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 17);
            this.label14.TabIndex = 25;
            this.label14.Text = "L2:  Channel D";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(12, 215);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(101, 17);
            this.label16.TabIndex = 27;
            this.label16.Text = "L2:  Channel E";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 249);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 17);
            this.label18.TabIndex = 29;
            this.label18.Text = "L2:  Channel F";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 253);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(102, 17);
            this.label20.TabIndex = 41;
            this.label20.Text = "R2:  Channel F";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(10, 218);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 17);
            this.label22.TabIndex = 39;
            this.label22.Text = "R2:  Channel E";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 182);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(104, 17);
            this.label24.TabIndex = 37;
            this.label24.Text = "R2:  Channel D";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 147);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 17);
            this.label26.TabIndex = 35;
            this.label26.Text = "R1:  Channel C";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(10, 109);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(103, 17);
            this.label28.TabIndex = 33;
            this.label28.Text = "R1:  Channel B";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(10, 74);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(103, 17);
            this.label30.TabIndex = 31;
            this.label30.Text = "R1:  Channel A";
            // 
            // connectionSpeedLabel
            // 
            this.connectionSpeedLabel.Font = new System.Drawing.Font("Segoe UI", 7F);
            this.connectionSpeedLabel.Location = new System.Drawing.Point(542, 19);
            this.connectionSpeedLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.connectionSpeedLabel.Name = "connectionSpeedLabel";
            this.connectionSpeedLabel.Size = new System.Drawing.Size(158, 20);
            this.connectionSpeedLabel.TabIndex = 47;
            this.connectionSpeedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(10, 13);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(34, 17);
            this.label39.TabIndex = 46;
            this.label39.Text = "Port";
            // 
            // connectionStatusPictureBox
            // 
            this.connectionStatusPictureBox.BackColor = System.Drawing.Color.Red;
            this.connectionStatusPictureBox.Location = new System.Drawing.Point(514, 16);
            this.connectionStatusPictureBox.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.connectionStatusPictureBox.Name = "connectionStatusPictureBox";
            this.connectionStatusPictureBox.Size = new System.Drawing.Size(24, 19);
            this.connectionStatusPictureBox.TabIndex = 45;
            this.connectionStatusPictureBox.TabStop = false;
            // 
            // PortsCombo
            // 
            this.PortsCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PortsCombo.FormattingEnabled = true;
            this.PortsCombo.Location = new System.Drawing.Point(50, 12);
            this.PortsCombo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PortsCombo.Name = "PortsCombo";
            this.PortsCombo.Size = new System.Drawing.Size(362, 24);
            this.PortsCombo.TabIndex = 0;
            this.PortsCombo.SelectedIndexChanged += new System.EventHandler(this.PortsCombo_SelectedIndexChanged);
            // 
            // ConnectButton
            // 
            this.ConnectButton.Enabled = false;
            this.ConnectButton.Location = new System.Drawing.Point(418, 12);
            this.ConnectButton.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(96, 26);
            this.ConnectButton.TabIndex = 1;
            this.ConnectButton.Text = "&Connect";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.ConnectButton_Click);
            // 
            // nudTonePeriodCourseLB
            // 
            this.nudTonePeriodCourseLB.Location = new System.Drawing.Point(122, 111);
            this.nudTonePeriodCourseLB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseLB.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseLB.Name = "nudTonePeriodCourseLB";
            this.nudTonePeriodCourseLB.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseLB.TabIndex = 5;
            this.nudTonePeriodCourseLB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudTonePeriodFineLB
            // 
            this.nudTonePeriodFineLB.Location = new System.Drawing.Point(216, 111);
            this.nudTonePeriodFineLB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineLB.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineLB.Name = "nudTonePeriodFineLB";
            this.nudTonePeriodFineLB.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineLB.TabIndex = 6;
            this.nudTonePeriodFineLB.Value = new decimal(new int[] {
            123,
            0,
            0,
            0});
            // 
            // nudTonePeriodCourseLC
            // 
            this.nudTonePeriodCourseLC.Location = new System.Drawing.Point(122, 147);
            this.nudTonePeriodCourseLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseLC.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseLC.Name = "nudTonePeriodCourseLC";
            this.nudTonePeriodCourseLC.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseLC.TabIndex = 8;
            this.nudTonePeriodCourseLC.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudTonePeriodFineLC
            // 
            this.nudTonePeriodFineLC.Location = new System.Drawing.Point(216, 147);
            this.nudTonePeriodFineLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineLC.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineLC.Name = "nudTonePeriodFineLC";
            this.nudTonePeriodFineLC.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineLC.TabIndex = 9;
            this.nudTonePeriodFineLC.Value = new decimal(new int[] {
            62,
            0,
            0,
            0});
            // 
            // nudTonePeriodCourseLD
            // 
            this.nudTonePeriodCourseLD.Location = new System.Drawing.Point(122, 181);
            this.nudTonePeriodCourseLD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseLD.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseLD.Name = "nudTonePeriodCourseLD";
            this.nudTonePeriodCourseLD.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseLD.TabIndex = 11;
            // 
            // nudTonePeriodFineLD
            // 
            this.nudTonePeriodFineLD.Location = new System.Drawing.Point(216, 181);
            this.nudTonePeriodFineLD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineLD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineLD.Name = "nudTonePeriodFineLD";
            this.nudTonePeriodFineLD.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineLD.TabIndex = 12;
            // 
            // nudTonePeriodCourseLE
            // 
            this.nudTonePeriodCourseLE.Location = new System.Drawing.Point(122, 217);
            this.nudTonePeriodCourseLE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseLE.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseLE.Name = "nudTonePeriodCourseLE";
            this.nudTonePeriodCourseLE.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseLE.TabIndex = 14;
            // 
            // nudTonePeriodFineLE
            // 
            this.nudTonePeriodFineLE.Location = new System.Drawing.Point(216, 217);
            this.nudTonePeriodFineLE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineLE.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineLE.Name = "nudTonePeriodFineLE";
            this.nudTonePeriodFineLE.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineLE.TabIndex = 15;
            // 
            // nudTonePeriodCourseLF
            // 
            this.nudTonePeriodCourseLF.Location = new System.Drawing.Point(122, 251);
            this.nudTonePeriodCourseLF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseLF.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseLF.Name = "nudTonePeriodCourseLF";
            this.nudTonePeriodCourseLF.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseLF.TabIndex = 17;
            // 
            // nudTonePeriodFineLF
            // 
            this.nudTonePeriodFineLF.Location = new System.Drawing.Point(216, 251);
            this.nudTonePeriodFineLF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineLF.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineLF.Name = "nudTonePeriodFineLF";
            this.nudTonePeriodFineLF.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineLF.TabIndex = 18;
            // 
            // nudTonePeriodCourseRF
            // 
            this.nudTonePeriodCourseRF.Location = new System.Drawing.Point(122, 249);
            this.nudTonePeriodCourseRF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseRF.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseRF.Name = "nudTonePeriodCourseRF";
            this.nudTonePeriodCourseRF.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseRF.TabIndex = 35;
            // 
            // nudTonePeriodFineRF
            // 
            this.nudTonePeriodFineRF.Location = new System.Drawing.Point(214, 249);
            this.nudTonePeriodFineRF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineRF.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineRF.Name = "nudTonePeriodFineRF";
            this.nudTonePeriodFineRF.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineRF.TabIndex = 36;
            // 
            // nudTonePeriodCourseRE
            // 
            this.nudTonePeriodCourseRE.Location = new System.Drawing.Point(122, 214);
            this.nudTonePeriodCourseRE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseRE.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseRE.Name = "nudTonePeriodCourseRE";
            this.nudTonePeriodCourseRE.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseRE.TabIndex = 32;
            // 
            // nudTonePeriodFineRE
            // 
            this.nudTonePeriodFineRE.Location = new System.Drawing.Point(214, 214);
            this.nudTonePeriodFineRE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineRE.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineRE.Name = "nudTonePeriodFineRE";
            this.nudTonePeriodFineRE.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineRE.TabIndex = 33;
            // 
            // nudTonePeriodCourseRD
            // 
            this.nudTonePeriodCourseRD.Location = new System.Drawing.Point(122, 179);
            this.nudTonePeriodCourseRD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseRD.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseRD.Name = "nudTonePeriodCourseRD";
            this.nudTonePeriodCourseRD.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseRD.TabIndex = 29;
            // 
            // nudTonePeriodFineRD
            // 
            this.nudTonePeriodFineRD.Location = new System.Drawing.Point(214, 179);
            this.nudTonePeriodFineRD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineRD.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineRD.Name = "nudTonePeriodFineRD";
            this.nudTonePeriodFineRD.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineRD.TabIndex = 30;
            // 
            // nudTonePeriodCourseRC
            // 
            this.nudTonePeriodCourseRC.Location = new System.Drawing.Point(122, 144);
            this.nudTonePeriodCourseRC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseRC.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseRC.Name = "nudTonePeriodCourseRC";
            this.nudTonePeriodCourseRC.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseRC.TabIndex = 26;
            this.nudTonePeriodCourseRC.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudTonePeriodFineRC
            // 
            this.nudTonePeriodFineRC.Location = new System.Drawing.Point(214, 144);
            this.nudTonePeriodFineRC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineRC.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineRC.Name = "nudTonePeriodFineRC";
            this.nudTonePeriodFineRC.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineRC.TabIndex = 27;
            this.nudTonePeriodFineRC.Value = new decimal(new int[] {
            62,
            0,
            0,
            0});
            // 
            // nudTonePeriodCourseRB
            // 
            this.nudTonePeriodCourseRB.Location = new System.Drawing.Point(122, 109);
            this.nudTonePeriodCourseRB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseRB.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseRB.Name = "nudTonePeriodCourseRB";
            this.nudTonePeriodCourseRB.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseRB.TabIndex = 23;
            this.nudTonePeriodCourseRB.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudTonePeriodFineRB
            // 
            this.nudTonePeriodFineRB.Location = new System.Drawing.Point(214, 109);
            this.nudTonePeriodFineRB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineRB.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineRB.Name = "nudTonePeriodFineRB";
            this.nudTonePeriodFineRB.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineRB.TabIndex = 24;
            this.nudTonePeriodFineRB.Value = new decimal(new int[] {
            123,
            0,
            0,
            0});
            // 
            // nudTonePeriodCourseRA
            // 
            this.nudTonePeriodCourseRA.Location = new System.Drawing.Point(122, 74);
            this.nudTonePeriodCourseRA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodCourseRA.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudTonePeriodCourseRA.Name = "nudTonePeriodCourseRA";
            this.nudTonePeriodCourseRA.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodCourseRA.TabIndex = 20;
            this.nudTonePeriodCourseRA.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nudTonePeriodFineRA
            // 
            this.nudTonePeriodFineRA.Location = new System.Drawing.Point(214, 74);
            this.nudTonePeriodFineRA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudTonePeriodFineRA.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudTonePeriodFineRA.Name = "nudTonePeriodFineRA";
            this.nudTonePeriodFineRA.Size = new System.Drawing.Size(62, 22);
            this.nudTonePeriodFineRA.TabIndex = 21;
            this.nudTonePeriodFineRA.Value = new decimal(new int[] {
            221,
            0,
            0,
            0});
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.nudNoisePeriodL2);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.nudEnvelopePeriodCourseL2);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.nudEnvelopePeriodFineL2);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.chkContL2);
            this.groupBox1.Controls.Add(this.chkAttL2);
            this.groupBox1.Controls.Add(this.chkAltL2);
            this.groupBox1.Controls.Add(this.chkHoldL2);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.nudNoisePeriodL1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.nudEnvelopePeriodCourseL1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.nudEnvelopePeriodFineL1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.chkContL1);
            this.groupBox1.Controls.Add(this.chkAttL1);
            this.groupBox1.Controls.Add(this.chkAltL1);
            this.groupBox1.Controls.Add(this.chkHoldL1);
            this.groupBox1.Location = new System.Drawing.Point(14, 377);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox1.Size = new System.Drawing.Size(566, 263);
            this.groupBox1.TabIndex = 70;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Left Additional";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(26, 147);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(77, 17);
            this.label32.TabIndex = 57;
            this.label32.Text = "PSG Left 2";
            // 
            // nudNoisePeriodL2
            // 
            this.nudNoisePeriodL2.Location = new System.Drawing.Point(26, 211);
            this.nudNoisePeriodL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudNoisePeriodL2.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.nudNoisePeriodL2.Name = "nudNoisePeriodL2";
            this.nudNoisePeriodL2.Size = new System.Drawing.Size(60, 22);
            this.nudNoisePeriodL2.TabIndex = 50;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(24, 173);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(89, 34);
            this.label33.TabIndex = 46;
            this.label33.Text = "Noise Period\r\n(0-31)";
            // 
            // nudEnvelopePeriodCourseL2
            // 
            this.nudEnvelopePeriodCourseL2.Location = new System.Drawing.Point(118, 211);
            this.nudEnvelopePeriodCourseL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodCourseL2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodCourseL2.Name = "nudEnvelopePeriodCourseL2";
            this.nudEnvelopePeriodCourseL2.Size = new System.Drawing.Size(50, 22);
            this.nudEnvelopePeriodCourseL2.TabIndex = 51;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(114, 173);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(104, 34);
            this.label34.TabIndex = 47;
            this.label34.Text = "Env Period\r\nCourse (0-255)";
            // 
            // nudEnvelopePeriodFineL2
            // 
            this.nudEnvelopePeriodFineL2.Location = new System.Drawing.Point(226, 211);
            this.nudEnvelopePeriodFineL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodFineL2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodFineL2.Name = "nudEnvelopePeriodFineL2";
            this.nudEnvelopePeriodFineL2.Size = new System.Drawing.Size(46, 22);
            this.nudEnvelopePeriodFineL2.TabIndex = 52;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(222, 173);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(86, 34);
            this.label35.TabIndex = 48;
            this.label35.Text = "Env Period\r\nFine (0-255)";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(322, 173);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(150, 17);
            this.label36.TabIndex = 49;
            this.label36.Text = "Envelope Shape/Cycle";
            // 
            // chkContL2
            // 
            this.chkContL2.AutoSize = true;
            this.chkContL2.Location = new System.Drawing.Point(320, 211);
            this.chkContL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkContL2.Name = "chkContL2";
            this.chkContL2.Size = new System.Drawing.Size(59, 21);
            this.chkContL2.TabIndex = 53;
            this.chkContL2.Text = "Cont";
            this.chkContL2.UseVisualStyleBackColor = true;
            // 
            // chkAttL2
            // 
            this.chkAttL2.AutoSize = true;
            this.chkAttL2.Location = new System.Drawing.Point(384, 211);
            this.chkAttL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAttL2.Name = "chkAttL2";
            this.chkAttL2.Size = new System.Drawing.Size(47, 21);
            this.chkAttL2.TabIndex = 54;
            this.chkAttL2.Text = "Att";
            this.chkAttL2.UseVisualStyleBackColor = true;
            // 
            // chkAltL2
            // 
            this.chkAltL2.AutoSize = true;
            this.chkAltL2.Location = new System.Drawing.Point(438, 211);
            this.chkAltL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAltL2.Name = "chkAltL2";
            this.chkAltL2.Size = new System.Drawing.Size(46, 21);
            this.chkAltL2.TabIndex = 55;
            this.chkAltL2.Text = "Alt";
            this.chkAltL2.UseVisualStyleBackColor = true;
            // 
            // chkHoldL2
            // 
            this.chkHoldL2.AutoSize = true;
            this.chkHoldL2.Location = new System.Drawing.Point(490, 211);
            this.chkHoldL2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkHoldL2.Name = "chkHoldL2";
            this.chkHoldL2.Size = new System.Drawing.Size(59, 21);
            this.chkHoldL2.TabIndex = 56;
            this.chkHoldL2.Text = "Hold";
            this.chkHoldL2.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(22, 33);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 17);
            this.label23.TabIndex = 45;
            this.label23.Text = "PSG Left 1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboVolFixedVarLF);
            this.groupBox2.Controls.Add(this.cboVolFixedVarLE);
            this.groupBox2.Controls.Add(this.cboVolFixedVarLD);
            this.groupBox2.Controls.Add(this.cboVolFixedVarLC);
            this.groupBox2.Controls.Add(this.cboVolFixedVarLB);
            this.groupBox2.Controls.Add(this.cboVolFixedVarLA);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.noiseLF);
            this.groupBox2.Controls.Add(this.toneLF);
            this.groupBox2.Controls.Add(this.noiseLE);
            this.groupBox2.Controls.Add(this.toneLE);
            this.groupBox2.Controls.Add(this.noiseLD);
            this.groupBox2.Controls.Add(this.toneLD);
            this.groupBox2.Controls.Add(this.noiseLC);
            this.groupBox2.Controls.Add(this.toneLC);
            this.groupBox2.Controls.Add(this.noiseLB);
            this.groupBox2.Controls.Add(this.toneLB);
            this.groupBox2.Controls.Add(this.noiseLA);
            this.groupBox2.Controls.Add(this.toneLA);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.nudVolumeLA);
            this.groupBox2.Controls.Add(this.nudVolumeLB);
            this.groupBox2.Controls.Add(this.nudVolumeLC);
            this.groupBox2.Controls.Add(this.nudVolumeLD);
            this.groupBox2.Controls.Add(this.nudVolumeLE);
            this.groupBox2.Controls.Add(this.nudVolumeLF);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.nudTonePeriodFineLA);
            this.groupBox2.Controls.Add(this.nudTonePeriodCourseLA);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.nudTonePeriodFineLB);
            this.groupBox2.Controls.Add(this.nudTonePeriodCourseLB);
            this.groupBox2.Controls.Add(this.nudTonePeriodFineLC);
            this.groupBox2.Controls.Add(this.nudTonePeriodCourseLC);
            this.groupBox2.Controls.Add(this.nudTonePeriodFineLD);
            this.groupBox2.Controls.Add(this.nudTonePeriodCourseLD);
            this.groupBox2.Controls.Add(this.nudTonePeriodFineLE);
            this.groupBox2.Controls.Add(this.nudTonePeriodCourseLF);
            this.groupBox2.Controls.Add(this.nudTonePeriodCourseLE);
            this.groupBox2.Controls.Add(this.nudTonePeriodFineLF);
            this.groupBox2.Location = new System.Drawing.Point(14, 59);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox2.Size = new System.Drawing.Size(566, 292);
            this.groupBox2.TabIndex = 71;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Left";
            // 
            // cboVolFixedVarLF
            // 
            this.cboVolFixedVarLF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarLF.FormattingEnabled = true;
            this.cboVolFixedVarLF.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarLF.Location = new System.Drawing.Point(294, 252);
            this.cboVolFixedVarLF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarLF.Name = "cboVolFixedVarLF";
            this.cboVolFixedVarLF.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarLF.TabIndex = 99;
            // 
            // cboVolFixedVarLE
            // 
            this.cboVolFixedVarLE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarLE.FormattingEnabled = true;
            this.cboVolFixedVarLE.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarLE.Location = new System.Drawing.Point(294, 217);
            this.cboVolFixedVarLE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarLE.Name = "cboVolFixedVarLE";
            this.cboVolFixedVarLE.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarLE.TabIndex = 98;
            // 
            // cboVolFixedVarLD
            // 
            this.cboVolFixedVarLD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarLD.FormattingEnabled = true;
            this.cboVolFixedVarLD.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarLD.Location = new System.Drawing.Point(294, 180);
            this.cboVolFixedVarLD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarLD.Name = "cboVolFixedVarLD";
            this.cboVolFixedVarLD.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarLD.TabIndex = 97;
            // 
            // cboVolFixedVarLC
            // 
            this.cboVolFixedVarLC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarLC.FormattingEnabled = true;
            this.cboVolFixedVarLC.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarLC.Location = new System.Drawing.Point(294, 144);
            this.cboVolFixedVarLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarLC.Name = "cboVolFixedVarLC";
            this.cboVolFixedVarLC.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarLC.TabIndex = 96;
            // 
            // cboVolFixedVarLB
            // 
            this.cboVolFixedVarLB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarLB.FormattingEnabled = true;
            this.cboVolFixedVarLB.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarLB.Location = new System.Drawing.Point(294, 108);
            this.cboVolFixedVarLB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarLB.Name = "cboVolFixedVarLB";
            this.cboVolFixedVarLB.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarLB.TabIndex = 95;
            // 
            // cboVolFixedVarLA
            // 
            this.cboVolFixedVarLA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarLA.FormattingEnabled = true;
            this.cboVolFixedVarLA.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarLA.Location = new System.Drawing.Point(294, 71);
            this.cboVolFixedVarLA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarLA.Name = "cboVolFixedVarLA";
            this.cboVolFixedVarLA.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarLA.TabIndex = 94;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(296, 25);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 34);
            this.label25.TabIndex = 86;
            this.label25.Text = "Volume\r\nFxd/Var";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(394, 25);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 34);
            this.label11.TabIndex = 58;
            this.label11.Text = "Volume\r\n(0-15)\r\n";
            // 
            // noiseLF
            // 
            this.noiseLF.AutoSize = true;
            this.noiseLF.Location = new System.Drawing.Point(522, 253);
            this.noiseLF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseLF.Name = "noiseLF";
            this.noiseLF.Size = new System.Drawing.Size(18, 17);
            this.noiseLF.TabIndex = 85;
            this.noiseLF.UseVisualStyleBackColor = true;
            // 
            // toneLF
            // 
            this.toneLF.AutoSize = true;
            this.toneLF.Location = new System.Drawing.Point(480, 255);
            this.toneLF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneLF.Name = "toneLF";
            this.toneLF.Size = new System.Drawing.Size(18, 17);
            this.toneLF.TabIndex = 84;
            this.toneLF.UseVisualStyleBackColor = true;
            // 
            // noiseLE
            // 
            this.noiseLE.AutoSize = true;
            this.noiseLE.Location = new System.Drawing.Point(522, 218);
            this.noiseLE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseLE.Name = "noiseLE";
            this.noiseLE.Size = new System.Drawing.Size(18, 17);
            this.noiseLE.TabIndex = 83;
            this.noiseLE.UseVisualStyleBackColor = true;
            // 
            // toneLE
            // 
            this.toneLE.AutoSize = true;
            this.toneLE.Location = new System.Drawing.Point(480, 219);
            this.toneLE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneLE.Name = "toneLE";
            this.toneLE.Size = new System.Drawing.Size(18, 17);
            this.toneLE.TabIndex = 82;
            this.toneLE.UseVisualStyleBackColor = true;
            // 
            // noiseLD
            // 
            this.noiseLD.AutoSize = true;
            this.noiseLD.Location = new System.Drawing.Point(522, 182);
            this.noiseLD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseLD.Name = "noiseLD";
            this.noiseLD.Size = new System.Drawing.Size(18, 17);
            this.noiseLD.TabIndex = 81;
            this.noiseLD.UseVisualStyleBackColor = true;
            // 
            // toneLD
            // 
            this.toneLD.AutoSize = true;
            this.toneLD.Location = new System.Drawing.Point(480, 183);
            this.toneLD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneLD.Name = "toneLD";
            this.toneLD.Size = new System.Drawing.Size(18, 17);
            this.toneLD.TabIndex = 80;
            this.toneLD.UseVisualStyleBackColor = true;
            // 
            // noiseLC
            // 
            this.noiseLC.AutoSize = true;
            this.noiseLC.Location = new System.Drawing.Point(522, 147);
            this.noiseLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseLC.Name = "noiseLC";
            this.noiseLC.Size = new System.Drawing.Size(18, 17);
            this.noiseLC.TabIndex = 79;
            this.noiseLC.UseVisualStyleBackColor = true;
            // 
            // toneLC
            // 
            this.toneLC.AutoSize = true;
            this.toneLC.Checked = true;
            this.toneLC.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toneLC.Location = new System.Drawing.Point(480, 147);
            this.toneLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneLC.Name = "toneLC";
            this.toneLC.Size = new System.Drawing.Size(18, 17);
            this.toneLC.TabIndex = 78;
            this.toneLC.UseVisualStyleBackColor = true;
            // 
            // noiseLB
            // 
            this.noiseLB.AutoSize = true;
            this.noiseLB.Location = new System.Drawing.Point(522, 109);
            this.noiseLB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseLB.Name = "noiseLB";
            this.noiseLB.Size = new System.Drawing.Size(18, 17);
            this.noiseLB.TabIndex = 77;
            this.noiseLB.UseVisualStyleBackColor = true;
            // 
            // toneLB
            // 
            this.toneLB.AutoSize = true;
            this.toneLB.Checked = true;
            this.toneLB.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toneLB.Location = new System.Drawing.Point(480, 111);
            this.toneLB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneLB.Name = "toneLB";
            this.toneLB.Size = new System.Drawing.Size(18, 17);
            this.toneLB.TabIndex = 76;
            this.toneLB.UseVisualStyleBackColor = true;
            // 
            // noiseLA
            // 
            this.noiseLA.AutoSize = true;
            this.noiseLA.Location = new System.Drawing.Point(522, 74);
            this.noiseLA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseLA.Name = "noiseLA";
            this.noiseLA.Size = new System.Drawing.Size(18, 17);
            this.noiseLA.TabIndex = 75;
            this.noiseLA.UseVisualStyleBackColor = true;
            // 
            // toneLA
            // 
            this.toneLA.AutoSize = true;
            this.toneLA.Checked = true;
            this.toneLA.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toneLA.Location = new System.Drawing.Point(480, 75);
            this.toneLA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneLA.Name = "toneLA";
            this.toneLA.Size = new System.Drawing.Size(18, 17);
            this.toneLA.TabIndex = 45;
            this.toneLA.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(508, 25);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 17);
            this.label17.TabIndex = 74;
            this.label17.Text = "Noise";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(466, 25);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 17);
            this.label15.TabIndex = 73;
            this.label15.Text = "Tone";
            // 
            // nudVolumeLA
            // 
            this.nudVolumeLA.Location = new System.Drawing.Point(396, 76);
            this.nudVolumeLA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeLA.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeLA.Name = "nudVolumeLA";
            this.nudVolumeLA.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeLA.TabIndex = 4;
            this.nudVolumeLA.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudVolumeLB
            // 
            this.nudVolumeLB.Location = new System.Drawing.Point(396, 111);
            this.nudVolumeLB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeLB.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeLB.Name = "nudVolumeLB";
            this.nudVolumeLB.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeLB.TabIndex = 7;
            this.nudVolumeLB.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudVolumeLC
            // 
            this.nudVolumeLC.Location = new System.Drawing.Point(396, 147);
            this.nudVolumeLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeLC.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeLC.Name = "nudVolumeLC";
            this.nudVolumeLC.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeLC.TabIndex = 10;
            this.nudVolumeLC.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // nudVolumeLD
            // 
            this.nudVolumeLD.Location = new System.Drawing.Point(396, 181);
            this.nudVolumeLD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeLD.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeLD.Name = "nudVolumeLD";
            this.nudVolumeLD.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeLD.TabIndex = 13;
            // 
            // nudVolumeLE
            // 
            this.nudVolumeLE.Location = new System.Drawing.Point(396, 217);
            this.nudVolumeLE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeLE.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeLE.Name = "nudVolumeLE";
            this.nudVolumeLE.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeLE.TabIndex = 16;
            // 
            // nudVolumeLF
            // 
            this.nudVolumeLF.Location = new System.Drawing.Point(396, 251);
            this.nudVolumeLF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeLF.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeLF.Name = "nudVolumeLF";
            this.nudVolumeLF.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeLF.TabIndex = 19;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cboVolFixedVarRF);
            this.groupBox3.Controls.Add(this.cboVolFixedVarRE);
            this.groupBox3.Controls.Add(this.cboVolFixedVarRD);
            this.groupBox3.Controls.Add(this.cboVolFixedVarRC);
            this.groupBox3.Controls.Add(this.cboVolFixedVarRB);
            this.groupBox3.Controls.Add(this.cboVolFixedVarRA);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.noiseRF);
            this.groupBox3.Controls.Add(this.nudVolumeRA);
            this.groupBox3.Controls.Add(this.toneRF);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.noiseRE);
            this.groupBox3.Controls.Add(this.nudVolumeRB);
            this.groupBox3.Controls.Add(this.toneRE);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.noiseRD);
            this.groupBox3.Controls.Add(this.nudVolumeRC);
            this.groupBox3.Controls.Add(this.toneRD);
            this.groupBox3.Controls.Add(this.nudVolumeRD);
            this.groupBox3.Controls.Add(this.noiseRC);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.toneRC);
            this.groupBox3.Controls.Add(this.nudVolumeRE);
            this.groupBox3.Controls.Add(this.noiseRB);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.toneRB);
            this.groupBox3.Controls.Add(this.nudVolumeRF);
            this.groupBox3.Controls.Add(this.noiseRA);
            this.groupBox3.Controls.Add(this.toneRA);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.nudTonePeriodCourseRF);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.nudTonePeriodFineRF);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.nudTonePeriodCourseRE);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.nudTonePeriodFineRE);
            this.groupBox3.Controls.Add(this.nudTonePeriodFineRA);
            this.groupBox3.Controls.Add(this.nudTonePeriodCourseRD);
            this.groupBox3.Controls.Add(this.nudTonePeriodCourseRA);
            this.groupBox3.Controls.Add(this.nudTonePeriodFineRD);
            this.groupBox3.Controls.Add(this.nudTonePeriodFineRB);
            this.groupBox3.Controls.Add(this.nudTonePeriodCourseRC);
            this.groupBox3.Controls.Add(this.nudTonePeriodCourseRB);
            this.groupBox3.Controls.Add(this.nudTonePeriodFineRC);
            this.groupBox3.Location = new System.Drawing.Point(586, 59);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox3.Size = new System.Drawing.Size(574, 292);
            this.groupBox3.TabIndex = 72;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Right";
            // 
            // cboVolFixedVarRF
            // 
            this.cboVolFixedVarRF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarRF.FormattingEnabled = true;
            this.cboVolFixedVarRF.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarRF.Location = new System.Drawing.Point(292, 250);
            this.cboVolFixedVarRF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarRF.Name = "cboVolFixedVarRF";
            this.cboVolFixedVarRF.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarRF.TabIndex = 106;
            // 
            // cboVolFixedVarRE
            // 
            this.cboVolFixedVarRE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarRE.FormattingEnabled = true;
            this.cboVolFixedVarRE.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarRE.Location = new System.Drawing.Point(292, 214);
            this.cboVolFixedVarRE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarRE.Name = "cboVolFixedVarRE";
            this.cboVolFixedVarRE.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarRE.TabIndex = 105;
            // 
            // cboVolFixedVarRD
            // 
            this.cboVolFixedVarRD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarRD.FormattingEnabled = true;
            this.cboVolFixedVarRD.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarRD.Location = new System.Drawing.Point(292, 179);
            this.cboVolFixedVarRD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarRD.Name = "cboVolFixedVarRD";
            this.cboVolFixedVarRD.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarRD.TabIndex = 104;
            // 
            // cboVolFixedVarRC
            // 
            this.cboVolFixedVarRC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarRC.FormattingEnabled = true;
            this.cboVolFixedVarRC.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarRC.Location = new System.Drawing.Point(292, 141);
            this.cboVolFixedVarRC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarRC.Name = "cboVolFixedVarRC";
            this.cboVolFixedVarRC.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarRC.TabIndex = 103;
            // 
            // cboVolFixedVarRB
            // 
            this.cboVolFixedVarRB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarRB.FormattingEnabled = true;
            this.cboVolFixedVarRB.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarRB.Location = new System.Drawing.Point(292, 106);
            this.cboVolFixedVarRB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarRB.Name = "cboVolFixedVarRB";
            this.cboVolFixedVarRB.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarRB.TabIndex = 102;
            // 
            // cboVolFixedVarRA
            // 
            this.cboVolFixedVarRA.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboVolFixedVarRA.FormattingEnabled = true;
            this.cboVolFixedVarRA.Items.AddRange(new object[] {
            "Fixed",
            "Variable"});
            this.cboVolFixedVarRA.Location = new System.Drawing.Point(292, 70);
            this.cboVolFixedVarRA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.cboVolFixedVarRA.Name = "cboVolFixedVarRA";
            this.cboVolFixedVarRA.Size = new System.Drawing.Size(90, 24);
            this.cboVolFixedVarRA.TabIndex = 101;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(290, 25);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(56, 34);
            this.label29.TabIndex = 100;
            this.label29.Text = "Volume\r\nFxd/Var";
            // 
            // noiseRF
            // 
            this.noiseRF.AutoSize = true;
            this.noiseRF.Location = new System.Drawing.Point(528, 251);
            this.noiseRF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseRF.Name = "noiseRF";
            this.noiseRF.Size = new System.Drawing.Size(18, 17);
            this.noiseRF.TabIndex = 99;
            this.noiseRF.UseVisualStyleBackColor = true;
            // 
            // nudVolumeRA
            // 
            this.nudVolumeRA.Location = new System.Drawing.Point(396, 73);
            this.nudVolumeRA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeRA.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeRA.Name = "nudVolumeRA";
            this.nudVolumeRA.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeRA.TabIndex = 22;
            this.nudVolumeRA.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // toneRF
            // 
            this.toneRF.AutoSize = true;
            this.toneRF.Location = new System.Drawing.Point(482, 252);
            this.toneRF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneRF.Name = "toneRF";
            this.toneRF.Size = new System.Drawing.Size(18, 17);
            this.toneRF.TabIndex = 98;
            this.toneRF.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(394, 25);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 34);
            this.label13.TabIndex = 73;
            this.label13.Text = "Volume\r\n(0-15)\r\n";
            // 
            // noiseRE
            // 
            this.noiseRE.AutoSize = true;
            this.noiseRE.Location = new System.Drawing.Point(528, 215);
            this.noiseRE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseRE.Name = "noiseRE";
            this.noiseRE.Size = new System.Drawing.Size(18, 17);
            this.noiseRE.TabIndex = 97;
            this.noiseRE.UseVisualStyleBackColor = true;
            // 
            // nudVolumeRB
            // 
            this.nudVolumeRB.Location = new System.Drawing.Point(396, 108);
            this.nudVolumeRB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeRB.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeRB.Name = "nudVolumeRB";
            this.nudVolumeRB.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeRB.TabIndex = 25;
            this.nudVolumeRB.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // toneRE
            // 
            this.toneRE.AutoSize = true;
            this.toneRE.Location = new System.Drawing.Point(482, 217);
            this.toneRE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneRE.Name = "toneRE";
            this.toneRE.Size = new System.Drawing.Size(18, 17);
            this.toneRE.TabIndex = 96;
            this.toneRE.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(200, 25);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 34);
            this.label3.TabIndex = 58;
            this.label3.Text = "Tone Period\r\nFine (0-255)";
            // 
            // noiseRD
            // 
            this.noiseRD.AutoSize = true;
            this.noiseRD.Location = new System.Drawing.Point(528, 179);
            this.noiseRD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseRD.Name = "noiseRD";
            this.noiseRD.Size = new System.Drawing.Size(18, 17);
            this.noiseRD.TabIndex = 95;
            this.noiseRD.UseVisualStyleBackColor = true;
            // 
            // nudVolumeRC
            // 
            this.nudVolumeRC.Location = new System.Drawing.Point(396, 143);
            this.nudVolumeRC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeRC.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeRC.Name = "nudVolumeRC";
            this.nudVolumeRC.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeRC.TabIndex = 28;
            this.nudVolumeRC.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // toneRD
            // 
            this.toneRD.AutoSize = true;
            this.toneRD.Location = new System.Drawing.Point(482, 180);
            this.toneRD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneRD.Name = "toneRD";
            this.toneRD.Size = new System.Drawing.Size(18, 17);
            this.toneRD.TabIndex = 94;
            this.toneRD.UseVisualStyleBackColor = true;
            // 
            // nudVolumeRD
            // 
            this.nudVolumeRD.Location = new System.Drawing.Point(396, 179);
            this.nudVolumeRD.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeRD.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeRD.Name = "nudVolumeRD";
            this.nudVolumeRD.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeRD.TabIndex = 31;
            // 
            // noiseRC
            // 
            this.noiseRC.AutoSize = true;
            this.noiseRC.Location = new System.Drawing.Point(528, 143);
            this.noiseRC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseRC.Name = "noiseRC";
            this.noiseRC.Size = new System.Drawing.Size(18, 17);
            this.noiseRC.TabIndex = 93;
            this.noiseRC.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(104, 25);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 34);
            this.label9.TabIndex = 59;
            this.label9.Text = "Tone Period\r\nCourse (0-15)";
            // 
            // toneRC
            // 
            this.toneRC.AutoSize = true;
            this.toneRC.Checked = true;
            this.toneRC.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toneRC.Location = new System.Drawing.Point(482, 144);
            this.toneRC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneRC.Name = "toneRC";
            this.toneRC.Size = new System.Drawing.Size(18, 17);
            this.toneRC.TabIndex = 92;
            this.toneRC.UseVisualStyleBackColor = true;
            // 
            // nudVolumeRE
            // 
            this.nudVolumeRE.Location = new System.Drawing.Point(396, 213);
            this.nudVolumeRE.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeRE.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeRE.Name = "nudVolumeRE";
            this.nudVolumeRE.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeRE.TabIndex = 34;
            // 
            // noiseRB
            // 
            this.noiseRB.AutoSize = true;
            this.noiseRB.Location = new System.Drawing.Point(528, 107);
            this.noiseRB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseRB.Name = "noiseRB";
            this.noiseRB.Size = new System.Drawing.Size(18, 17);
            this.noiseRB.TabIndex = 91;
            this.noiseRB.UseVisualStyleBackColor = true;
            // 
            // toneRB
            // 
            this.toneRB.AutoSize = true;
            this.toneRB.Checked = true;
            this.toneRB.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toneRB.Location = new System.Drawing.Point(482, 108);
            this.toneRB.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneRB.Name = "toneRB";
            this.toneRB.Size = new System.Drawing.Size(18, 17);
            this.toneRB.TabIndex = 90;
            this.toneRB.UseVisualStyleBackColor = true;
            // 
            // nudVolumeRF
            // 
            this.nudVolumeRF.Location = new System.Drawing.Point(396, 249);
            this.nudVolumeRF.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudVolumeRF.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudVolumeRF.Name = "nudVolumeRF";
            this.nudVolumeRF.Size = new System.Drawing.Size(52, 22);
            this.nudVolumeRF.TabIndex = 37;
            // 
            // noiseRA
            // 
            this.noiseRA.AutoSize = true;
            this.noiseRA.Location = new System.Drawing.Point(528, 71);
            this.noiseRA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.noiseRA.Name = "noiseRA";
            this.noiseRA.Size = new System.Drawing.Size(18, 17);
            this.noiseRA.TabIndex = 89;
            this.noiseRA.UseVisualStyleBackColor = true;
            // 
            // toneRA
            // 
            this.toneRA.AutoSize = true;
            this.toneRA.Checked = true;
            this.toneRA.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toneRA.Location = new System.Drawing.Point(482, 71);
            this.toneRA.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.toneRA.Name = "toneRA";
            this.toneRA.Size = new System.Drawing.Size(18, 17);
            this.toneRA.TabIndex = 86;
            this.toneRA.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(510, 25);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(44, 17);
            this.label19.TabIndex = 88;
            this.label19.Text = "Noise";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(462, 25);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 17);
            this.label21.TabIndex = 87;
            this.label21.Text = "Tone";
            // 
            // enableUpdateButtonTimer
            // 
            this.enableUpdateButtonTimer.Interval = 6000;
            this.enableUpdateButtonTimer.Tick += new System.EventHandler(this.enableUpdateButtonTimer_Tick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label37);
            this.groupBox4.Controls.Add(this.nudNoisePeriodR2);
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Controls.Add(this.nudEnvelopePeriodCourseR2);
            this.groupBox4.Controls.Add(this.label40);
            this.groupBox4.Controls.Add(this.nudEnvelopePeriodFineR2);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.chkContR2);
            this.groupBox4.Controls.Add(this.chkAttR2);
            this.groupBox4.Controls.Add(this.chkAltR2);
            this.groupBox4.Controls.Add(this.chkHoldR2);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.nudNoisePeriodR1);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.nudEnvelopePeriodCourseR1);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.nudEnvelopePeriodFineR1);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.label47);
            this.groupBox4.Controls.Add(this.chkContR1);
            this.groupBox4.Controls.Add(this.chkAttR1);
            this.groupBox4.Controls.Add(this.chkAltR1);
            this.groupBox4.Controls.Add(this.chkHoldR1);
            this.groupBox4.Location = new System.Drawing.Point(586, 377);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.groupBox4.Size = new System.Drawing.Size(574, 263);
            this.groupBox4.TabIndex = 71;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Right Additional";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(24, 147);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(86, 17);
            this.label37.TabIndex = 57;
            this.label37.Text = "PSG Right 2";
            // 
            // nudNoisePeriodR2
            // 
            this.nudNoisePeriodR2.Location = new System.Drawing.Point(26, 211);
            this.nudNoisePeriodR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudNoisePeriodR2.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.nudNoisePeriodR2.Name = "nudNoisePeriodR2";
            this.nudNoisePeriodR2.Size = new System.Drawing.Size(60, 22);
            this.nudNoisePeriodR2.TabIndex = 50;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(24, 173);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(89, 34);
            this.label38.TabIndex = 46;
            this.label38.Text = "Noise Period\r\n(0-31)";
            // 
            // nudEnvelopePeriodCourseR2
            // 
            this.nudEnvelopePeriodCourseR2.Location = new System.Drawing.Point(118, 211);
            this.nudEnvelopePeriodCourseR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodCourseR2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodCourseR2.Name = "nudEnvelopePeriodCourseR2";
            this.nudEnvelopePeriodCourseR2.Size = new System.Drawing.Size(50, 22);
            this.nudEnvelopePeriodCourseR2.TabIndex = 51;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(116, 173);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(104, 34);
            this.label40.TabIndex = 47;
            this.label40.Text = "Env Period\r\nCourse (0-255)";
            // 
            // nudEnvelopePeriodFineR2
            // 
            this.nudEnvelopePeriodFineR2.Location = new System.Drawing.Point(226, 211);
            this.nudEnvelopePeriodFineR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodFineR2.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodFineR2.Name = "nudEnvelopePeriodFineR2";
            this.nudEnvelopePeriodFineR2.Size = new System.Drawing.Size(46, 22);
            this.nudEnvelopePeriodFineR2.TabIndex = 52;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(222, 173);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(86, 34);
            this.label41.TabIndex = 48;
            this.label41.Text = "Env Period\r\nFine (0-255)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(324, 173);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(150, 17);
            this.label42.TabIndex = 49;
            this.label42.Text = "Envelope Shape/Cycle";
            // 
            // chkContR2
            // 
            this.chkContR2.AutoSize = true;
            this.chkContR2.Location = new System.Drawing.Point(322, 211);
            this.chkContR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkContR2.Name = "chkContR2";
            this.chkContR2.Size = new System.Drawing.Size(59, 21);
            this.chkContR2.TabIndex = 53;
            this.chkContR2.Text = "Cont";
            this.chkContR2.UseVisualStyleBackColor = true;
            // 
            // chkAttR2
            // 
            this.chkAttR2.AutoSize = true;
            this.chkAttR2.Location = new System.Drawing.Point(386, 211);
            this.chkAttR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAttR2.Name = "chkAttR2";
            this.chkAttR2.Size = new System.Drawing.Size(47, 21);
            this.chkAttR2.TabIndex = 54;
            this.chkAttR2.Text = "Att";
            this.chkAttR2.UseVisualStyleBackColor = true;
            // 
            // chkAltR2
            // 
            this.chkAltR2.AutoSize = true;
            this.chkAltR2.Location = new System.Drawing.Point(440, 211);
            this.chkAltR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAltR2.Name = "chkAltR2";
            this.chkAltR2.Size = new System.Drawing.Size(46, 21);
            this.chkAltR2.TabIndex = 55;
            this.chkAltR2.Text = "Alt";
            this.chkAltR2.UseVisualStyleBackColor = true;
            // 
            // chkHoldR2
            // 
            this.chkHoldR2.AutoSize = true;
            this.chkHoldR2.Location = new System.Drawing.Point(492, 211);
            this.chkHoldR2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkHoldR2.Name = "chkHoldR2";
            this.chkHoldR2.Size = new System.Drawing.Size(59, 21);
            this.chkHoldR2.TabIndex = 56;
            this.chkHoldR2.Text = "Hold";
            this.chkHoldR2.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(24, 33);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(86, 17);
            this.label43.TabIndex = 45;
            this.label43.Text = "PSG Right 1";
            // 
            // nudNoisePeriodR1
            // 
            this.nudNoisePeriodR1.Location = new System.Drawing.Point(26, 97);
            this.nudNoisePeriodR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudNoisePeriodR1.Maximum = new decimal(new int[] {
            31,
            0,
            0,
            0});
            this.nudNoisePeriodR1.Name = "nudNoisePeriodR1";
            this.nudNoisePeriodR1.Size = new System.Drawing.Size(60, 22);
            this.nudNoisePeriodR1.TabIndex = 38;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(24, 60);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(89, 34);
            this.label44.TabIndex = 8;
            this.label44.Text = "Noise Period\r\n(0-31)";
            // 
            // nudEnvelopePeriodCourseR1
            // 
            this.nudEnvelopePeriodCourseR1.Location = new System.Drawing.Point(120, 97);
            this.nudEnvelopePeriodCourseR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodCourseR1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodCourseR1.Name = "nudEnvelopePeriodCourseR1";
            this.nudEnvelopePeriodCourseR1.Size = new System.Drawing.Size(50, 22);
            this.nudEnvelopePeriodCourseR1.TabIndex = 39;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(118, 60);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(104, 34);
            this.label45.TabIndex = 10;
            this.label45.Text = "Env Period\r\nCourse (0-255)";
            // 
            // nudEnvelopePeriodFineR1
            // 
            this.nudEnvelopePeriodFineR1.Location = new System.Drawing.Point(226, 97);
            this.nudEnvelopePeriodFineR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudEnvelopePeriodFineR1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudEnvelopePeriodFineR1.Name = "nudEnvelopePeriodFineR1";
            this.nudEnvelopePeriodFineR1.Size = new System.Drawing.Size(46, 22);
            this.nudEnvelopePeriodFineR1.TabIndex = 40;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(222, 60);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(86, 34);
            this.label46.TabIndex = 12;
            this.label46.Text = "Env Period\r\nFine (0-255)";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(322, 60);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(150, 17);
            this.label47.TabIndex = 14;
            this.label47.Text = "Envelope Shape/Cycle";
            // 
            // chkContR1
            // 
            this.chkContR1.AutoSize = true;
            this.chkContR1.Location = new System.Drawing.Point(322, 97);
            this.chkContR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkContR1.Name = "chkContR1";
            this.chkContR1.Size = new System.Drawing.Size(59, 21);
            this.chkContR1.TabIndex = 41;
            this.chkContR1.Text = "Cont";
            this.chkContR1.UseVisualStyleBackColor = true;
            // 
            // chkAttR1
            // 
            this.chkAttR1.AutoSize = true;
            this.chkAttR1.Location = new System.Drawing.Point(386, 97);
            this.chkAttR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAttR1.Name = "chkAttR1";
            this.chkAttR1.Size = new System.Drawing.Size(47, 21);
            this.chkAttR1.TabIndex = 42;
            this.chkAttR1.Text = "Att";
            this.chkAttR1.UseVisualStyleBackColor = true;
            // 
            // chkAltR1
            // 
            this.chkAltR1.AutoSize = true;
            this.chkAltR1.Location = new System.Drawing.Point(438, 97);
            this.chkAltR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkAltR1.Name = "chkAltR1";
            this.chkAltR1.Size = new System.Drawing.Size(46, 21);
            this.chkAltR1.TabIndex = 43;
            this.chkAltR1.Text = "Alt";
            this.chkAltR1.UseVisualStyleBackColor = true;
            // 
            // chkHoldR1
            // 
            this.chkHoldR1.AutoSize = true;
            this.chkHoldR1.Location = new System.Drawing.Point(490, 97);
            this.chkHoldR1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkHoldR1.Name = "chkHoldR1";
            this.chkHoldR1.Size = new System.Drawing.Size(59, 21);
            this.chkHoldR1.TabIndex = 44;
            this.chkHoldR1.Text = "Hold";
            this.chkHoldR1.UseVisualStyleBackColor = true;
            // 
            // chkHex
            // 
            this.chkHex.AutoSize = true;
            this.chkHex.Location = new System.Drawing.Point(662, 19);
            this.chkHex.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.chkHex.Name = "chkHex";
            this.chkHex.Size = new System.Drawing.Size(54, 21);
            this.chkHex.TabIndex = 73;
            this.chkHex.Text = "Hex";
            this.chkHex.UseVisualStyleBackColor = true;
            this.chkHex.CheckedChanged += new System.EventHandler(this.chkHex_CheckedChanged);
            // 
            // AddToSequenceButton
            // 
            this.AddToSequenceButton.Location = new System.Drawing.Point(1126, 19);
            this.AddToSequenceButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.AddToSequenceButton.Name = "AddToSequenceButton";
            this.AddToSequenceButton.Size = new System.Drawing.Size(138, 39);
            this.AddToSequenceButton.TabIndex = 74;
            this.AddToSequenceButton.Text = "&Add to Sequence";
            this.AddToSequenceButton.UseVisualStyleBackColor = true;
            this.AddToSequenceButton.Click += new System.EventHandler(this.AddToSequenceButton_Click);
            // 
            // dgvSequence
            // 
            this.dgvSequence.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSequence.AutoGenerateColumns = false;
            this.dgvSequence.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSequence.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.command1DataGridViewTextBoxColumn,
            this.command2DataGridViewTextBoxColumn,
            this.command3DataGridViewTextBoxColumn,
            this.command4DataGridViewTextBoxColumn,
            this.tonePeriodCourseLADataGridViewTextBoxColumn,
            this.tonePeriodCourseLBDataGridViewTextBoxColumn,
            this.tonePeriodCourseLCDataGridViewTextBoxColumn,
            this.tonePeriodCourseLDDataGridViewTextBoxColumn,
            this.tonePeriodCourseLEDataGridViewTextBoxColumn,
            this.tonePeriodCourseLFDataGridViewTextBoxColumn,
            this.tonePeriodFineLADataGridViewTextBoxColumn,
            this.tonePeriodFineLBDataGridViewTextBoxColumn,
            this.tonePeriodFineLCDataGridViewTextBoxColumn,
            this.tonePeriodFineLDDataGridViewTextBoxColumn,
            this.tonePeriodFineLEDataGridViewTextBoxColumn,
            this.tonePeriodFineLFDataGridViewTextBoxColumn,
            this.volumeLADataGridViewTextBoxColumn,
            this.volumeLBDataGridViewTextBoxColumn,
            this.volumeLCDataGridViewTextBoxColumn,
            this.volumeLDDataGridViewTextBoxColumn,
            this.volumeLEDataGridViewTextBoxColumn,
            this.volumeLFDataGridViewTextBoxColumn,
            this.tonePeriodCourseRADataGridViewTextBoxColumn,
            this.tonePeriodCourseRBDataGridViewTextBoxColumn,
            this.tonePeriodCourseRCDataGridViewTextBoxColumn,
            this.tonePeriodCourseRDDataGridViewTextBoxColumn,
            this.tonePeriodCourseREDataGridViewTextBoxColumn,
            this.tonePeriodCourseRFDataGridViewTextBoxColumn,
            this.tonePeriodFineRADataGridViewTextBoxColumn,
            this.tonePeriodFineRBDataGridViewTextBoxColumn,
            this.tonePeriodFineRCDataGridViewTextBoxColumn,
            this.tonePeriodFineRDDataGridViewTextBoxColumn,
            this.tonePeriodFineREDataGridViewTextBoxColumn,
            this.tonePeriodFineRFDataGridViewTextBoxColumn,
            this.volumeRADataGridViewTextBoxColumn,
            this.volumeRBDataGridViewTextBoxColumn,
            this.volumeRCDataGridViewTextBoxColumn,
            this.volumeRDDataGridViewTextBoxColumn,
            this.volumeREDataGridViewTextBoxColumn,
            this.volumeRFDataGridViewTextBoxColumn,
            this.noisePeriodL1DataGridViewTextBoxColumn,
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn,
            this.envelopePeriodFineL1DataGridViewTextBoxColumn,
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn,
            this.enableLeft1DataGridViewTextBoxColumn,
            this.enableRight1DataGridViewTextBoxColumn,
            this.enableLeft2DataGridViewTextBoxColumn,
            this.enableRight2DataGridViewTextBoxColumn,
            this.noisePeriodR1DataGridViewTextBoxColumn,
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn,
            this.envelopePeriodFineR1DataGridViewTextBoxColumn,
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn,
            this.noisePeriodL2DataGridViewTextBoxColumn,
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn,
            this.envelopePeriodFineL2DataGridViewTextBoxColumn,
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn,
            this.noisePeriodR2DataGridViewTextBoxColumn,
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn,
            this.envelopePeriodFineR2DataGridViewTextBoxColumn,
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn,
            this.holdTicksDataGridViewTextBoxColumn});
            this.dgvSequence.DataMember = "Table1";
            this.dgvSequence.DataSource = this.SequenceDataSet;
            this.dgvSequence.Location = new System.Drawing.Point(1180, 129);
            this.dgvSequence.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvSequence.Name = "dgvSequence";
            this.dgvSequence.RowHeadersWidth = 102;
            this.dgvSequence.Size = new System.Drawing.Size(706, 509);
            this.dgvSequence.TabIndex = 76;
            // 
            // command1DataGridViewTextBoxColumn
            // 
            this.command1DataGridViewTextBoxColumn.DataPropertyName = "Command1";
            this.command1DataGridViewTextBoxColumn.HeaderText = "Command1";
            this.command1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.command1DataGridViewTextBoxColumn.Name = "command1DataGridViewTextBoxColumn";
            this.command1DataGridViewTextBoxColumn.Visible = false;
            this.command1DataGridViewTextBoxColumn.Width = 250;
            // 
            // command2DataGridViewTextBoxColumn
            // 
            this.command2DataGridViewTextBoxColumn.DataPropertyName = "Command2";
            this.command2DataGridViewTextBoxColumn.HeaderText = "Command2";
            this.command2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.command2DataGridViewTextBoxColumn.Name = "command2DataGridViewTextBoxColumn";
            this.command2DataGridViewTextBoxColumn.Visible = false;
            this.command2DataGridViewTextBoxColumn.Width = 250;
            // 
            // command3DataGridViewTextBoxColumn
            // 
            this.command3DataGridViewTextBoxColumn.DataPropertyName = "Command3";
            this.command3DataGridViewTextBoxColumn.HeaderText = "Command3";
            this.command3DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.command3DataGridViewTextBoxColumn.Name = "command3DataGridViewTextBoxColumn";
            this.command3DataGridViewTextBoxColumn.Visible = false;
            this.command3DataGridViewTextBoxColumn.Width = 250;
            // 
            // command4DataGridViewTextBoxColumn
            // 
            this.command4DataGridViewTextBoxColumn.DataPropertyName = "Command4";
            this.command4DataGridViewTextBoxColumn.HeaderText = "Command4";
            this.command4DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.command4DataGridViewTextBoxColumn.Name = "command4DataGridViewTextBoxColumn";
            this.command4DataGridViewTextBoxColumn.Visible = false;
            this.command4DataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseLADataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseLADataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseLA";
            this.tonePeriodCourseLADataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseLA";
            this.tonePeriodCourseLADataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseLADataGridViewTextBoxColumn.Name = "tonePeriodCourseLADataGridViewTextBoxColumn";
            this.tonePeriodCourseLADataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseLBDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseLBDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseLB";
            this.tonePeriodCourseLBDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseLB";
            this.tonePeriodCourseLBDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseLBDataGridViewTextBoxColumn.Name = "tonePeriodCourseLBDataGridViewTextBoxColumn";
            this.tonePeriodCourseLBDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseLCDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseLCDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseLC";
            this.tonePeriodCourseLCDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseLC";
            this.tonePeriodCourseLCDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseLCDataGridViewTextBoxColumn.Name = "tonePeriodCourseLCDataGridViewTextBoxColumn";
            this.tonePeriodCourseLCDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseLDDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseLDDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseLD";
            this.tonePeriodCourseLDDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseLD";
            this.tonePeriodCourseLDDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseLDDataGridViewTextBoxColumn.Name = "tonePeriodCourseLDDataGridViewTextBoxColumn";
            this.tonePeriodCourseLDDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseLEDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseLEDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseLE";
            this.tonePeriodCourseLEDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseLE";
            this.tonePeriodCourseLEDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseLEDataGridViewTextBoxColumn.Name = "tonePeriodCourseLEDataGridViewTextBoxColumn";
            this.tonePeriodCourseLEDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseLFDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseLFDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseLF";
            this.tonePeriodCourseLFDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseLF";
            this.tonePeriodCourseLFDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseLFDataGridViewTextBoxColumn.Name = "tonePeriodCourseLFDataGridViewTextBoxColumn";
            this.tonePeriodCourseLFDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineLADataGridViewTextBoxColumn
            // 
            this.tonePeriodFineLADataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineLA";
            this.tonePeriodFineLADataGridViewTextBoxColumn.HeaderText = "TonePeriodFineLA";
            this.tonePeriodFineLADataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineLADataGridViewTextBoxColumn.Name = "tonePeriodFineLADataGridViewTextBoxColumn";
            this.tonePeriodFineLADataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineLBDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineLBDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineLB";
            this.tonePeriodFineLBDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineLB";
            this.tonePeriodFineLBDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineLBDataGridViewTextBoxColumn.Name = "tonePeriodFineLBDataGridViewTextBoxColumn";
            this.tonePeriodFineLBDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineLCDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineLCDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineLC";
            this.tonePeriodFineLCDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineLC";
            this.tonePeriodFineLCDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineLCDataGridViewTextBoxColumn.Name = "tonePeriodFineLCDataGridViewTextBoxColumn";
            this.tonePeriodFineLCDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineLDDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineLDDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineLD";
            this.tonePeriodFineLDDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineLD";
            this.tonePeriodFineLDDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineLDDataGridViewTextBoxColumn.Name = "tonePeriodFineLDDataGridViewTextBoxColumn";
            this.tonePeriodFineLDDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineLEDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineLEDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineLE";
            this.tonePeriodFineLEDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineLE";
            this.tonePeriodFineLEDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineLEDataGridViewTextBoxColumn.Name = "tonePeriodFineLEDataGridViewTextBoxColumn";
            this.tonePeriodFineLEDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineLFDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineLFDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineLF";
            this.tonePeriodFineLFDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineLF";
            this.tonePeriodFineLFDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineLFDataGridViewTextBoxColumn.Name = "tonePeriodFineLFDataGridViewTextBoxColumn";
            this.tonePeriodFineLFDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeLADataGridViewTextBoxColumn
            // 
            this.volumeLADataGridViewTextBoxColumn.DataPropertyName = "VolumeLA";
            this.volumeLADataGridViewTextBoxColumn.HeaderText = "VolumeLA";
            this.volumeLADataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeLADataGridViewTextBoxColumn.Name = "volumeLADataGridViewTextBoxColumn";
            this.volumeLADataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeLBDataGridViewTextBoxColumn
            // 
            this.volumeLBDataGridViewTextBoxColumn.DataPropertyName = "VolumeLB";
            this.volumeLBDataGridViewTextBoxColumn.HeaderText = "VolumeLB";
            this.volumeLBDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeLBDataGridViewTextBoxColumn.Name = "volumeLBDataGridViewTextBoxColumn";
            this.volumeLBDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeLCDataGridViewTextBoxColumn
            // 
            this.volumeLCDataGridViewTextBoxColumn.DataPropertyName = "VolumeLC";
            this.volumeLCDataGridViewTextBoxColumn.HeaderText = "VolumeLC";
            this.volumeLCDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeLCDataGridViewTextBoxColumn.Name = "volumeLCDataGridViewTextBoxColumn";
            this.volumeLCDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeLDDataGridViewTextBoxColumn
            // 
            this.volumeLDDataGridViewTextBoxColumn.DataPropertyName = "VolumeLD";
            this.volumeLDDataGridViewTextBoxColumn.HeaderText = "VolumeLD";
            this.volumeLDDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeLDDataGridViewTextBoxColumn.Name = "volumeLDDataGridViewTextBoxColumn";
            this.volumeLDDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeLEDataGridViewTextBoxColumn
            // 
            this.volumeLEDataGridViewTextBoxColumn.DataPropertyName = "VolumeLE";
            this.volumeLEDataGridViewTextBoxColumn.HeaderText = "VolumeLE";
            this.volumeLEDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeLEDataGridViewTextBoxColumn.Name = "volumeLEDataGridViewTextBoxColumn";
            this.volumeLEDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeLFDataGridViewTextBoxColumn
            // 
            this.volumeLFDataGridViewTextBoxColumn.DataPropertyName = "VolumeLF";
            this.volumeLFDataGridViewTextBoxColumn.HeaderText = "VolumeLF";
            this.volumeLFDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeLFDataGridViewTextBoxColumn.Name = "volumeLFDataGridViewTextBoxColumn";
            this.volumeLFDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseRADataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseRADataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseRA";
            this.tonePeriodCourseRADataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseRA";
            this.tonePeriodCourseRADataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseRADataGridViewTextBoxColumn.Name = "tonePeriodCourseRADataGridViewTextBoxColumn";
            this.tonePeriodCourseRADataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseRBDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseRBDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseRB";
            this.tonePeriodCourseRBDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseRB";
            this.tonePeriodCourseRBDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseRBDataGridViewTextBoxColumn.Name = "tonePeriodCourseRBDataGridViewTextBoxColumn";
            this.tonePeriodCourseRBDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseRCDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseRCDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseRC";
            this.tonePeriodCourseRCDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseRC";
            this.tonePeriodCourseRCDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseRCDataGridViewTextBoxColumn.Name = "tonePeriodCourseRCDataGridViewTextBoxColumn";
            this.tonePeriodCourseRCDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseRDDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseRDDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseRD";
            this.tonePeriodCourseRDDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseRD";
            this.tonePeriodCourseRDDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseRDDataGridViewTextBoxColumn.Name = "tonePeriodCourseRDDataGridViewTextBoxColumn";
            this.tonePeriodCourseRDDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseREDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseREDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseRE";
            this.tonePeriodCourseREDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseRE";
            this.tonePeriodCourseREDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseREDataGridViewTextBoxColumn.Name = "tonePeriodCourseREDataGridViewTextBoxColumn";
            this.tonePeriodCourseREDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodCourseRFDataGridViewTextBoxColumn
            // 
            this.tonePeriodCourseRFDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodCourseRF";
            this.tonePeriodCourseRFDataGridViewTextBoxColumn.HeaderText = "TonePeriodCourseRF";
            this.tonePeriodCourseRFDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodCourseRFDataGridViewTextBoxColumn.Name = "tonePeriodCourseRFDataGridViewTextBoxColumn";
            this.tonePeriodCourseRFDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineRADataGridViewTextBoxColumn
            // 
            this.tonePeriodFineRADataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineRA";
            this.tonePeriodFineRADataGridViewTextBoxColumn.HeaderText = "TonePeriodFineRA";
            this.tonePeriodFineRADataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineRADataGridViewTextBoxColumn.Name = "tonePeriodFineRADataGridViewTextBoxColumn";
            this.tonePeriodFineRADataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineRBDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineRBDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineRB";
            this.tonePeriodFineRBDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineRB";
            this.tonePeriodFineRBDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineRBDataGridViewTextBoxColumn.Name = "tonePeriodFineRBDataGridViewTextBoxColumn";
            this.tonePeriodFineRBDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineRCDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineRCDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineRC";
            this.tonePeriodFineRCDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineRC";
            this.tonePeriodFineRCDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineRCDataGridViewTextBoxColumn.Name = "tonePeriodFineRCDataGridViewTextBoxColumn";
            this.tonePeriodFineRCDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineRDDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineRDDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineRD";
            this.tonePeriodFineRDDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineRD";
            this.tonePeriodFineRDDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineRDDataGridViewTextBoxColumn.Name = "tonePeriodFineRDDataGridViewTextBoxColumn";
            this.tonePeriodFineRDDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineREDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineREDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineRE";
            this.tonePeriodFineREDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineRE";
            this.tonePeriodFineREDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineREDataGridViewTextBoxColumn.Name = "tonePeriodFineREDataGridViewTextBoxColumn";
            this.tonePeriodFineREDataGridViewTextBoxColumn.Width = 250;
            // 
            // tonePeriodFineRFDataGridViewTextBoxColumn
            // 
            this.tonePeriodFineRFDataGridViewTextBoxColumn.DataPropertyName = "TonePeriodFineRF";
            this.tonePeriodFineRFDataGridViewTextBoxColumn.HeaderText = "TonePeriodFineRF";
            this.tonePeriodFineRFDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.tonePeriodFineRFDataGridViewTextBoxColumn.Name = "tonePeriodFineRFDataGridViewTextBoxColumn";
            this.tonePeriodFineRFDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeRADataGridViewTextBoxColumn
            // 
            this.volumeRADataGridViewTextBoxColumn.DataPropertyName = "VolumeRA";
            this.volumeRADataGridViewTextBoxColumn.HeaderText = "VolumeRA";
            this.volumeRADataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeRADataGridViewTextBoxColumn.Name = "volumeRADataGridViewTextBoxColumn";
            this.volumeRADataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeRBDataGridViewTextBoxColumn
            // 
            this.volumeRBDataGridViewTextBoxColumn.DataPropertyName = "VolumeRB";
            this.volumeRBDataGridViewTextBoxColumn.HeaderText = "VolumeRB";
            this.volumeRBDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeRBDataGridViewTextBoxColumn.Name = "volumeRBDataGridViewTextBoxColumn";
            this.volumeRBDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeRCDataGridViewTextBoxColumn
            // 
            this.volumeRCDataGridViewTextBoxColumn.DataPropertyName = "VolumeRC";
            this.volumeRCDataGridViewTextBoxColumn.HeaderText = "VolumeRC";
            this.volumeRCDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeRCDataGridViewTextBoxColumn.Name = "volumeRCDataGridViewTextBoxColumn";
            this.volumeRCDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeRDDataGridViewTextBoxColumn
            // 
            this.volumeRDDataGridViewTextBoxColumn.DataPropertyName = "VolumeRD";
            this.volumeRDDataGridViewTextBoxColumn.HeaderText = "VolumeRD";
            this.volumeRDDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeRDDataGridViewTextBoxColumn.Name = "volumeRDDataGridViewTextBoxColumn";
            this.volumeRDDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeREDataGridViewTextBoxColumn
            // 
            this.volumeREDataGridViewTextBoxColumn.DataPropertyName = "VolumeRE";
            this.volumeREDataGridViewTextBoxColumn.HeaderText = "VolumeRE";
            this.volumeREDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeREDataGridViewTextBoxColumn.Name = "volumeREDataGridViewTextBoxColumn";
            this.volumeREDataGridViewTextBoxColumn.Width = 250;
            // 
            // volumeRFDataGridViewTextBoxColumn
            // 
            this.volumeRFDataGridViewTextBoxColumn.DataPropertyName = "VolumeRF";
            this.volumeRFDataGridViewTextBoxColumn.HeaderText = "VolumeRF";
            this.volumeRFDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.volumeRFDataGridViewTextBoxColumn.Name = "volumeRFDataGridViewTextBoxColumn";
            this.volumeRFDataGridViewTextBoxColumn.Width = 250;
            // 
            // noisePeriodL1DataGridViewTextBoxColumn
            // 
            this.noisePeriodL1DataGridViewTextBoxColumn.DataPropertyName = "NoisePeriodL1";
            this.noisePeriodL1DataGridViewTextBoxColumn.HeaderText = "NoisePeriodL1";
            this.noisePeriodL1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.noisePeriodL1DataGridViewTextBoxColumn.Name = "noisePeriodL1DataGridViewTextBoxColumn";
            this.noisePeriodL1DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodCourseL1DataGridViewTextBoxColumn
            // 
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodCourseL1";
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodCourseL1";
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn.Name = "envelopePeriodCourseL1DataGridViewTextBoxColumn";
            this.envelopePeriodCourseL1DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodFineL1DataGridViewTextBoxColumn
            // 
            this.envelopePeriodFineL1DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodFineL1";
            this.envelopePeriodFineL1DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodFineL1";
            this.envelopePeriodFineL1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodFineL1DataGridViewTextBoxColumn.Name = "envelopePeriodFineL1DataGridViewTextBoxColumn";
            this.envelopePeriodFineL1DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopeShapeCycleL1DataGridViewTextBoxColumn
            // 
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn.DataPropertyName = "EnvelopeShapeCycleL1";
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn.HeaderText = "EnvelopeShapeCycleL1";
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn.Name = "envelopeShapeCycleL1DataGridViewTextBoxColumn";
            this.envelopeShapeCycleL1DataGridViewTextBoxColumn.Width = 250;
            // 
            // enableLeft1DataGridViewTextBoxColumn
            // 
            this.enableLeft1DataGridViewTextBoxColumn.DataPropertyName = "EnableLeft1";
            this.enableLeft1DataGridViewTextBoxColumn.HeaderText = "EnableLeft1";
            this.enableLeft1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.enableLeft1DataGridViewTextBoxColumn.Name = "enableLeft1DataGridViewTextBoxColumn";
            this.enableLeft1DataGridViewTextBoxColumn.Width = 250;
            // 
            // enableRight1DataGridViewTextBoxColumn
            // 
            this.enableRight1DataGridViewTextBoxColumn.DataPropertyName = "EnableRight1";
            this.enableRight1DataGridViewTextBoxColumn.HeaderText = "EnableRight1";
            this.enableRight1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.enableRight1DataGridViewTextBoxColumn.Name = "enableRight1DataGridViewTextBoxColumn";
            this.enableRight1DataGridViewTextBoxColumn.Width = 250;
            // 
            // enableLeft2DataGridViewTextBoxColumn
            // 
            this.enableLeft2DataGridViewTextBoxColumn.DataPropertyName = "EnableLeft2";
            this.enableLeft2DataGridViewTextBoxColumn.HeaderText = "EnableLeft2";
            this.enableLeft2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.enableLeft2DataGridViewTextBoxColumn.Name = "enableLeft2DataGridViewTextBoxColumn";
            this.enableLeft2DataGridViewTextBoxColumn.Width = 250;
            // 
            // enableRight2DataGridViewTextBoxColumn
            // 
            this.enableRight2DataGridViewTextBoxColumn.DataPropertyName = "EnableRight2";
            this.enableRight2DataGridViewTextBoxColumn.HeaderText = "EnableRight2";
            this.enableRight2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.enableRight2DataGridViewTextBoxColumn.Name = "enableRight2DataGridViewTextBoxColumn";
            this.enableRight2DataGridViewTextBoxColumn.Width = 250;
            // 
            // noisePeriodR1DataGridViewTextBoxColumn
            // 
            this.noisePeriodR1DataGridViewTextBoxColumn.DataPropertyName = "NoisePeriodR1";
            this.noisePeriodR1DataGridViewTextBoxColumn.HeaderText = "NoisePeriodR1";
            this.noisePeriodR1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.noisePeriodR1DataGridViewTextBoxColumn.Name = "noisePeriodR1DataGridViewTextBoxColumn";
            this.noisePeriodR1DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodCourseR1DataGridViewTextBoxColumn
            // 
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodCourseR1";
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodCourseR1";
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn.Name = "envelopePeriodCourseR1DataGridViewTextBoxColumn";
            this.envelopePeriodCourseR1DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodFineR1DataGridViewTextBoxColumn
            // 
            this.envelopePeriodFineR1DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodFineR1";
            this.envelopePeriodFineR1DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodFineR1";
            this.envelopePeriodFineR1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodFineR1DataGridViewTextBoxColumn.Name = "envelopePeriodFineR1DataGridViewTextBoxColumn";
            this.envelopePeriodFineR1DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopeShapeCycleR1DataGridViewTextBoxColumn
            // 
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn.DataPropertyName = "EnvelopeShapeCycleR1";
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn.HeaderText = "EnvelopeShapeCycleR1";
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn.Name = "envelopeShapeCycleR1DataGridViewTextBoxColumn";
            this.envelopeShapeCycleR1DataGridViewTextBoxColumn.Width = 250;
            // 
            // noisePeriodL2DataGridViewTextBoxColumn
            // 
            this.noisePeriodL2DataGridViewTextBoxColumn.DataPropertyName = "NoisePeriodL2";
            this.noisePeriodL2DataGridViewTextBoxColumn.HeaderText = "NoisePeriodL2";
            this.noisePeriodL2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.noisePeriodL2DataGridViewTextBoxColumn.Name = "noisePeriodL2DataGridViewTextBoxColumn";
            this.noisePeriodL2DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodCourseL2DataGridViewTextBoxColumn
            // 
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodCourseL2";
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodCourseL2";
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn.Name = "envelopePeriodCourseL2DataGridViewTextBoxColumn";
            this.envelopePeriodCourseL2DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodFineL2DataGridViewTextBoxColumn
            // 
            this.envelopePeriodFineL2DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodFineL2";
            this.envelopePeriodFineL2DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodFineL2";
            this.envelopePeriodFineL2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodFineL2DataGridViewTextBoxColumn.Name = "envelopePeriodFineL2DataGridViewTextBoxColumn";
            this.envelopePeriodFineL2DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopeShapeCycleL2DataGridViewTextBoxColumn
            // 
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn.DataPropertyName = "EnvelopeShapeCycleL2";
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn.HeaderText = "EnvelopeShapeCycleL2";
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn.Name = "envelopeShapeCycleL2DataGridViewTextBoxColumn";
            this.envelopeShapeCycleL2DataGridViewTextBoxColumn.Width = 250;
            // 
            // noisePeriodR2DataGridViewTextBoxColumn
            // 
            this.noisePeriodR2DataGridViewTextBoxColumn.DataPropertyName = "NoisePeriodR2";
            this.noisePeriodR2DataGridViewTextBoxColumn.HeaderText = "NoisePeriodR2";
            this.noisePeriodR2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.noisePeriodR2DataGridViewTextBoxColumn.Name = "noisePeriodR2DataGridViewTextBoxColumn";
            this.noisePeriodR2DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodCourseR2DataGridViewTextBoxColumn
            // 
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodCourseR2";
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodCourseR2";
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn.Name = "envelopePeriodCourseR2DataGridViewTextBoxColumn";
            this.envelopePeriodCourseR2DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopePeriodFineR2DataGridViewTextBoxColumn
            // 
            this.envelopePeriodFineR2DataGridViewTextBoxColumn.DataPropertyName = "EnvelopePeriodFineR2";
            this.envelopePeriodFineR2DataGridViewTextBoxColumn.HeaderText = "EnvelopePeriodFineR2";
            this.envelopePeriodFineR2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopePeriodFineR2DataGridViewTextBoxColumn.Name = "envelopePeriodFineR2DataGridViewTextBoxColumn";
            this.envelopePeriodFineR2DataGridViewTextBoxColumn.Width = 250;
            // 
            // envelopeShapeCycleR2DataGridViewTextBoxColumn
            // 
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn.DataPropertyName = "EnvelopeShapeCycleR2";
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn.HeaderText = "EnvelopeShapeCycleR2";
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn.MinimumWidth = 12;
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn.Name = "envelopeShapeCycleR2DataGridViewTextBoxColumn";
            this.envelopeShapeCycleR2DataGridViewTextBoxColumn.Width = 250;
            // 
            // holdTicksDataGridViewTextBoxColumn
            // 
            this.holdTicksDataGridViewTextBoxColumn.DataPropertyName = "HoldTicks";
            this.holdTicksDataGridViewTextBoxColumn.HeaderText = "HoldTicks";
            this.holdTicksDataGridViewTextBoxColumn.MinimumWidth = 12;
            this.holdTicksDataGridViewTextBoxColumn.Name = "holdTicksDataGridViewTextBoxColumn";
            this.holdTicksDataGridViewTextBoxColumn.Width = 250;
            // 
            // SequenceDataSet
            // 
            this.SequenceDataSet.DataSetName = "NewDataSet";
            this.SequenceDataSet.Tables.AddRange(new System.Data.DataTable[] {
            this.dataTable1});
            // 
            // dataTable1
            // 
            this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2,
            this.dataColumn3,
            this.dataColumn4,
            this.dataColumn5,
            this.dataColumn6,
            this.dataColumn7,
            this.dataColumn8,
            this.dataColumn9,
            this.dataColumn10,
            this.dataColumn11,
            this.dataColumn12,
            this.dataColumn13,
            this.dataColumn14,
            this.dataColumn15,
            this.dataColumn16,
            this.dataColumn17,
            this.dataColumn18,
            this.dataColumn19,
            this.dataColumn20,
            this.dataColumn21,
            this.dataColumn22,
            this.dataColumn23,
            this.dataColumn24,
            this.dataColumn25,
            this.dataColumn26,
            this.dataColumn27,
            this.dataColumn28,
            this.dataColumn29,
            this.dataColumn30,
            this.dataColumn31,
            this.dataColumn32,
            this.dataColumn33,
            this.dataColumn34,
            this.dataColumn35,
            this.dataColumn36,
            this.dataColumn37,
            this.dataColumn38,
            this.dataColumn39,
            this.dataColumn40,
            this.dataColumn41,
            this.dataColumn42,
            this.dataColumn43,
            this.dataColumn44,
            this.dataColumn45,
            this.dataColumn46,
            this.dataColumn47,
            this.dataColumn48,
            this.dataColumn49,
            this.dataColumn50,
            this.dataColumn51,
            this.dataColumn52,
            this.dataColumn53,
            this.dataColumn54,
            this.dataColumn55,
            this.dataColumn56,
            this.dataColumn57,
            this.dataColumn58,
            this.dataColumn59,
            this.dataColumn60,
            this.dataColumn61});
            this.dataTable1.TableName = "Table1";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "Command1";
            this.dataColumn1.DataType = typeof(byte);
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "Command2";
            this.dataColumn2.DataType = typeof(byte);
            // 
            // dataColumn3
            // 
            this.dataColumn3.ColumnName = "Command3";
            this.dataColumn3.DataType = typeof(byte);
            // 
            // dataColumn4
            // 
            this.dataColumn4.ColumnName = "Command4";
            this.dataColumn4.DataType = typeof(byte);
            // 
            // dataColumn5
            // 
            this.dataColumn5.ColumnName = "TonePeriodCourseLA";
            this.dataColumn5.DataType = typeof(byte);
            // 
            // dataColumn6
            // 
            this.dataColumn6.ColumnName = "TonePeriodCourseLB";
            this.dataColumn6.DataType = typeof(byte);
            // 
            // dataColumn7
            // 
            this.dataColumn7.ColumnName = "TonePeriodCourseLC";
            this.dataColumn7.DataType = typeof(byte);
            // 
            // dataColumn8
            // 
            this.dataColumn8.ColumnName = "TonePeriodCourseLD";
            this.dataColumn8.DataType = typeof(byte);
            // 
            // dataColumn9
            // 
            this.dataColumn9.ColumnName = "TonePeriodCourseLE";
            this.dataColumn9.DataType = typeof(byte);
            // 
            // dataColumn10
            // 
            this.dataColumn10.ColumnName = "TonePeriodCourseLF";
            this.dataColumn10.DataType = typeof(byte);
            // 
            // dataColumn11
            // 
            this.dataColumn11.ColumnName = "TonePeriodFineLA";
            this.dataColumn11.DataType = typeof(byte);
            // 
            // dataColumn12
            // 
            this.dataColumn12.ColumnName = "TonePeriodFineLB";
            this.dataColumn12.DataType = typeof(byte);
            // 
            // dataColumn13
            // 
            this.dataColumn13.ColumnName = "TonePeriodFineLC";
            this.dataColumn13.DataType = typeof(byte);
            // 
            // dataColumn14
            // 
            this.dataColumn14.ColumnName = "TonePeriodFineLD";
            this.dataColumn14.DataType = typeof(byte);
            // 
            // dataColumn15
            // 
            this.dataColumn15.ColumnName = "TonePeriodFineLE";
            this.dataColumn15.DataType = typeof(byte);
            // 
            // dataColumn16
            // 
            this.dataColumn16.ColumnName = "TonePeriodFineLF";
            this.dataColumn16.DataType = typeof(byte);
            // 
            // dataColumn17
            // 
            this.dataColumn17.ColumnName = "VolumeLA";
            this.dataColumn17.DataType = typeof(byte);
            // 
            // dataColumn18
            // 
            this.dataColumn18.ColumnName = "VolumeLB";
            this.dataColumn18.DataType = typeof(byte);
            // 
            // dataColumn19
            // 
            this.dataColumn19.ColumnName = "VolumeLC";
            this.dataColumn19.DataType = typeof(byte);
            // 
            // dataColumn20
            // 
            this.dataColumn20.ColumnName = "VolumeLD";
            this.dataColumn20.DataType = typeof(byte);
            // 
            // dataColumn21
            // 
            this.dataColumn21.ColumnName = "VolumeLE";
            this.dataColumn21.DataType = typeof(byte);
            // 
            // dataColumn22
            // 
            this.dataColumn22.ColumnName = "VolumeLF";
            this.dataColumn22.DataType = typeof(byte);
            // 
            // dataColumn23
            // 
            this.dataColumn23.ColumnName = "TonePeriodCourseRA";
            this.dataColumn23.DataType = typeof(byte);
            // 
            // dataColumn24
            // 
            this.dataColumn24.ColumnName = "TonePeriodCourseRB";
            this.dataColumn24.DataType = typeof(byte);
            // 
            // dataColumn25
            // 
            this.dataColumn25.ColumnName = "TonePeriodCourseRC";
            this.dataColumn25.DataType = typeof(byte);
            // 
            // dataColumn26
            // 
            this.dataColumn26.ColumnName = "TonePeriodCourseRD";
            this.dataColumn26.DataType = typeof(byte);
            // 
            // dataColumn27
            // 
            this.dataColumn27.ColumnName = "TonePeriodCourseRE";
            this.dataColumn27.DataType = typeof(byte);
            // 
            // dataColumn28
            // 
            this.dataColumn28.ColumnName = "TonePeriodCourseRF";
            this.dataColumn28.DataType = typeof(byte);
            // 
            // dataColumn29
            // 
            this.dataColumn29.ColumnName = "TonePeriodFineRA";
            this.dataColumn29.DataType = typeof(byte);
            // 
            // dataColumn30
            // 
            this.dataColumn30.ColumnName = "TonePeriodFineRB";
            this.dataColumn30.DataType = typeof(byte);
            // 
            // dataColumn31
            // 
            this.dataColumn31.ColumnName = "TonePeriodFineRC";
            this.dataColumn31.DataType = typeof(byte);
            // 
            // dataColumn32
            // 
            this.dataColumn32.ColumnName = "TonePeriodFineRD";
            this.dataColumn32.DataType = typeof(byte);
            // 
            // dataColumn33
            // 
            this.dataColumn33.ColumnName = "TonePeriodFineRE";
            this.dataColumn33.DataType = typeof(byte);
            // 
            // dataColumn34
            // 
            this.dataColumn34.ColumnName = "TonePeriodFineRF";
            this.dataColumn34.DataType = typeof(byte);
            // 
            // dataColumn35
            // 
            this.dataColumn35.ColumnName = "VolumeRA";
            this.dataColumn35.DataType = typeof(byte);
            // 
            // dataColumn36
            // 
            this.dataColumn36.ColumnName = "VolumeRB";
            this.dataColumn36.DataType = typeof(byte);
            // 
            // dataColumn37
            // 
            this.dataColumn37.ColumnName = "VolumeRC";
            this.dataColumn37.DataType = typeof(byte);
            // 
            // dataColumn38
            // 
            this.dataColumn38.ColumnName = "VolumeRD";
            this.dataColumn38.DataType = typeof(byte);
            // 
            // dataColumn39
            // 
            this.dataColumn39.ColumnName = "VolumeRE";
            this.dataColumn39.DataType = typeof(byte);
            // 
            // dataColumn40
            // 
            this.dataColumn40.ColumnName = "VolumeRF";
            this.dataColumn40.DataType = typeof(byte);
            // 
            // dataColumn41
            // 
            this.dataColumn41.ColumnName = "NoisePeriodL1";
            this.dataColumn41.DataType = typeof(byte);
            // 
            // dataColumn42
            // 
            this.dataColumn42.ColumnName = "EnvelopePeriodCourseL1";
            this.dataColumn42.DataType = typeof(byte);
            // 
            // dataColumn43
            // 
            this.dataColumn43.ColumnName = "EnvelopePeriodFineL1";
            this.dataColumn43.DataType = typeof(byte);
            // 
            // dataColumn44
            // 
            this.dataColumn44.ColumnName = "EnvelopeShapeCycleL1";
            this.dataColumn44.DataType = typeof(byte);
            // 
            // dataColumn45
            // 
            this.dataColumn45.ColumnName = "EnableLeft1";
            this.dataColumn45.DataType = typeof(byte);
            // 
            // dataColumn46
            // 
            this.dataColumn46.ColumnName = "EnableRight1";
            this.dataColumn46.DataType = typeof(byte);
            // 
            // dataColumn47
            // 
            this.dataColumn47.ColumnName = "EnableLeft2";
            this.dataColumn47.DataType = typeof(byte);
            // 
            // dataColumn48
            // 
            this.dataColumn48.ColumnName = "EnableRight2";
            this.dataColumn48.DataType = typeof(byte);
            // 
            // dataColumn49
            // 
            this.dataColumn49.ColumnName = "NoisePeriodR1";
            this.dataColumn49.DataType = typeof(byte);
            // 
            // dataColumn50
            // 
            this.dataColumn50.ColumnName = "EnvelopePeriodCourseR1";
            this.dataColumn50.DataType = typeof(byte);
            // 
            // dataColumn51
            // 
            this.dataColumn51.ColumnName = "EnvelopePeriodFineR1";
            this.dataColumn51.DataType = typeof(byte);
            // 
            // dataColumn52
            // 
            this.dataColumn52.ColumnName = "EnvelopeShapeCycleR1";
            this.dataColumn52.DataType = typeof(byte);
            // 
            // dataColumn53
            // 
            this.dataColumn53.ColumnName = "NoisePeriodL2";
            this.dataColumn53.DataType = typeof(byte);
            // 
            // dataColumn54
            // 
            this.dataColumn54.ColumnName = "EnvelopePeriodCourseL2";
            this.dataColumn54.DataType = typeof(byte);
            // 
            // dataColumn55
            // 
            this.dataColumn55.ColumnName = "EnvelopePeriodFineL2";
            this.dataColumn55.DataType = typeof(byte);
            // 
            // dataColumn56
            // 
            this.dataColumn56.ColumnName = "EnvelopeShapeCycleL2";
            this.dataColumn56.DataType = typeof(byte);
            // 
            // dataColumn57
            // 
            this.dataColumn57.ColumnName = "NoisePeriodR2";
            this.dataColumn57.DataType = typeof(byte);
            // 
            // dataColumn58
            // 
            this.dataColumn58.ColumnName = "EnvelopePeriodCourseR2";
            this.dataColumn58.DataType = typeof(byte);
            // 
            // dataColumn59
            // 
            this.dataColumn59.ColumnName = "EnvelopePeriodFineR2";
            this.dataColumn59.DataType = typeof(byte);
            // 
            // dataColumn60
            // 
            this.dataColumn60.ColumnName = "EnvelopeShapeCycleR2";
            this.dataColumn60.DataType = typeof(byte);
            // 
            // dataColumn61
            // 
            this.dataColumn61.ColumnName = "HoldTicks";
            this.dataColumn61.DataType = typeof(byte);
            // 
            // ExpandDataViewButton
            // 
            this.ExpandDataViewButton.Location = new System.Drawing.Point(1592, 84);
            this.ExpandDataViewButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ExpandDataViewButton.Name = "ExpandDataViewButton";
            this.ExpandDataViewButton.Size = new System.Drawing.Size(50, 39);
            this.ExpandDataViewButton.TabIndex = 77;
            this.ExpandDataViewButton.Text = ">>>";
            this.ExpandDataViewButton.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1270, 33);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 17);
            this.label27.TabIndex = 78;
            this.label27.Text = "with delay of";
            // 
            // nudDelay
            // 
            this.nudDelay.Location = new System.Drawing.Point(1362, 27);
            this.nudDelay.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.nudDelay.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.nudDelay.Name = "nudDelay";
            this.nudDelay.Size = new System.Drawing.Size(62, 22);
            this.nudDelay.TabIndex = 100;
            this.nudDelay.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(1180, 84);
            this.SaveButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(54, 39);
            this.SaveButton.TabIndex = 101;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            // 
            // LoadButton
            // 
            this.LoadButton.Location = new System.Drawing.Point(1240, 84);
            this.LoadButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.LoadButton.Name = "LoadButton";
            this.LoadButton.Size = new System.Drawing.Size(54, 39);
            this.LoadButton.TabIndex = 102;
            this.LoadButton.Text = "Load";
            this.LoadButton.UseVisualStyleBackColor = true;
            // 
            // PlayButton
            // 
            this.PlayButton.Location = new System.Drawing.Point(1458, 84);
            this.PlayButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PlayButton.Name = "PlayButton";
            this.PlayButton.Size = new System.Drawing.Size(94, 39);
            this.PlayButton.TabIndex = 103;
            this.PlayButton.Text = "Play";
            this.PlayButton.UseVisualStyleBackColor = true;
            this.PlayButton.Click += new System.EventHandler(this.PlayButton_Click);
            // 
            // CreateAssemblyButton
            // 
            this.CreateAssemblyButton.Location = new System.Drawing.Point(1342, 84);
            this.CreateAssemblyButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.CreateAssemblyButton.Name = "CreateAssemblyButton";
            this.CreateAssemblyButton.Size = new System.Drawing.Size(82, 39);
            this.CreateAssemblyButton.TabIndex = 104;
            this.CreateAssemblyButton.Text = "Assembly";
            this.CreateAssemblyButton.UseVisualStyleBackColor = true;
            // 
            // midiButton
            // 
            this.midiButton.Location = new System.Drawing.Point(996, 19);
            this.midiButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.midiButton.Name = "midiButton";
            this.midiButton.Size = new System.Drawing.Size(71, 39);
            this.midiButton.TabIndex = 105;
            this.midiButton.Text = "&MIDI";
            this.midiButton.UseVisualStyleBackColor = true;
            this.midiButton.Click += new System.EventHandler(this.midiButton_Click);
            // 
            // SoundForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1899, 653);
            this.Controls.Add(this.midiButton);
            this.Controls.Add(this.CreateAssemblyButton);
            this.Controls.Add(this.PlayButton);
            this.Controls.Add(this.LoadButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.nudDelay);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ExpandDataViewButton);
            this.Controls.Add(this.dgvSequence);
            this.Controls.Add(this.AddToSequenceButton);
            this.Controls.Add(this.chkHex);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.connectionSpeedLabel);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.connectionStatusPictureBox);
            this.Controls.Add(this.PortsCombo);
            this.Controls.Add(this.ConnectButton);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.startButton);
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "SoundForm";
            this.Text = "6502 Dynamic Sound Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SoundForm_FormClosing);
            this.Load += new System.EventHandler(this.SoundForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionStatusPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseLF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineLF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodCourseRA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTonePeriodFineRA)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineL2)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeLF)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVolumeRF)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineR2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudNoisePeriodR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodCourseR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudEnvelopePeriodFineR1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSequence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SequenceDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDelay)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nudTonePeriodFineLA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseLA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudNoisePeriodL1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodCourseL1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodFineL1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkContL1;
        private System.Windows.Forms.CheckBox chkAttL1;
        private System.Windows.Forms.CheckBox chkHoldL1;
        private System.Windows.Forms.CheckBox chkAltL1;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label connectionSpeedLabel;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.PictureBox connectionStatusPictureBox;
        private System.Windows.Forms.ComboBox PortsCombo;
        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseLB;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineLB;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseLC;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineLC;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseLD;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineLD;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseLE;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineLE;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseLF;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineLF;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseRF;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineRF;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseRE;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineRE;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseRD;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineRD;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseRC;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineRC;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseRB;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineRB;
        private System.Windows.Forms.NumericUpDown nudTonePeriodCourseRA;
        private System.Windows.Forms.NumericUpDown nudTonePeriodFineRA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown nudVolumeLA;
        private System.Windows.Forms.NumericUpDown nudVolumeLB;
        private System.Windows.Forms.NumericUpDown nudVolumeLC;
        private System.Windows.Forms.NumericUpDown nudVolumeLD;
        private System.Windows.Forms.NumericUpDown nudVolumeLE;
        private System.Windows.Forms.NumericUpDown nudVolumeLF;
        private System.Windows.Forms.NumericUpDown nudVolumeRA;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown nudVolumeRB;
        private System.Windows.Forms.NumericUpDown nudVolumeRC;
        private System.Windows.Forms.NumericUpDown nudVolumeRD;
        private System.Windows.Forms.NumericUpDown nudVolumeRE;
        private System.Windows.Forms.NumericUpDown nudVolumeRF;
        private System.Windows.Forms.Timer enableUpdateButtonTimer;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox noiseLF;
        private System.Windows.Forms.CheckBox toneLF;
        private System.Windows.Forms.CheckBox noiseLE;
        private System.Windows.Forms.CheckBox toneLE;
        private System.Windows.Forms.CheckBox noiseLD;
        private System.Windows.Forms.CheckBox toneLD;
        private System.Windows.Forms.CheckBox noiseLC;
        private System.Windows.Forms.CheckBox toneLC;
        private System.Windows.Forms.CheckBox noiseLB;
        private System.Windows.Forms.CheckBox toneLB;
        private System.Windows.Forms.CheckBox noiseLA;
        private System.Windows.Forms.CheckBox toneLA;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox noiseRF;
        private System.Windows.Forms.CheckBox toneRF;
        private System.Windows.Forms.CheckBox noiseRE;
        private System.Windows.Forms.CheckBox toneRE;
        private System.Windows.Forms.CheckBox noiseRD;
        private System.Windows.Forms.CheckBox toneRD;
        private System.Windows.Forms.CheckBox noiseRC;
        private System.Windows.Forms.CheckBox toneRC;
        private System.Windows.Forms.CheckBox noiseRB;
        private System.Windows.Forms.CheckBox toneRB;
        private System.Windows.Forms.CheckBox noiseRA;
        private System.Windows.Forms.CheckBox toneRA;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cboVolFixedVarLA;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cboVolFixedVarLF;
        private System.Windows.Forms.ComboBox cboVolFixedVarLE;
        private System.Windows.Forms.ComboBox cboVolFixedVarLD;
        private System.Windows.Forms.ComboBox cboVolFixedVarLC;
        private System.Windows.Forms.ComboBox cboVolFixedVarLB;
        private System.Windows.Forms.ComboBox cboVolFixedVarRF;
        private System.Windows.Forms.ComboBox cboVolFixedVarRE;
        private System.Windows.Forms.ComboBox cboVolFixedVarRD;
        private System.Windows.Forms.ComboBox cboVolFixedVarRC;
        private System.Windows.Forms.ComboBox cboVolFixedVarRB;
        private System.Windows.Forms.ComboBox cboVolFixedVarRA;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown nudNoisePeriodL2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodCourseL2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodFineL2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.CheckBox chkContL2;
        private System.Windows.Forms.CheckBox chkAttL2;
        private System.Windows.Forms.CheckBox chkAltL2;
        private System.Windows.Forms.CheckBox chkHoldL2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.NumericUpDown nudNoisePeriodR2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodCourseR2;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodFineR2;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.CheckBox chkContR2;
        private System.Windows.Forms.CheckBox chkAttR2;
        private System.Windows.Forms.CheckBox chkAltR2;
        private System.Windows.Forms.CheckBox chkHoldR2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.NumericUpDown nudNoisePeriodR1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodCourseR1;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.NumericUpDown nudEnvelopePeriodFineR1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.CheckBox chkContR1;
        private System.Windows.Forms.CheckBox chkAttR1;
        private System.Windows.Forms.CheckBox chkAltR1;
        private System.Windows.Forms.CheckBox chkHoldR1;
        private System.Windows.Forms.CheckBox chkHex;
        private System.Windows.Forms.Button AddToSequenceButton;
        private System.Windows.Forms.DataGridView dgvSequence;
        private System.Windows.Forms.Button ExpandDataViewButton;
        private System.Data.DataSet SequenceDataSet;
        private System.Data.DataTable dataTable1;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Data.DataColumn dataColumn3;
        private System.Data.DataColumn dataColumn4;
        private System.Data.DataColumn dataColumn5;
        private System.Data.DataColumn dataColumn6;
        private System.Data.DataColumn dataColumn7;
        private System.Data.DataColumn dataColumn8;
        private System.Data.DataColumn dataColumn9;
        private System.Data.DataColumn dataColumn10;
        private System.Data.DataColumn dataColumn11;
        private System.Data.DataColumn dataColumn12;
        private System.Data.DataColumn dataColumn13;
        private System.Data.DataColumn dataColumn14;
        private System.Data.DataColumn dataColumn15;
        private System.Data.DataColumn dataColumn16;
        private System.Data.DataColumn dataColumn17;
        private System.Data.DataColumn dataColumn18;
        private System.Data.DataColumn dataColumn19;
        private System.Data.DataColumn dataColumn20;
        private System.Data.DataColumn dataColumn21;
        private System.Data.DataColumn dataColumn22;
        private System.Data.DataColumn dataColumn23;
        private System.Data.DataColumn dataColumn24;
        private System.Data.DataColumn dataColumn25;
        private System.Data.DataColumn dataColumn26;
        private System.Data.DataColumn dataColumn27;
        private System.Data.DataColumn dataColumn28;
        private System.Data.DataColumn dataColumn29;
        private System.Data.DataColumn dataColumn30;
        private System.Data.DataColumn dataColumn31;
        private System.Data.DataColumn dataColumn32;
        private System.Data.DataColumn dataColumn33;
        private System.Data.DataColumn dataColumn34;
        private System.Data.DataColumn dataColumn35;
        private System.Data.DataColumn dataColumn36;
        private System.Data.DataColumn dataColumn37;
        private System.Data.DataColumn dataColumn38;
        private System.Data.DataColumn dataColumn39;
        private System.Data.DataColumn dataColumn40;
        private System.Data.DataColumn dataColumn41;
        private System.Data.DataColumn dataColumn42;
        private System.Data.DataColumn dataColumn43;
        private System.Data.DataColumn dataColumn44;
        private System.Data.DataColumn dataColumn45;
        private System.Data.DataColumn dataColumn46;
        private System.Data.DataColumn dataColumn47;
        private System.Data.DataColumn dataColumn48;
        private System.Data.DataColumn dataColumn49;
        private System.Data.DataColumn dataColumn50;
        private System.Data.DataColumn dataColumn51;
        private System.Data.DataColumn dataColumn52;
        private System.Data.DataColumn dataColumn53;
        private System.Data.DataColumn dataColumn54;
        private System.Data.DataColumn dataColumn55;
        private System.Data.DataColumn dataColumn56;
        private System.Data.DataColumn dataColumn57;
        private System.Data.DataColumn dataColumn58;
        private System.Data.DataColumn dataColumn59;
        private System.Data.DataColumn dataColumn60;
        private System.Data.DataColumn dataColumn61;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown nudDelay;
        private System.Windows.Forms.DataGridViewTextBoxColumn command1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn command2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn command3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn command4DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseLADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseLBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseLCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseLDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseLEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseLFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineLADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineLBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineLCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineLDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineLEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineLFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeLADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeLBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeLCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeLDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeLEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeLFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseRADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseRBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseRCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseRDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodCourseRFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineRADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineRBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineRCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineRDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tonePeriodFineRFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeRADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeRBDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeRCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeRDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeREDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn volumeRFDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noisePeriodL1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodCourseL1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodFineL1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopeShapeCycleL1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enableLeft1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enableRight1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enableLeft2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn enableRight2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noisePeriodR1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodCourseR1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodFineR1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopeShapeCycleR1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noisePeriodL2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodCourseL2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodFineL2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopeShapeCycleL2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noisePeriodR2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodCourseR2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopePeriodFineR2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn envelopeShapeCycleR2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn holdTicksDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button LoadButton;
        private System.Windows.Forms.Button PlayButton;
        private System.Windows.Forms.Button CreateAssemblyButton;
        private System.Windows.Forms.Button midiButton;
    }
}