﻿using PureMidi.CoreMmSystem.MidiIO.Data;

namespace PureMidi.CoreMmSystem.MidiIO
{
    public delegate void MidiMessageEvent(MidiEvent ev);
}