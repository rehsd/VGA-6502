namespace PureMidi.CoreMmSystem.MidiIO.Definitions
{
    public enum EShortMessageType
    {
        
    }
}