﻿
namespace Font_ROM_Builder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.outTextBox = new System.Windows.Forms.TextBox();
            this.copyToClipboardButton = new System.Windows.Forms.Button();
            this.pbPanel = new System.Windows.Forms.Panel();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.pictureBox26 = new System.Windows.Forms.PictureBox();
            this.pictureBox27 = new System.Windows.Forms.PictureBox();
            this.pictureBox28 = new System.Windows.Forms.PictureBox();
            this.pictureBox29 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pb75 = new System.Windows.Forms.PictureBox();
            this.pb74 = new System.Windows.Forms.PictureBox();
            this.pb73 = new System.Windows.Forms.PictureBox();
            this.pb72 = new System.Windows.Forms.PictureBox();
            this.pb71 = new System.Windows.Forms.PictureBox();
            this.pb65 = new System.Windows.Forms.PictureBox();
            this.pb64 = new System.Windows.Forms.PictureBox();
            this.pb63 = new System.Windows.Forms.PictureBox();
            this.pb62 = new System.Windows.Forms.PictureBox();
            this.pb61 = new System.Windows.Forms.PictureBox();
            this.pb55 = new System.Windows.Forms.PictureBox();
            this.pb54 = new System.Windows.Forms.PictureBox();
            this.pb53 = new System.Windows.Forms.PictureBox();
            this.pb52 = new System.Windows.Forms.PictureBox();
            this.pb51 = new System.Windows.Forms.PictureBox();
            this.pb45 = new System.Windows.Forms.PictureBox();
            this.pb44 = new System.Windows.Forms.PictureBox();
            this.pb43 = new System.Windows.Forms.PictureBox();
            this.pb42 = new System.Windows.Forms.PictureBox();
            this.pb41 = new System.Windows.Forms.PictureBox();
            this.pb35 = new System.Windows.Forms.PictureBox();
            this.pb34 = new System.Windows.Forms.PictureBox();
            this.pb33 = new System.Windows.Forms.PictureBox();
            this.pb32 = new System.Windows.Forms.PictureBox();
            this.pb31 = new System.Windows.Forms.PictureBox();
            this.pb25 = new System.Windows.Forms.PictureBox();
            this.pb24 = new System.Windows.Forms.PictureBox();
            this.pb23 = new System.Windows.Forms.PictureBox();
            this.pb22 = new System.Windows.Forms.PictureBox();
            this.pb21 = new System.Windows.Forms.PictureBox();
            this.pb15 = new System.Windows.Forms.PictureBox();
            this.pb14 = new System.Windows.Forms.PictureBox();
            this.pb13 = new System.Windows.Forms.PictureBox();
            this.pb12 = new System.Windows.Forms.PictureBox();
            this.pb11 = new System.Windows.Forms.PictureBox();
            this.includeCommentHeaderCheckbox = new System.Windows.Forms.CheckBox();
            this.resetButton = new System.Windows.Forms.Button();
            this.outputTypeCombo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pbPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb11)).BeginInit();
            this.SuspendLayout();
            // 
            // outTextBox
            // 
            this.outTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outTextBox.Location = new System.Drawing.Point(286, 36);
            this.outTextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.outTextBox.Multiline = true;
            this.outTextBox.Name = "outTextBox";
            this.outTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.outTextBox.Size = new System.Drawing.Size(606, 163);
            this.outTextBox.TabIndex = 35;
            // 
            // copyToClipboardButton
            // 
            this.copyToClipboardButton.Location = new System.Drawing.Point(200, 36);
            this.copyToClipboardButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.copyToClipboardButton.Name = "copyToClipboardButton";
            this.copyToClipboardButton.Size = new System.Drawing.Size(69, 166);
            this.copyToClipboardButton.TabIndex = 42;
            this.copyToClipboardButton.Text = "&Copy\r\nto \r\nClipboard";
            this.copyToClipboardButton.UseVisualStyleBackColor = true;
            this.copyToClipboardButton.Click += new System.EventHandler(this.copyToClipboardButton_Click);
            // 
            // pbPanel
            // 
            this.pbPanel.Controls.Add(this.pictureBox22);
            this.pbPanel.Controls.Add(this.pictureBox23);
            this.pbPanel.Controls.Add(this.pictureBox24);
            this.pbPanel.Controls.Add(this.pictureBox25);
            this.pbPanel.Controls.Add(this.pictureBox26);
            this.pbPanel.Controls.Add(this.pictureBox27);
            this.pbPanel.Controls.Add(this.pictureBox28);
            this.pbPanel.Controls.Add(this.pictureBox29);
            this.pbPanel.Controls.Add(this.pictureBox15);
            this.pbPanel.Controls.Add(this.pictureBox16);
            this.pbPanel.Controls.Add(this.pictureBox17);
            this.pbPanel.Controls.Add(this.pictureBox18);
            this.pbPanel.Controls.Add(this.pictureBox19);
            this.pbPanel.Controls.Add(this.pictureBox20);
            this.pbPanel.Controls.Add(this.pictureBox21);
            this.pbPanel.Controls.Add(this.pictureBox8);
            this.pbPanel.Controls.Add(this.pictureBox9);
            this.pbPanel.Controls.Add(this.pictureBox10);
            this.pbPanel.Controls.Add(this.pictureBox11);
            this.pbPanel.Controls.Add(this.pictureBox12);
            this.pbPanel.Controls.Add(this.pictureBox13);
            this.pbPanel.Controls.Add(this.pictureBox14);
            this.pbPanel.Controls.Add(this.pictureBox1);
            this.pbPanel.Controls.Add(this.pictureBox2);
            this.pbPanel.Controls.Add(this.pictureBox3);
            this.pbPanel.Controls.Add(this.pictureBox4);
            this.pbPanel.Controls.Add(this.pictureBox5);
            this.pbPanel.Controls.Add(this.pictureBox6);
            this.pbPanel.Controls.Add(this.pictureBox7);
            this.pbPanel.Controls.Add(this.pb75);
            this.pbPanel.Controls.Add(this.pb74);
            this.pbPanel.Controls.Add(this.pb73);
            this.pbPanel.Controls.Add(this.pb72);
            this.pbPanel.Controls.Add(this.pb71);
            this.pbPanel.Controls.Add(this.pb65);
            this.pbPanel.Controls.Add(this.pb64);
            this.pbPanel.Controls.Add(this.pb63);
            this.pbPanel.Controls.Add(this.pb62);
            this.pbPanel.Controls.Add(this.pb61);
            this.pbPanel.Controls.Add(this.pb55);
            this.pbPanel.Controls.Add(this.pb54);
            this.pbPanel.Controls.Add(this.pb53);
            this.pbPanel.Controls.Add(this.pb52);
            this.pbPanel.Controls.Add(this.pb51);
            this.pbPanel.Controls.Add(this.pb45);
            this.pbPanel.Controls.Add(this.pb44);
            this.pbPanel.Controls.Add(this.pb43);
            this.pbPanel.Controls.Add(this.pb42);
            this.pbPanel.Controls.Add(this.pb41);
            this.pbPanel.Controls.Add(this.pb35);
            this.pbPanel.Controls.Add(this.pb34);
            this.pbPanel.Controls.Add(this.pb33);
            this.pbPanel.Controls.Add(this.pb32);
            this.pbPanel.Controls.Add(this.pb31);
            this.pbPanel.Controls.Add(this.pb25);
            this.pbPanel.Controls.Add(this.pb24);
            this.pbPanel.Controls.Add(this.pb23);
            this.pbPanel.Controls.Add(this.pb22);
            this.pbPanel.Controls.Add(this.pb21);
            this.pbPanel.Controls.Add(this.pb15);
            this.pbPanel.Controls.Add(this.pb14);
            this.pbPanel.Controls.Add(this.pb13);
            this.pbPanel.Controls.Add(this.pb12);
            this.pbPanel.Controls.Add(this.pb11);
            this.pbPanel.Location = new System.Drawing.Point(9, 10);
            this.pbPanel.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pbPanel.Name = "pbPanel";
            this.pbPanel.Size = new System.Drawing.Size(178, 196);
            this.pbPanel.TabIndex = 72;
            // 
            // pictureBox22
            // 
            this.pictureBox22.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox22.Location = new System.Drawing.Point(160, 173);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(18, 19);
            this.pictureBox22.TabIndex = 135;
            this.pictureBox22.TabStop = false;
            // 
            // pictureBox23
            // 
            this.pictureBox23.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox23.Location = new System.Drawing.Point(137, 173);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(18, 19);
            this.pictureBox23.TabIndex = 134;
            this.pictureBox23.TabStop = false;
            // 
            // pictureBox24
            // 
            this.pictureBox24.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox24.Location = new System.Drawing.Point(115, 173);
            this.pictureBox24.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(18, 19);
            this.pictureBox24.TabIndex = 133;
            this.pictureBox24.TabStop = false;
            // 
            // pictureBox25
            // 
            this.pictureBox25.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox25.Location = new System.Drawing.Point(92, 173);
            this.pictureBox25.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(18, 19);
            this.pictureBox25.TabIndex = 132;
            this.pictureBox25.TabStop = false;
            // 
            // pictureBox26
            // 
            this.pictureBox26.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox26.Location = new System.Drawing.Point(70, 173);
            this.pictureBox26.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox26.Name = "pictureBox26";
            this.pictureBox26.Size = new System.Drawing.Size(18, 19);
            this.pictureBox26.TabIndex = 131;
            this.pictureBox26.TabStop = false;
            // 
            // pictureBox27
            // 
            this.pictureBox27.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox27.Location = new System.Drawing.Point(47, 173);
            this.pictureBox27.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox27.Name = "pictureBox27";
            this.pictureBox27.Size = new System.Drawing.Size(18, 19);
            this.pictureBox27.TabIndex = 130;
            this.pictureBox27.TabStop = false;
            // 
            // pictureBox28
            // 
            this.pictureBox28.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox28.Location = new System.Drawing.Point(25, 173);
            this.pictureBox28.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox28.Name = "pictureBox28";
            this.pictureBox28.Size = new System.Drawing.Size(18, 19);
            this.pictureBox28.TabIndex = 129;
            this.pictureBox28.TabStop = false;
            // 
            // pictureBox29
            // 
            this.pictureBox29.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox29.Location = new System.Drawing.Point(2, 173);
            this.pictureBox29.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox29.Name = "pictureBox29";
            this.pictureBox29.Size = new System.Drawing.Size(18, 19);
            this.pictureBox29.TabIndex = 128;
            this.pictureBox29.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox15.Location = new System.Drawing.Point(160, 149);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(18, 19);
            this.pictureBox15.TabIndex = 127;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox16.Location = new System.Drawing.Point(160, 124);
            this.pictureBox16.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(18, 19);
            this.pictureBox16.TabIndex = 126;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox17.Location = new System.Drawing.Point(160, 100);
            this.pictureBox17.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(18, 19);
            this.pictureBox17.TabIndex = 125;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox18.Location = new System.Drawing.Point(160, 75);
            this.pictureBox18.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(18, 19);
            this.pictureBox18.TabIndex = 124;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox19.Location = new System.Drawing.Point(160, 51);
            this.pictureBox19.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(18, 19);
            this.pictureBox19.TabIndex = 123;
            this.pictureBox19.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox20.Location = new System.Drawing.Point(160, 27);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(18, 19);
            this.pictureBox20.TabIndex = 122;
            this.pictureBox20.TabStop = false;
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox21.Location = new System.Drawing.Point(160, 3);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(18, 19);
            this.pictureBox21.TabIndex = 121;
            this.pictureBox21.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox8.Location = new System.Drawing.Point(137, 149);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(18, 19);
            this.pictureBox8.TabIndex = 120;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox9.Location = new System.Drawing.Point(137, 124);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(18, 19);
            this.pictureBox9.TabIndex = 119;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox10.Location = new System.Drawing.Point(137, 100);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(18, 19);
            this.pictureBox10.TabIndex = 118;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox11.Location = new System.Drawing.Point(137, 75);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(18, 19);
            this.pictureBox11.TabIndex = 117;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox12.Location = new System.Drawing.Point(137, 51);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(18, 19);
            this.pictureBox12.TabIndex = 116;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox13.Location = new System.Drawing.Point(137, 27);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(18, 19);
            this.pictureBox13.TabIndex = 115;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox14.Location = new System.Drawing.Point(137, 3);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(18, 19);
            this.pictureBox14.TabIndex = 114;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox1.Location = new System.Drawing.Point(115, 149);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(18, 19);
            this.pictureBox1.TabIndex = 113;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox2.Location = new System.Drawing.Point(115, 124);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(18, 19);
            this.pictureBox2.TabIndex = 112;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox3.Location = new System.Drawing.Point(115, 100);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(18, 19);
            this.pictureBox3.TabIndex = 111;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox4.Location = new System.Drawing.Point(115, 75);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 19);
            this.pictureBox4.TabIndex = 110;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox5.Location = new System.Drawing.Point(115, 51);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 19);
            this.pictureBox5.TabIndex = 109;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox6.Location = new System.Drawing.Point(115, 27);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 19);
            this.pictureBox6.TabIndex = 108;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox7.Location = new System.Drawing.Point(115, 3);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(18, 19);
            this.pictureBox7.TabIndex = 107;
            this.pictureBox7.TabStop = false;
            // 
            // pb75
            // 
            this.pb75.BackColor = System.Drawing.Color.LightGray;
            this.pb75.Location = new System.Drawing.Point(92, 149);
            this.pb75.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb75.Name = "pb75";
            this.pb75.Size = new System.Drawing.Size(18, 19);
            this.pb75.TabIndex = 106;
            this.pb75.TabStop = false;
            // 
            // pb74
            // 
            this.pb74.BackColor = System.Drawing.Color.LightGray;
            this.pb74.Location = new System.Drawing.Point(70, 149);
            this.pb74.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb74.Name = "pb74";
            this.pb74.Size = new System.Drawing.Size(18, 19);
            this.pb74.TabIndex = 105;
            this.pb74.TabStop = false;
            // 
            // pb73
            // 
            this.pb73.BackColor = System.Drawing.Color.LightGray;
            this.pb73.Location = new System.Drawing.Point(47, 149);
            this.pb73.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb73.Name = "pb73";
            this.pb73.Size = new System.Drawing.Size(18, 19);
            this.pb73.TabIndex = 104;
            this.pb73.TabStop = false;
            // 
            // pb72
            // 
            this.pb72.BackColor = System.Drawing.Color.LightGray;
            this.pb72.Location = new System.Drawing.Point(25, 149);
            this.pb72.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb72.Name = "pb72";
            this.pb72.Size = new System.Drawing.Size(18, 19);
            this.pb72.TabIndex = 103;
            this.pb72.TabStop = false;
            // 
            // pb71
            // 
            this.pb71.BackColor = System.Drawing.Color.LightGray;
            this.pb71.Location = new System.Drawing.Point(2, 149);
            this.pb71.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb71.Name = "pb71";
            this.pb71.Size = new System.Drawing.Size(18, 19);
            this.pb71.TabIndex = 102;
            this.pb71.TabStop = false;
            // 
            // pb65
            // 
            this.pb65.BackColor = System.Drawing.Color.LightGray;
            this.pb65.Location = new System.Drawing.Point(92, 124);
            this.pb65.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb65.Name = "pb65";
            this.pb65.Size = new System.Drawing.Size(18, 19);
            this.pb65.TabIndex = 101;
            this.pb65.TabStop = false;
            // 
            // pb64
            // 
            this.pb64.BackColor = System.Drawing.Color.LightGray;
            this.pb64.Location = new System.Drawing.Point(70, 124);
            this.pb64.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb64.Name = "pb64";
            this.pb64.Size = new System.Drawing.Size(18, 19);
            this.pb64.TabIndex = 100;
            this.pb64.TabStop = false;
            // 
            // pb63
            // 
            this.pb63.BackColor = System.Drawing.Color.LightGray;
            this.pb63.Location = new System.Drawing.Point(47, 124);
            this.pb63.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb63.Name = "pb63";
            this.pb63.Size = new System.Drawing.Size(18, 19);
            this.pb63.TabIndex = 99;
            this.pb63.TabStop = false;
            // 
            // pb62
            // 
            this.pb62.BackColor = System.Drawing.Color.LightGray;
            this.pb62.Location = new System.Drawing.Point(25, 124);
            this.pb62.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb62.Name = "pb62";
            this.pb62.Size = new System.Drawing.Size(18, 19);
            this.pb62.TabIndex = 98;
            this.pb62.TabStop = false;
            // 
            // pb61
            // 
            this.pb61.BackColor = System.Drawing.Color.LightGray;
            this.pb61.Location = new System.Drawing.Point(2, 124);
            this.pb61.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb61.Name = "pb61";
            this.pb61.Size = new System.Drawing.Size(18, 19);
            this.pb61.TabIndex = 97;
            this.pb61.TabStop = false;
            // 
            // pb55
            // 
            this.pb55.BackColor = System.Drawing.Color.LightGray;
            this.pb55.Location = new System.Drawing.Point(92, 100);
            this.pb55.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb55.Name = "pb55";
            this.pb55.Size = new System.Drawing.Size(18, 19);
            this.pb55.TabIndex = 96;
            this.pb55.TabStop = false;
            // 
            // pb54
            // 
            this.pb54.BackColor = System.Drawing.Color.LightGray;
            this.pb54.Location = new System.Drawing.Point(70, 100);
            this.pb54.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb54.Name = "pb54";
            this.pb54.Size = new System.Drawing.Size(18, 19);
            this.pb54.TabIndex = 95;
            this.pb54.TabStop = false;
            // 
            // pb53
            // 
            this.pb53.BackColor = System.Drawing.Color.LightGray;
            this.pb53.Location = new System.Drawing.Point(47, 100);
            this.pb53.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb53.Name = "pb53";
            this.pb53.Size = new System.Drawing.Size(18, 19);
            this.pb53.TabIndex = 94;
            this.pb53.TabStop = false;
            // 
            // pb52
            // 
            this.pb52.BackColor = System.Drawing.Color.LightGray;
            this.pb52.Location = new System.Drawing.Point(25, 100);
            this.pb52.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb52.Name = "pb52";
            this.pb52.Size = new System.Drawing.Size(18, 19);
            this.pb52.TabIndex = 93;
            this.pb52.TabStop = false;
            // 
            // pb51
            // 
            this.pb51.BackColor = System.Drawing.Color.LightGray;
            this.pb51.Location = new System.Drawing.Point(2, 100);
            this.pb51.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb51.Name = "pb51";
            this.pb51.Size = new System.Drawing.Size(18, 19);
            this.pb51.TabIndex = 92;
            this.pb51.TabStop = false;
            // 
            // pb45
            // 
            this.pb45.BackColor = System.Drawing.Color.LightGray;
            this.pb45.Location = new System.Drawing.Point(92, 75);
            this.pb45.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb45.Name = "pb45";
            this.pb45.Size = new System.Drawing.Size(18, 19);
            this.pb45.TabIndex = 91;
            this.pb45.TabStop = false;
            // 
            // pb44
            // 
            this.pb44.BackColor = System.Drawing.Color.LightGray;
            this.pb44.Location = new System.Drawing.Point(70, 75);
            this.pb44.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb44.Name = "pb44";
            this.pb44.Size = new System.Drawing.Size(18, 19);
            this.pb44.TabIndex = 90;
            this.pb44.TabStop = false;
            // 
            // pb43
            // 
            this.pb43.BackColor = System.Drawing.Color.LightGray;
            this.pb43.Location = new System.Drawing.Point(47, 75);
            this.pb43.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb43.Name = "pb43";
            this.pb43.Size = new System.Drawing.Size(18, 19);
            this.pb43.TabIndex = 89;
            this.pb43.TabStop = false;
            // 
            // pb42
            // 
            this.pb42.BackColor = System.Drawing.Color.LightGray;
            this.pb42.Location = new System.Drawing.Point(25, 75);
            this.pb42.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb42.Name = "pb42";
            this.pb42.Size = new System.Drawing.Size(18, 19);
            this.pb42.TabIndex = 88;
            this.pb42.TabStop = false;
            // 
            // pb41
            // 
            this.pb41.BackColor = System.Drawing.Color.LightGray;
            this.pb41.Location = new System.Drawing.Point(2, 75);
            this.pb41.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb41.Name = "pb41";
            this.pb41.Size = new System.Drawing.Size(18, 19);
            this.pb41.TabIndex = 87;
            this.pb41.TabStop = false;
            // 
            // pb35
            // 
            this.pb35.BackColor = System.Drawing.Color.LightGray;
            this.pb35.Location = new System.Drawing.Point(92, 51);
            this.pb35.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb35.Name = "pb35";
            this.pb35.Size = new System.Drawing.Size(18, 19);
            this.pb35.TabIndex = 86;
            this.pb35.TabStop = false;
            // 
            // pb34
            // 
            this.pb34.BackColor = System.Drawing.Color.LightGray;
            this.pb34.Location = new System.Drawing.Point(70, 51);
            this.pb34.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb34.Name = "pb34";
            this.pb34.Size = new System.Drawing.Size(18, 19);
            this.pb34.TabIndex = 85;
            this.pb34.TabStop = false;
            // 
            // pb33
            // 
            this.pb33.BackColor = System.Drawing.Color.LightGray;
            this.pb33.Location = new System.Drawing.Point(47, 51);
            this.pb33.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb33.Name = "pb33";
            this.pb33.Size = new System.Drawing.Size(18, 19);
            this.pb33.TabIndex = 84;
            this.pb33.TabStop = false;
            // 
            // pb32
            // 
            this.pb32.BackColor = System.Drawing.Color.LightGray;
            this.pb32.Location = new System.Drawing.Point(25, 51);
            this.pb32.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb32.Name = "pb32";
            this.pb32.Size = new System.Drawing.Size(18, 19);
            this.pb32.TabIndex = 83;
            this.pb32.TabStop = false;
            // 
            // pb31
            // 
            this.pb31.BackColor = System.Drawing.Color.LightGray;
            this.pb31.Location = new System.Drawing.Point(2, 51);
            this.pb31.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb31.Name = "pb31";
            this.pb31.Size = new System.Drawing.Size(18, 19);
            this.pb31.TabIndex = 82;
            this.pb31.TabStop = false;
            // 
            // pb25
            // 
            this.pb25.BackColor = System.Drawing.Color.LightGray;
            this.pb25.Location = new System.Drawing.Point(92, 27);
            this.pb25.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb25.Name = "pb25";
            this.pb25.Size = new System.Drawing.Size(18, 19);
            this.pb25.TabIndex = 81;
            this.pb25.TabStop = false;
            // 
            // pb24
            // 
            this.pb24.BackColor = System.Drawing.Color.LightGray;
            this.pb24.Location = new System.Drawing.Point(70, 27);
            this.pb24.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb24.Name = "pb24";
            this.pb24.Size = new System.Drawing.Size(18, 19);
            this.pb24.TabIndex = 80;
            this.pb24.TabStop = false;
            // 
            // pb23
            // 
            this.pb23.BackColor = System.Drawing.Color.LightGray;
            this.pb23.Location = new System.Drawing.Point(47, 27);
            this.pb23.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb23.Name = "pb23";
            this.pb23.Size = new System.Drawing.Size(18, 19);
            this.pb23.TabIndex = 79;
            this.pb23.TabStop = false;
            // 
            // pb22
            // 
            this.pb22.BackColor = System.Drawing.Color.LightGray;
            this.pb22.Location = new System.Drawing.Point(25, 27);
            this.pb22.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb22.Name = "pb22";
            this.pb22.Size = new System.Drawing.Size(18, 19);
            this.pb22.TabIndex = 78;
            this.pb22.TabStop = false;
            // 
            // pb21
            // 
            this.pb21.BackColor = System.Drawing.Color.LightGray;
            this.pb21.Location = new System.Drawing.Point(2, 27);
            this.pb21.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb21.Name = "pb21";
            this.pb21.Size = new System.Drawing.Size(18, 19);
            this.pb21.TabIndex = 77;
            this.pb21.TabStop = false;
            // 
            // pb15
            // 
            this.pb15.BackColor = System.Drawing.Color.LightGray;
            this.pb15.Location = new System.Drawing.Point(92, 3);
            this.pb15.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb15.Name = "pb15";
            this.pb15.Size = new System.Drawing.Size(18, 19);
            this.pb15.TabIndex = 76;
            this.pb15.TabStop = false;
            // 
            // pb14
            // 
            this.pb14.BackColor = System.Drawing.Color.LightGray;
            this.pb14.Location = new System.Drawing.Point(70, 3);
            this.pb14.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb14.Name = "pb14";
            this.pb14.Size = new System.Drawing.Size(18, 19);
            this.pb14.TabIndex = 75;
            this.pb14.TabStop = false;
            // 
            // pb13
            // 
            this.pb13.BackColor = System.Drawing.Color.LightGray;
            this.pb13.Location = new System.Drawing.Point(47, 3);
            this.pb13.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb13.Name = "pb13";
            this.pb13.Size = new System.Drawing.Size(18, 19);
            this.pb13.TabIndex = 74;
            this.pb13.TabStop = false;
            // 
            // pb12
            // 
            this.pb12.BackColor = System.Drawing.Color.LightGray;
            this.pb12.Location = new System.Drawing.Point(25, 3);
            this.pb12.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb12.Name = "pb12";
            this.pb12.Size = new System.Drawing.Size(18, 19);
            this.pb12.TabIndex = 73;
            this.pb12.TabStop = false;
            // 
            // pb11
            // 
            this.pb11.BackColor = System.Drawing.Color.LightGray;
            this.pb11.Location = new System.Drawing.Point(2, 3);
            this.pb11.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pb11.Name = "pb11";
            this.pb11.Size = new System.Drawing.Size(18, 19);
            this.pb11.TabIndex = 72;
            this.pb11.TabStop = false;
            // 
            // includeCommentHeaderCheckbox
            // 
            this.includeCommentHeaderCheckbox.AutoSize = true;
            this.includeCommentHeaderCheckbox.Location = new System.Drawing.Point(508, 11);
            this.includeCommentHeaderCheckbox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.includeCommentHeaderCheckbox.Name = "includeCommentHeaderCheckbox";
            this.includeCommentHeaderCheckbox.Size = new System.Drawing.Size(143, 17);
            this.includeCommentHeaderCheckbox.TabIndex = 73;
            this.includeCommentHeaderCheckbox.Text = "Include comment &header";
            this.includeCommentHeaderCheckbox.UseVisualStyleBackColor = true;
            this.includeCommentHeaderCheckbox.CheckedChanged += new System.EventHandler(this.includeCommentHeaderCheckbox_CheckedChanged);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(200, 7);
            this.resetButton.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(69, 23);
            this.resetButton.TabIndex = 74;
            this.resetButton.Text = "&Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // outputTypeCombo
            // 
            this.outputTypeCombo.FormattingEnabled = true;
            this.outputTypeCombo.Items.AddRange(new object[] {
            "6502 Assembly",
            "MicroBlaze C"});
            this.outputTypeCombo.Location = new System.Drawing.Point(337, 10);
            this.outputTypeCombo.Margin = new System.Windows.Forms.Padding(2);
            this.outputTypeCombo.Name = "outputTypeCombo";
            this.outputTypeCombo.Size = new System.Drawing.Size(101, 21);
            this.outputTypeCombo.TabIndex = 75;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(293, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 76;
            this.label1.Text = "Output";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(906, 211);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.outputTypeCombo);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.includeCommentHeaderCheckbox);
            this.Controls.Add(this.pbPanel);
            this.Controls.Add(this.copyToClipboardButton);
            this.Controls.Add(this.outTextBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Font Builder";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pbPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox outTextBox;
        private System.Windows.Forms.Button copyToClipboardButton;
        private System.Windows.Forms.Panel pbPanel;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox24;
        private System.Windows.Forms.PictureBox pictureBox25;
        private System.Windows.Forms.PictureBox pictureBox26;
        private System.Windows.Forms.PictureBox pictureBox27;
        private System.Windows.Forms.PictureBox pictureBox28;
        private System.Windows.Forms.PictureBox pictureBox29;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pb75;
        private System.Windows.Forms.PictureBox pb74;
        private System.Windows.Forms.PictureBox pb73;
        private System.Windows.Forms.PictureBox pb72;
        private System.Windows.Forms.PictureBox pb71;
        private System.Windows.Forms.PictureBox pb65;
        private System.Windows.Forms.PictureBox pb64;
        private System.Windows.Forms.PictureBox pb63;
        private System.Windows.Forms.PictureBox pb62;
        private System.Windows.Forms.PictureBox pb61;
        private System.Windows.Forms.PictureBox pb55;
        private System.Windows.Forms.PictureBox pb54;
        private System.Windows.Forms.PictureBox pb53;
        private System.Windows.Forms.PictureBox pb52;
        private System.Windows.Forms.PictureBox pb51;
        private System.Windows.Forms.PictureBox pb45;
        private System.Windows.Forms.PictureBox pb44;
        private System.Windows.Forms.PictureBox pb43;
        private System.Windows.Forms.PictureBox pb42;
        private System.Windows.Forms.PictureBox pb41;
        private System.Windows.Forms.PictureBox pb35;
        private System.Windows.Forms.PictureBox pb34;
        private System.Windows.Forms.PictureBox pb33;
        private System.Windows.Forms.PictureBox pb32;
        private System.Windows.Forms.PictureBox pb31;
        private System.Windows.Forms.PictureBox pb25;
        private System.Windows.Forms.PictureBox pb24;
        private System.Windows.Forms.PictureBox pb23;
        private System.Windows.Forms.PictureBox pb22;
        private System.Windows.Forms.PictureBox pb21;
        private System.Windows.Forms.PictureBox pb15;
        private System.Windows.Forms.PictureBox pb14;
        private System.Windows.Forms.PictureBox pb13;
        private System.Windows.Forms.PictureBox pb12;
        private System.Windows.Forms.PictureBox pb11;
        private System.Windows.Forms.CheckBox includeCommentHeaderCheckbox;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.ComboBox outputTypeCombo;
        private System.Windows.Forms.Label label1;
    }
}

