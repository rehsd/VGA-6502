﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Font_ROM_Builder
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void pb_Click(object sender, EventArgs e)
        {
            PictureBox pb = (PictureBox)sender;
            if (pb.BackColor == Color.LightGray)
            {
                pb.BackColor = Color.Blue;
            }
            else
            {
                pb.BackColor = Color.LightGray;
            }
            generateCode();
        }

        void generateCode()
        {
            switch (outputTypeCombo.Text)
            {
                case "6502 Assembly":
                    generateAssemblyCode();
                    break;
                case "MicroBlaze C":
                    generateCCode();
                    break;
            }  
        }
        void generateCCode()
        {
            StringBuilder sb = new StringBuilder();
            //if (includeCommentHeaderCheckbox.Checked)
            //{
            //    sb.AppendLine("  ;char:*     ascii:0x**      charmmap_location:0x**");
            //}
            sb.Append("        {");
            sb.Append("{" + getBitChar(pb11) + "," + getBitChar(pb12) + "," + getBitChar(pb13) + "," + getBitChar(pb14) + "," + getBitChar(pb15) + "},");
            sb.Append("{" + getBitChar(pb21) + "," + getBitChar(pb22) + "," + getBitChar(pb23) + "," + getBitChar(pb24) + "," + getBitChar(pb25) + "},");
            sb.Append("{" + getBitChar(pb31) + "," + getBitChar(pb32) + "," + getBitChar(pb33) + "," + getBitChar(pb34) + "," + getBitChar(pb35) + "},");
            sb.Append("{" + getBitChar(pb41) + "," + getBitChar(pb42) + "," + getBitChar(pb43) + "," + getBitChar(pb44) + "," + getBitChar(pb45) + "},");
            sb.Append("{" + getBitChar(pb51) + "," + getBitChar(pb52) + "," + getBitChar(pb53) + "," + getBitChar(pb54) + "," + getBitChar(pb55) + "},");
            sb.Append("{" + getBitChar(pb61) + "," + getBitChar(pb62) + "," + getBitChar(pb63) + "," + getBitChar(pb64) + "," + getBitChar(pb65) + "},");
            sb.Append("{" + getBitChar(pb71) + "," + getBitChar(pb72) + "," + getBitChar(pb73) + "," + getBitChar(pb74) + "," + getBitChar(pb75) + "}");
            sb.Append("},");

            outTextBox.Text = sb.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (Control pbParam in pbPanel.Controls)
            {
                if (pbParam.BackColor == Color.LightGray)
                {
                    PictureBox pb = (PictureBox)pbParam;
                    pb.Click += pb_Click;
                }
            }
        }

        private void generateAssemblyCode()
        {
            StringBuilder sb = new StringBuilder();
            if (includeCommentHeaderCheckbox.Checked)
            {
                sb.AppendLine("  ;char:*     ascii:0x**      charmmap_location:0x**");
            }
            sb.AppendLine("      .byte %" + getBitChar(pb11) + getBitChar(pb12) + getBitChar(pb13) + getBitChar(pb14) + getBitChar(pb15) + "000");
            sb.AppendLine("      .byte %" + getBitChar(pb21) + getBitChar(pb22) + getBitChar(pb23) + getBitChar(pb24) + getBitChar(pb25) + "000");
            sb.AppendLine("      .byte %" + getBitChar(pb31) + getBitChar(pb32) + getBitChar(pb33) + getBitChar(pb34) + getBitChar(pb35) + "000");
            sb.AppendLine("      .byte %" + getBitChar(pb41) + getBitChar(pb42) + getBitChar(pb43) + getBitChar(pb44) + getBitChar(pb45) + "000");
            sb.AppendLine("      .byte %" + getBitChar(pb51) + getBitChar(pb52) + getBitChar(pb53) + getBitChar(pb54) + getBitChar(pb55) + "000");
            sb.AppendLine("      .byte %" + getBitChar(pb61) + getBitChar(pb62) + getBitChar(pb63) + getBitChar(pb64) + getBitChar(pb65) + "000");
            sb.AppendLine("      .byte %" + getBitChar(pb71) + getBitChar(pb72) + getBitChar(pb73) + getBitChar(pb74) + getBitChar(pb75) + "000");
            sb.Append("      .byte %00000000");

            outTextBox.Text = sb.ToString();
        }

        private Char getBitChar(PictureBox pb)
        {
            if (pb.BackColor == Color.LightGray)
            { return '0'; }
            else
            { return '1'; }
        }

        private void copyToClipboardButton_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(outTextBox.Text);
        }

        private void includeCommentHeaderCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            generateCode();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            foreach (Control pbParam in pbPanel.Controls)
            {
                if ((pbParam.BackColor == Color.LightGray) || (pbParam.BackColor == Color.Blue))
                {
                    PictureBox pb = (PictureBox)pbParam;
                    pb.BackColor = Color.LightGray;
                }
            }
            outTextBox.Clear();
        }
    }
}
