﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Configuration;
using System.Management;

namespace Monitor_6502
{
    public partial class SoundForm : Form
    {
        SerialPort myPort;
        const int CONNECTION_RATE = 115200;
        //const int CONNECTION_RATE = 230400;

        void PopulateSerialPorts()
        {
            try
            {
                ManagementObjectCollection mbsList = null;
                ManagementObjectSearcher mbs = new ManagementObjectSearcher("Select DeviceID, Description From Win32_SerialPort");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["DeviceID"].ToString() + ": " + mo["Description"].ToString());
                }

                mbs = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%(COM%' AND Name LIKE '%USB%'");
                mbsList = mbs.Get();

                foreach (ManagementObject mo in mbsList)
                {
                    PortsCombo.Items.Add(mo["Name"].ToString() + ": " + mo["Description"].ToString());
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        public SoundForm()
        {
            InitializeComponent();
        }


        private void ConnectButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (ConnectButton.Text == "&Connect")
                {
                    string s = PortsCombo.SelectedItem.ToString();
                    s = s.Substring(s.IndexOf("COM"), 4);
                    myPort = new SerialPort(s, CONNECTION_RATE);
                    myPort.ReadTimeout = 5000;
                    myPort.WriteTimeout = 5000;
                    myPort.Open();
                    connectionStatusPictureBox.BackColor = Color.Green;
                    System.Threading.Thread.Sleep(1000);
                    myPort.DataReceived += new SerialDataReceivedEventHandler(MyPort_DataReceived);
                    myPort.DiscardInBuffer();
                    connectionSpeedLabel.Text = s + " @ " + myPort.BaudRate.ToString();
                    myPort.DiscardInBuffer();
                    ConnectButton.Text = "&Disconnect";
                    nudTonePeriodCourseLA.Focus();
                    startButton.Enabled = false;
                    stopButton.Enabled = false;
                    enableUpdateButtonTimer.Enabled = true;
                }
                else
                {
                    if (myPort.IsOpen)
                    {
                        myPort.Close();
                    }
                    connectionStatusPictureBox.BackColor = Color.Red;
                    ConnectButton.Text = "&Connect";
                    connectionSpeedLabel.Text = "";
                    startButton.Enabled = false;
                    stopButton.Enabled = false;
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void SoundForm_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateSerialPorts();
                this.Width = 980;
                nudTonePeriodCourseLA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLB.MouseClick += new MouseEventHandler(nud_Enter); 
                nudTonePeriodCourseLC.Enter += new EventHandler(nud_Enter); 
                nudTonePeriodCourseLC.MouseClick += new MouseEventHandler(nud_Enter); 
                nudTonePeriodCourseLD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseLF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseLF.MouseClick += new MouseEventHandler(nud_Enter);

                nudTonePeriodFineLA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineLF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineLF.MouseClick += new MouseEventHandler(nud_Enter);

                nudVolumeLA.Enter += new EventHandler(nud_Enter);
                nudVolumeLA.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLB.Enter += new EventHandler(nud_Enter);
                nudVolumeLB.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLC.Enter += new EventHandler(nud_Enter);
                nudVolumeLC.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLD.Enter += new EventHandler(nud_Enter);
                nudVolumeLD.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLE.Enter += new EventHandler(nud_Enter);
                nudVolumeLE.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeLF.Enter += new EventHandler(nud_Enter);
                nudVolumeLF.MouseClick += new MouseEventHandler(nud_Enter);

                nudTonePeriodCourseRA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodCourseRF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodCourseRF.MouseClick += new MouseEventHandler(nud_Enter);

                nudTonePeriodFineRA.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRA.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRB.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRB.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRC.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRC.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRD.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRD.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRE.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRE.MouseClick += new MouseEventHandler(nud_Enter);
                nudTonePeriodFineRF.Enter += new EventHandler(nud_Enter);
                nudTonePeriodFineRF.MouseClick += new MouseEventHandler(nud_Enter);

                nudVolumeRA.Enter += new EventHandler(nud_Enter);
                nudVolumeRA.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRB.Enter += new EventHandler(nud_Enter);
                nudVolumeRB.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRC.Enter += new EventHandler(nud_Enter);
                nudVolumeRC.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRD.Enter += new EventHandler(nud_Enter);
                nudVolumeRD.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRE.Enter += new EventHandler(nud_Enter);
                nudVolumeRE.MouseClick += new MouseEventHandler(nud_Enter);
                nudVolumeRF.Enter += new EventHandler(nud_Enter);
                nudVolumeRF.MouseClick += new MouseEventHandler(nud_Enter);

                nudNoisePeriodL1.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodL1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseL1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseL1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineL1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineL1.MouseClick += new MouseEventHandler(nud_Enter);

                cboVolFixedVarLA.SelectedIndex = 0;
                cboVolFixedVarLB.SelectedIndex = 0;
                cboVolFixedVarLC.SelectedIndex = 0;
                cboVolFixedVarRA.SelectedIndex = 0;
                cboVolFixedVarRB.SelectedIndex = 0;
                cboVolFixedVarRC.SelectedIndex = 0;

                nudNoisePeriodR1.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodR1.MouseClick += new MouseEventHandler(nud_Enter); 
                nudNoisePeriodL2.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodR2.MouseClick += new MouseEventHandler(nud_Enter); 
                nudNoisePeriodR2.Enter += new EventHandler(nud_Enter);
                nudNoisePeriodR2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseR1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseR1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineR1.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineR1.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseL2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseL2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineL2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineL2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodCourseR2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodCourseR2.MouseClick += new MouseEventHandler(nud_Enter);
                nudEnvelopePeriodFineR2.Enter += new EventHandler(nud_Enter);
                nudEnvelopePeriodFineR2.MouseClick += new MouseEventHandler(nud_Enter);

                chkHex.Checked = true;
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void MyPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (InvokeRequired)
                {
                    this.Invoke(new MethodInvoker(delegate
                    {
                        Byte inByte = (Byte)myPort.ReadByte();
                        
                        //do something here...

                    }));
                }
                else
                {
                    //
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void PortsCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ConnectButton.Enabled = true;

        }

        private void SoundForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (myPort != null && myPort.IsOpen)
                {
                    myPort.Close();
                }
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message, "Ya'...., something failed...");
            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            //raise interrupt on VIA4 CB1
            //start trigger by sending serial data to Nano
            //Nano will then pull CB1 low

            Byte envelopeShapeCycleL1 = 0;
            if (chkContL1.Checked) { envelopeShapeCycleL1 |= 8; }
            if (chkAttL1.Checked) { envelopeShapeCycleL1 |= 4; }
            if (chkAltL1.Checked) { envelopeShapeCycleL1 |= 2; }
            if (chkHoldL1.Checked) { envelopeShapeCycleL1 |= 1; }

            Byte envelopeShapeCycleR1 = 0;
            if (chkContR1.Checked) { envelopeShapeCycleR1 |= 8; }
            if (chkAttR1.Checked) { envelopeShapeCycleR1 |= 4; }
            if (chkAltR1.Checked) { envelopeShapeCycleR1 |= 2; }
            if (chkHoldR1.Checked) { envelopeShapeCycleR1 |= 1; }

            Byte envelopeShapeCycleL2 = 0;
            if (chkContL2.Checked) { envelopeShapeCycleL2 |= 8; }
            if (chkAttL2.Checked) { envelopeShapeCycleL2 |= 4; }
            if (chkAltL2.Checked) { envelopeShapeCycleL2 |= 2; }
            if (chkHoldL2.Checked) { envelopeShapeCycleL2 |= 1; }

            Byte envelopeShapeCycleR2 = 0;
            if (chkContR2.Checked) { envelopeShapeCycleR2 |= 8; }
            if (chkAttR2.Checked) { envelopeShapeCycleR2 |= 4; }
            if (chkAltR2.Checked) { envelopeShapeCycleR2 |= 2; }
            if (chkHoldR2.Checked) { envelopeShapeCycleR2 |= 1; }

            Byte enableLeft1 = 0;
            Byte enableLeft2 = 0;
            Byte enableRight1 = 0;
            Byte enableRight2 = 0;

            //AY1
            if (!toneLA.Checked) { enableLeft1 |= 1; }
            if (!toneLB.Checked) { enableLeft1 |= 2; }
            if (!toneLC.Checked) { enableLeft1 |= 4; }
            if (!noiseLA.Checked) { enableLeft1 |= 8; }
            if (!noiseLB.Checked) { enableLeft1 |= 16; }
            if (!noiseLC.Checked) { enableLeft1 |= 32; }

            //AY2
            if (!toneRA.Checked) { enableRight1 |= 1; }
            if (!toneRB.Checked) { enableRight1 |= 2; }
            if (!toneRC.Checked) { enableRight1 |= 4; }
            if (!noiseRA.Checked) { enableRight1 |= 8; }
            if (!noiseRB.Checked) { enableRight1 |= 16; }
            if (!noiseRC.Checked) { enableRight1 |= 32; }

            //AY3
            if (!toneLD.Checked) { enableLeft2 |= 1; }
            if (!toneLE.Checked) { enableLeft2 |= 2; }
            if (!toneLF.Checked) { enableLeft2 |= 4; }
            if (!noiseLD.Checked) { enableLeft2 |= 8; }
            if (!noiseLE.Checked) { enableLeft2 |= 16; }
            if (!noiseLF.Checked) { enableLeft2 |= 32; }

            //AY4
            if (!toneRD.Checked) { enableRight2 |= 1; }
            if (!toneRE.Checked) { enableRight2 |= 2; }
            if (!toneRE.Checked) { enableRight2 |= 4; }
            if (!noiseRD.Checked) { enableRight2 |= 8; }
            if (!noiseRE.Checked) { enableRight2 |= 16; }
            if (!noiseRF.Checked) { enableRight2 |= 32; }

            byte[] buffer = new byte[60];

            buffer[0] = (byte)'C';
            buffer[1] = (byte)'B';
            buffer[2] = (byte)'1';
            buffer[3] = (byte)':';
            buffer[4] = (byte)nudTonePeriodCourseLA.Value;
            buffer[5] = (byte)nudTonePeriodCourseLB.Value;
            buffer[6] = (byte)nudTonePeriodCourseLC.Value;
            buffer[7] = (byte)nudTonePeriodCourseLD.Value;
            buffer[8] = (byte)nudTonePeriodCourseLE.Value;
            buffer[9] = (byte)nudTonePeriodCourseLF.Value;
            buffer[10] = (byte)nudTonePeriodFineLA.Value;
            buffer[11] = (byte)nudTonePeriodFineLB.Value;
            buffer[12] = (byte)nudTonePeriodFineLC.Value;
            buffer[13] = (byte)nudTonePeriodFineLD.Value;
            buffer[14] = (byte)nudTonePeriodFineLE.Value;
            buffer[15] = (byte)nudTonePeriodFineLF.Value;
            buffer[16] = (byte)((byte)nudVolumeLA.Value | (byte)cboVolFixedVarLA.SelectedIndex <<4);
            buffer[17] = (byte)((byte)nudVolumeLB.Value | (byte)cboVolFixedVarLB.SelectedIndex << 4);
            buffer[18] = (byte)((byte)nudVolumeLC.Value | (byte)cboVolFixedVarLC.SelectedIndex << 4);
            buffer[19] = (byte)((byte)nudVolumeLD.Value | (byte)cboVolFixedVarLD.SelectedIndex << 4);
            buffer[20] = (byte)((byte)nudVolumeLE.Value | (byte)cboVolFixedVarLE.SelectedIndex << 4);
            buffer[21] = (byte)((byte)nudVolumeLF.Value | (byte)cboVolFixedVarLF.SelectedIndex << 4);
            //buffer[16] = (byte)nudVolumeLA.Value;
            //buffer[17] = (byte)nudVolumeLB.Value;
            //buffer[18] = (byte)nudVolumeLC.Value;
            //buffer[19] = (byte)nudVolumeLD.Value;
            //buffer[20] = (byte)nudVolumeLE.Value;
            //buffer[21] = (byte)nudVolumeLF.Value;
            buffer[22] = (byte)nudTonePeriodCourseRA.Value;
            buffer[23] = (byte)nudTonePeriodCourseRB.Value;
            buffer[24] = (byte)nudTonePeriodCourseRC.Value;
            buffer[25] = (byte)nudTonePeriodCourseRD.Value;
            buffer[26] = (byte)nudTonePeriodCourseRE.Value;
            buffer[27] = (byte)nudTonePeriodCourseRF.Value;
            buffer[28] = (byte)nudTonePeriodFineRA.Value;
            buffer[29] = (byte)nudTonePeriodFineRB.Value;
            buffer[30] = (byte)nudTonePeriodFineRC.Value;
            buffer[31] = (byte)nudTonePeriodFineRD.Value;
            buffer[32] = (byte)nudTonePeriodFineRE.Value;
            buffer[33] = (byte)nudTonePeriodFineRF.Value;
            buffer[34] = (byte)((byte)nudVolumeRA.Value | (byte)cboVolFixedVarRA.SelectedIndex << 4);
            buffer[35] = (byte)((byte)nudVolumeRB.Value | (byte)cboVolFixedVarRB.SelectedIndex << 4);
            buffer[36] = (byte)((byte)nudVolumeRC.Value | (byte)cboVolFixedVarRC.SelectedIndex << 4);
            buffer[37] = (byte)((byte)nudVolumeRD.Value | (byte)cboVolFixedVarRD.SelectedIndex << 4);
            buffer[38] = (byte)((byte)nudVolumeRE.Value | (byte)cboVolFixedVarRE.SelectedIndex << 4);
            buffer[39] = (byte)((byte)nudVolumeRF.Value | (byte)cboVolFixedVarRF.SelectedIndex << 4);
            //buffer[34] = (byte)nudVolumeRA.Value;
            //buffer[35] = (byte)nudVolumeRB.Value;
            //buffer[36] = (byte)nudVolumeRC.Value;
            //buffer[37] = (byte)nudVolumeRD.Value;
            //buffer[38] = (byte)nudVolumeRE.Value;
            //buffer[39] = (byte)nudVolumeRF.Value;
            buffer[40] = (byte)nudNoisePeriodL1.Value;
            buffer[41] = (byte)nudEnvelopePeriodCourseL1.Value;
            buffer[42] = (byte)nudEnvelopePeriodFineL1.Value;
            buffer[43] = envelopeShapeCycleL1;
            buffer[44] = enableLeft1;
            buffer[45] = enableRight1;
            buffer[46] = enableLeft2;
            buffer[47] = enableRight2;
            //added:
            buffer[48] = (byte)nudNoisePeriodR1.Value;
            buffer[49] = (byte)nudEnvelopePeriodCourseR1.Value;
            buffer[50] = (byte)nudEnvelopePeriodFineR1.Value;
            buffer[51] = envelopeShapeCycleR1;
            buffer[52] = (byte)nudNoisePeriodL2.Value;
            buffer[53] = (byte)nudEnvelopePeriodCourseL2.Value;
            buffer[54] = (byte)nudEnvelopePeriodFineL2.Value;
            buffer[55] = envelopeShapeCycleL2;
            buffer[56] = (byte)nudNoisePeriodR2.Value;
            buffer[57] = (byte)nudEnvelopePeriodCourseR2.Value;
            buffer[58] = (byte)nudEnvelopePeriodFineR2.Value;
            buffer[59] = envelopeShapeCycleR2;


            myPort.Encoding = Encoding.UTF8;
            myPort.Write(buffer,0,buffer.Length);
            //MessageBox.Show("request sent to Nano...");
        }

        
        private void stopButton_Click(object sender, EventArgs e)
        {
            //raise interrupt on VIA4 CB1
            //start trigger by sending serial data to Nano
            //Nano will then pull CB1 low

            Byte envelopeShapeCycleL1 = 0;
            if (chkContL1.Checked) { envelopeShapeCycleL1 |= 8; }
            if (chkAttL1.Checked) { envelopeShapeCycleL1 |= 4; }
            if (chkAltL1.Checked) { envelopeShapeCycleL1 |= 2; }
            if (chkHoldL1.Checked) { envelopeShapeCycleL1 |= 1; }

            Byte envelopeShapeCycleR1 = 0;
            if (chkContR1.Checked) { envelopeShapeCycleR1 |= 8; }
            if (chkAttR1.Checked) { envelopeShapeCycleR1 |= 4; }
            if (chkAltR1.Checked) { envelopeShapeCycleR1 |= 2; }
            if (chkHoldR1.Checked) { envelopeShapeCycleR1 |= 1; }

            Byte envelopeShapeCycleL2 = 0;
            if (chkContL2.Checked) { envelopeShapeCycleL2 |= 8; }
            if (chkAttL2.Checked) { envelopeShapeCycleL2 |= 4; }
            if (chkAltL2.Checked) { envelopeShapeCycleL2 |= 2; }
            if (chkHoldL2.Checked) { envelopeShapeCycleL2 |= 1; }

            Byte envelopeShapeCycleR2 = 0;
            if (chkContR2.Checked) { envelopeShapeCycleR2 |= 8; }
            if (chkAttR2.Checked) { envelopeShapeCycleR2 |= 4; }
            if (chkAltR2.Checked) { envelopeShapeCycleR2 |= 2; }
            if (chkHoldR2.Checked) { envelopeShapeCycleR2 |= 1; }


            Byte enableLeft1 = 0;
            Byte enableLeft2 = 0;
            Byte enableRight1 = 0;
            Byte enableRight2 = 0;

            if (!toneLA.Checked) { enableLeft1 |= 1; }
            if (!toneLB.Checked) { enableLeft1 |= 2; }
            if (!toneLC.Checked) { enableLeft1 |= 4; }
            if (!noiseLA.Checked) { enableLeft1 |= 8; }
            if (!noiseLB.Checked) { enableLeft1 |= 16; }
            if (!noiseLC.Checked) { enableLeft1 |= 32; }

            if (!toneRA.Checked) { enableRight1 |= 1; }
            if (!toneRB.Checked) { enableLeft1 |= 2; }
            if (!toneRC.Checked) { enableRight1 |= 4; }
            if (!noiseRA.Checked) { enableRight1 |= 8; }
            if (!noiseRB.Checked) { enableRight1 |= 16; }
            if (!noiseRC.Checked) { enableRight1 |= 32; }

            if (!toneLD.Checked) { enableLeft2 |= 1; }
            if (!toneLE.Checked) { enableLeft2 |= 2; }
            if (!toneLF.Checked) { enableLeft2 |= 4; }
            if (!noiseLD.Checked) { enableLeft2 |= 8; }
            if (!noiseLE.Checked) { enableLeft2 |= 16; }
            if (!noiseLF.Checked) { enableLeft2 |= 32; }

            if (!toneRD.Checked) { enableRight2 |= 1; }
            if (!toneRE.Checked) { enableLeft2 |= 2; }
            if (!toneRE.Checked) { enableRight2 |= 4; }
            if (!noiseRD.Checked) { enableRight2 |= 8; }
            if (!noiseRE.Checked) { enableRight2 |= 16; }
            if (!noiseRF.Checked) { enableRight2 |= 32; }

            byte[] buffer = new byte[60];

            buffer[0] = (byte)'C';
            buffer[1] = (byte)'B';
            buffer[2] = (byte)'1';
            buffer[3] = (byte)':';
            buffer[4] = (byte)nudTonePeriodCourseLA.Value;
            buffer[5] = (byte)nudTonePeriodCourseLB.Value;
            buffer[6] = (byte)nudTonePeriodCourseLC.Value;
            buffer[7] = (byte)nudTonePeriodCourseLD.Value;
            buffer[8] = (byte)nudTonePeriodCourseLE.Value;
            buffer[9] = (byte)nudTonePeriodCourseLF.Value;
            buffer[10] = (byte)nudTonePeriodFineLA.Value;
            buffer[11] = (byte)nudTonePeriodFineLB.Value;
            buffer[12] = (byte)nudTonePeriodFineLC.Value;
            buffer[13] = (byte)nudTonePeriodFineLD.Value;
            buffer[14] = (byte)nudTonePeriodFineLE.Value;
            buffer[15] = (byte)nudTonePeriodFineLF.Value;
            buffer[16] = (byte)0;       //volumes to zero
            buffer[17] = (byte)0;
            buffer[18] = (byte)0;
            buffer[19] = (byte)0;
            buffer[20] = (byte)0;
            buffer[21] = (byte)0;
            buffer[22] = (byte)nudTonePeriodCourseRA.Value;
            buffer[23] = (byte)nudTonePeriodCourseRB.Value;
            buffer[24] = (byte)nudTonePeriodCourseRC.Value;
            buffer[25] = (byte)nudTonePeriodCourseRD.Value;
            buffer[26] = (byte)nudTonePeriodCourseRE.Value;
            buffer[27] = (byte)nudTonePeriodCourseRF.Value;
            buffer[28] = (byte)nudTonePeriodFineRA.Value;
            buffer[29] = (byte)nudTonePeriodFineRB.Value;
            buffer[30] = (byte)nudTonePeriodFineRC.Value;
            buffer[31] = (byte)nudTonePeriodFineRD.Value;
            buffer[32] = (byte)nudTonePeriodFineRE.Value;
            buffer[33] = (byte)nudTonePeriodFineRF.Value;
            buffer[34] = (byte)0;       //volume to zero
            buffer[35] = (byte)0;
            buffer[36] = (byte)0;
            buffer[37] = (byte)0;
            buffer[38] = (byte)0;
            buffer[39] = (byte)0;
            buffer[40] = (byte)nudNoisePeriodL1.Value;
            buffer[41] = (byte)nudEnvelopePeriodCourseL1.Value;
            buffer[42] = (byte)nudEnvelopePeriodFineL1.Value;
            buffer[43] = envelopeShapeCycleL1;
            buffer[44] = enableLeft1;
            buffer[45] = enableRight1;
            buffer[46] = enableLeft2;
            buffer[47] = enableRight2;

            //added:
            buffer[48] = (byte)nudNoisePeriodR1.Value;
            buffer[49] = (byte)nudEnvelopePeriodCourseR1.Value;
            buffer[50] = (byte)nudEnvelopePeriodFineR1.Value;
            buffer[51] = envelopeShapeCycleR1;
            buffer[52] = (byte)nudNoisePeriodL2.Value;
            buffer[53] = (byte)nudEnvelopePeriodCourseL2.Value;
            buffer[54] = (byte)nudEnvelopePeriodFineL2.Value;
            buffer[55] = envelopeShapeCycleL2;
            buffer[56] = (byte)nudNoisePeriodR2.Value;
            buffer[57] = (byte)nudEnvelopePeriodCourseR2.Value;
            buffer[58] = (byte)nudEnvelopePeriodFineR2.Value;
            buffer[59] = envelopeShapeCycleR2;

            myPort.Encoding = Encoding.UTF8;
            myPort.Write(buffer, 0, buffer.Length);
        }

        private void nud_Enter(object sender, EventArgs e)
        {
            NumericUpDown nud = sender as NumericUpDown;
            nud.Select();
            nud.Select(0, nud.Text.Length);
        }

        private void enableUpdateButtonTimer_Tick(object sender, EventArgs e)
        {
            startButton.Enabled = true;
            stopButton.Enabled = true;
            enableUpdateButtonTimer.Enabled = false;
        }

        private void chkHex_CheckedChanged(object sender, EventArgs e)
        {
                nudTonePeriodCourseLA.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseLB.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseLC.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseLD.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseLE.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseLF.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineLA.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineLB.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineLC.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineLD.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineLE.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineLF.Hexadecimal = chkHex.Checked;
                nudVolumeLA.Hexadecimal = chkHex.Checked;
                nudVolumeLB.Hexadecimal = chkHex.Checked;
                nudVolumeLC.Hexadecimal = chkHex.Checked;
                nudVolumeLD.Hexadecimal = chkHex.Checked;
                nudVolumeLE.Hexadecimal = chkHex.Checked;
                nudVolumeLF.Hexadecimal = chkHex.Checked;
                nudNoisePeriodL1.Hexadecimal = chkHex.Checked;
                nudNoisePeriodL2.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodCourseL1.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodCourseL2.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodFineL1.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodFineL2.Hexadecimal = chkHex.Checked;

                nudTonePeriodCourseRA.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseRB.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseRC.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseRD.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseRE.Hexadecimal = chkHex.Checked;
                nudTonePeriodCourseRF.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineRA.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineRB.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineRC.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineRD.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineRE.Hexadecimal = chkHex.Checked;
                nudTonePeriodFineRF.Hexadecimal = chkHex.Checked;
                nudVolumeRA.Hexadecimal = chkHex.Checked;
                nudVolumeRB.Hexadecimal = chkHex.Checked;
                nudVolumeRC.Hexadecimal = chkHex.Checked;
                nudVolumeRD.Hexadecimal = chkHex.Checked;
                nudVolumeRE.Hexadecimal = chkHex.Checked;
                nudVolumeRF.Hexadecimal = chkHex.Checked;
                nudNoisePeriodR1.Hexadecimal = chkHex.Checked;
                nudNoisePeriodR2.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodCourseR1.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodCourseR2.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodFineR1.Hexadecimal = chkHex.Checked;
                nudEnvelopePeriodFineR2.Hexadecimal = chkHex.Checked;
        }
    }
}
