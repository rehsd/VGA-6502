//Simple image import
//Takes an image and extracts ARGB bytes for importing into C or 6502/ROM
namespace Graphics_6502
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Could also pull the dimensions of the image dynamically
                //or parse the dimensions from the combo item
                int _x = 0;
                int _y = 0;
                switch (sizeCombo.SelectedItem.ToString())
                {
                    case "32x32":
                        _x = 32;
                        _y = 32;
                        break;
                    case "32x16":
                        _x = 32;
                        _y = 16;
                        break;
                    case "16x16":
                        _x = 16;
                        _y = 16;
                        break;
                    case "16x8":
                        _x = 16;
                        _y = 8;
                        break;
                    case "8x8":
                        _x = 8;
                        _y = 8;
                        break;
                    default:
                        break;
                }
                rtb.Clear();
                openFileDialog1.ShowDialog();
                Bitmap srcImage = (Bitmap)Bitmap.FromFile(openFileDialog1.FileName);
                pictureBox1.Image = srcImage;

                switch(outputCombo.SelectedIndex)
                {
                    case 0:     //C
                        for (int y = 0; y < _y; y++)
                        {
                            rtb.Text += "{";
                            for (int x = 0; x < _x; x++)
                            {
                                Color pixelColor = srcImage.GetPixel(x, y);
                                rtb.Text += "0x" + (pixelColor.ToArgb() & 16777215).ToString("X");
                                if (x != _x - 1)
                                {
                                    rtb.Text += ",";
                                }
                            }

                            rtb.Text += "}";
                            if (y != _y - 1)
                            {
                                rtb.Text += ",";
                            }
                            rtb.Text += Environment.NewLine;
                            rtb.Focus();
                            rtb.SelectAll();
                        }
                        break;
                    case 1:     //6502/ROM
                        for (int y = 0; y < _y; y++)
                        {
                            for (int x = 0; x < _x; x++)
                            {
                                Color pixelColor = srcImage.GetPixel(x, y);
                                rtb.Text += (pixelColor.ToArgb() & 16777215).ToString("X");
                            }

                            rtb.Text += Environment.NewLine;
                            rtb.Focus();
                            rtb.SelectAll();
                        }
                        break;
                }
                
            }
            catch (Exception xcp)
            {
                MessageBox.Show(xcp.Message);
                throw;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sizeCombo.SelectedIndex = 0;
            outputCombo.SelectedIndex = 0;
        }


    }
}