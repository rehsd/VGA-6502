// **** TO DO ************************
// -Implement structs
//
// ***********************************

#include <stdio.h>
#include <xil_types.h>
#include <xil_cache.h>
#include <xparameters.h>
#include <xuartlite.h>
#include <stdlib.h>
#include <xil_io.h>
#include <xstatus.h>
#include <xil_printf.h>
#include <xgpio.h>
#include <xil_exception.h>
#include <xintc.h>

#include "chars.c"
#include "eight_bit_interface.h"
#include "globals.h"
#include "sprites.h"
#include "screen.h"
#include "zybo_vga/display_ctrl.h"

#define GPIO_DEVICE_ID0		XPAR_AXI_GPIO_0_DEVICE_ID
#define INTC_GPIO_INTERRUPT_ID	XPAR_INTC_0_GPIO_0_VEC_ID
#define GPIO_CHANNEL1		1

#define INTC_DEVICE_ID	XPAR_INTC_0_DEVICE_ID
#define INTC		XIntc
#define INTC_HANDLER	XIntc_InterruptHandler

//#define VIA_PORTA_INTERRUPT XGPIO_IR_CH1_MASK  /* Channel 1 Interrupt Mask */
#define GPIO0_CH1_INTERRUPT 0x01	//interrupt from GPI firs channel
#define VIA_PORTA_CONTROL_VALUE 0x8000


#define MAX_FRAME (800*600)
#define FRAME_STRIDE (800*4)


void GpioHandler(void *CallBackRef);
int GpioSetupIntrSystem(INTC *IntcInstancePtr, XGpio *InstancePtr, u16 DeviceId, u16 IntrId, u16 IntrMask);
void GpioDisableIntr(INTC *IntcInstancePtr, XGpio *InstancePtr, u16 IntrId, u16 IntrMask);


u32 frameBuf[DISPLAY_NUM_FRAMES][MAX_FRAME]; // Frame buffers for video data
void *pFrames[DISPLAY_NUM_FRAMES]; // Array of pointers to the frame buffers

XGpio Gpio0;
u32 gpio0_ch1_status=0;
INTC Intc;
static u16 GlobalIntrMask; /* GPIO channel mask that is needed by the Interrupt Handler */
static volatile u32 IntrFlag; /* Interrupt Handler Flag */
#define INTR_DELAY	0x00FFFFFF


XUartLite UartLite;
u8 SendBuffer[20];
u8 RecvBuffer[20];

void EnableCaches();
void DisableCaches();
void ProcessKeys();
//void ReceivePackets();

bool resetIrq = true;

int main(void) {
	EnableCaches();

	int status0;
	status0 = XGpio_Initialize(&Gpio0, GPIO_DEVICE_ID0);
	Gpio0.IsDual=1;
    XGpio_SetDataDirection(&Gpio0, 1, 0xffffffff);		//gpio, channel, direction: in
    XGpio_SetDataDirection(&Gpio0, 2, 0x00000000);		//gpio, channel, direction: out
    Gpio0.InterruptPresent=1;
    //status0 = GpioSetupIntrSystem(&Intc, &Gpio0, GPIO_DEVICE_ID0, XPAR_INTC_0_GPIO_0_VEC_ID, 1);
    status0 = GpioSetupIntrSystem(&Intc, &Gpio0, GPIO_DEVICE_ID0, XPAR_INTC_0_GPIO_0_VEC_ID, GPIO0_CH1_INTERRUPT);

    XGpio_DiscreteWrite(&Gpio0, 2, 1);	//bring signal high - used to trigger interrupt on 6502

	//u32 DataRead;
    //int Status = GpioIntrExample(&Intc, &Gpio0, GPIO_DEVICE_ID0, INTC_GPIO_INTERRUPT_ID, GPIO_CHANNEL1, &DataRead);

    int uartStatus = XUartLite_Initialize(&UartLite, XPAR_UARTLITE_0_DEVICE_ID);

	// Initialise an array of pointers to the 2 frame buffers
	int i;
	for (i = 0; i < DISPLAY_NUM_FRAMES; i++)
		pFrames[i] = frameBuf[i];

	// Initialise the display controller
	DisplayInitialize(&dispCtrl, XPAR_AXIVDMA_0_DEVICE_ID, XPAR_VTC_0_DEVICE_ID, XPAR_VGA_AXI_DYNCLK_0_S_AXI_LITE_BASEADDR, pFrames, FRAME_STRIDE);

	// Use first frame buffer (of two)
	DisplayChangeFrame(&dispCtrl, 0);

	// Set the display resolution
	DisplaySetMode(&dispCtrl, &VMODE_800x600);

	// Enable video output
	DisplayStart(&dispCtrl);

	SetDisplay(&dispCtrl);
	SpritesSetDisplay(&dispCtrl);
	SetDisplay_forScreen(&dispCtrl);


	// Get parameters from display controller struct
	int x, y;
	u32 stride = dispCtrl.stride / 4;
	u32 width = dispCtrl.vMode.width;
	u32 height = dispCtrl.vMode.height;
	u32 *frame = dispCtrl.framePtr[dispCtrl.curFrame];
	u32 red, green, blue;

//	for (y = 0; y < height; y++) {
//		for (x = 0; x < width; x++) {
//			green = (x*0xF0) / width;
//			blue = 0xF0 - ((x*0xF0) / width);
//			red = (y*0xF0) / height;
//			frame[y*stride + x] = (red << BIT_DISPLAY_RED) | (blue << BIT_DISPLAY_BLUE) | (green << BIT_DISPLAY_GREEN);
//		}
//	}


	//right wall
	for (y = 0; y < height; y++) {
		for (x = 600; x<650; x++) {
			green =  0xF0 / (650-x);
			blue = 0xF0 / (650-x);
			red = 0xF0 / (650-x);
			frame[y*stride + x] = (red << BIT_DISPLAY_RED) | (blue << BIT_DISPLAY_BLUE) | (green << BIT_DISPLAY_GREEN);
			frame[y*stride + x + 5] = 0x00FF0000;
			//frame[y*stride + x + 19] = 0x00FF0000;
			frame[y*stride + (1250-x) + (53)] = (red << BIT_DISPLAY_RED) | (blue << BIT_DISPLAY_BLUE) | (green << BIT_DISPLAY_GREEN);
		}
	}


	Xil_DCacheFlush();


	while(1)
	{
		//Incoming requests are interrupt-driven and handled by GpioHandler()
		DrawScreen();
	}

	DisableCaches();
	return 0;
}

int GpioSetupIntrSystem(INTC *IntcInstancePtr, XGpio *InstancePtr,
			u16 DeviceId, u16 IntrId, u16 IntrMask)
{
	int Result;

	GlobalIntrMask = IntrMask;

	/*
	 * Initialize the interrupt controller driver so that it's ready to use.
	 * specify the device ID that was generated in xparameters.h
	 */
	Result = XIntc_Initialize(IntcInstancePtr, INTC_DEVICE_ID);
	if (Result != XST_SUCCESS) {
		return Result;
	}

	/* Hook up interrupt service routine */
	XIntc_Connect(IntcInstancePtr, IntrId,
		      (Xil_ExceptionHandler)GpioHandler, InstancePtr);

	/* Enable the interrupt vector at the interrupt controller */

	XIntc_Enable(IntcInstancePtr, IntrId);

	/*
	 * Start the interrupt controller such that interrupts are recognized
	 * and handled by the processor
	 */
	Result = XIntc_Start(IntcInstancePtr, XIN_REAL_MODE);
	if (Result != XST_SUCCESS) {
		return Result;
	}

	/*
	 * Enable the GPIO channel interrupts so that push button can be
	 * detected and enable interrupts for the GPIO device
	 */
	XGpio_InterruptEnable(InstancePtr, IntrMask);
	XGpio_InterruptGlobalEnable(InstancePtr);

	/*
	 * Initialize the exception table and register the interrupt
	 * controller handler with the exception table
	 */
	Xil_ExceptionInit();

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
			 (Xil_ExceptionHandler)INTC_HANDLER, IntcInstancePtr);

	/* Enable non-critical exceptions */
	Xil_ExceptionEnable();

	return XST_SUCCESS;
}
void GpioHandler(void *CallbackRef)
{
	//keep this code short - set vars and let DrawScreen() do screen updates

	//xil_printf("irq handler...");
	XGpio *GpioPtr = (XGpio *)CallbackRef;

	//Clear the Interrupt
	//XGpio_InterruptClear(GpioPtr, GlobalIntrMask);

	gpio0_ch1_status = XGpio_DiscreteRead(GpioPtr, 1);		//gpio, channel
	//xil_printf("%d\r\n", gpio0_ch1_status);
	//MSB is interrupt (128). Next seven bits are CMD. LSB eight bits are data.
	u16 irqStatus = gpio0_ch1_status & 32768;
	//xil_printf("irq0...\r\n");
	if(irqStatus==32768 && resetIrq)	//interrupt bit
	{
		xil_printf("packet:%d", gpio0_ch1_status);
		u16 cmd = (gpio0_ch1_status&32512)>>8;	//mask for CMD bits
		u16 data = gpio0_ch1_status&255;		//mask for DATA bits
		ProcessPacket(cmd<<8 | data);
		resetIrq = false;
	}
	else if(irqStatus==0)
	{
		resetIrq = true;
	}

	IntrFlag = 1;

//	//Clear the Interrupt
	XGpio_InterruptClear(GpioPtr, GlobalIntrMask);

}


void GpioDisableIntr(INTC *IntcInstancePtr, XGpio *InstancePtr,
			u16 IntrId, u16 IntrMask)
{
	XGpio_InterruptDisable(InstancePtr, IntrMask);
	XIntc_Disable(IntcInstancePtr, IntrId);
	return;
}

//void ReceivePackets()
//{
//	//xil_printf("\n\rReady for 2-byte packets >");
//
//	//single key processing...
//	//char c = XUartLite_RecvByte(STDIN_BASEADDRESS);
//
//	unsigned int ReceivedCount = 0;
//	memset(RecvBuffer, 0, 20);	//clear the receive buffer
//
//	while (1)
//	{
//		ReceivedCount += XUartLite_Recv(&UartLite, RecvBuffer+ReceivedCount, 1);
//		if (RecvBuffer[ReceivedCount-1]=='\n' || RecvBuffer[ReceivedCount-1]=='\r')
//		{
//			if(ReceivedCount==17)	//expecting 2 bytes plus \n or \r
//			{
//				RecvBuffer[ReceivedCount-1]='\0';	//replace \n or \r with \0 terminator
//				//xil_printf("\r\n");
//
//				//convert received u8's to a single u16 to pass to ProcessPacket()
//				char packetBuffer[8];
//				memset(packetBuffer, 0, 8);	//clear the buffer
//				for(u8 b = 0; b<8; b++)
//				{
//					packetBuffer[b] = (char)(int)RecvBuffer[b];
//				}
//				u8 packet_MSB = convertBin2Dec(charArrayToInt(packetBuffer, 8));
//				memset(packetBuffer, 0, 8);	//clear the buffer
//				for(u8 b = 8; b<16; b++)
//				{
//					packetBuffer[b-8] = (char)(int)RecvBuffer[b];
//				}
//				u8 packet_LSB = convertBin2Dec(charArrayToInt(packetBuffer, 8));
//
//				ProcessPacket(packet_MSB<<8 | packet_LSB);
//
//				memset(RecvBuffer, 0, 20);	//clear the receive buffer
//				ReceivedCount = 0;
//				//xil_printf("\n\rReady for 2-byte packets >");
//
//				//rinse and repeat
//			}
//			else
//			{
//				//didn't receive what was expected. flush buffer and loop...
//				memset(RecvBuffer, 0, 20);	//clear the receive buffer
//				ReceivedCount = 0;
//				//xil_printf("\n\rReady for 2-byte packets >");
//
//			}
//		}
//	}
//}
int charArrayToInt(char *arr, int charLen) {
    int i, value, r, flag;
    flag = 1;
    i = value = 0;
    for( i = 0 ; i<charLen ; ++i){
        // if arr contain negative number
        if( i==0 && arr[i]=='-' ){
            flag = -1;
            continue;
        }

        r = arr[i] - '0';
        value = value * 10 + r;
    }
    value = value * flag;
    return value;
}
int convertBin2Dec(long binary)
{
	int  decimal_val = 0, base = 1, rem;
	while (binary > 0)
	  {
		  rem = binary % 10;
		  decimal_val = decimal_val + rem * base;
		 //num/=10;
		  binary = binary / 10 ;
		 //base*=2;
		  base = base * 2;
	  }
	return decimal_val;
}



void EnableCaches() {
#ifdef __MICROBLAZE__
#ifdef XPAR_MICROBLAZE_USE_ICACHE
   Xil_ICacheEnable();
#endif
#ifdef XPAR_MICROBLAZE_USE_DCACHE
   Xil_DCacheEnable();
#endif
#endif
}
void DisableCaches() {
#ifdef __MICROBLAZE__
#ifdef XPAR_MICROBLAZE_USE_DCACHE
   Xil_DCacheDisable();
#endif
#ifdef XPAR_MICROBLAZE_USE_ICACHE
   Xil_ICacheDisable();
#endif
#endif
}
