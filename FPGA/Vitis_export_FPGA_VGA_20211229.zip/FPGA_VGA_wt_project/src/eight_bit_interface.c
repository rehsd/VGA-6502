#include "eight_bit_interface.h"
#include "xil_io.h"
#include "zybo_vga/display_ctrl.h"
#include "chars.c"
#include "xil_cache.h"
#include "stdbool.h"
#include "sprites.h"
#include "globals.h"

#define MAX_FRAME (800*600)
#define FRAME_STRIDE (800*4)
#define PLAYER_MOVE_AMOUNT 3

u16 posCol;
u16 posRow;

void ProcessPacket(u16 packet)
{
	u8 cmd = packet >> 8;
	u8 data = packet & 255;
	xil_printf("    cmd:%d    data:%d\r\n", cmd, data);

	switch (cmd)
	{
		case EBI_CLEAR_SCREEN:	//EBI_CLEAR_SCREEN
		{
			xil_printf("   ClearScreen");
			ClearScreen();
			//xil_printf(".\r\n");
			break;
		}
		case EBI_PRINT_CHAR:
		{
			if(data==27)	//ESC
			{
				xil_printf("   ClearScreen");
				ClearScreen();
				//xil_printf(".\r\n");
				break;
			}
			if(data==96)	//`
			{
				if(!drawRectangleOn)
				{
					drawRectangleOn = true;
					//store position of start
					posRectangleStartX = posCol;
					posRectangleStartY = posRow;
				}
				else
				{
					//draw rectangle
					DrawRectangle();
					drawRectangleOn = false;
				}
				break;
			}
			xil_printf("   PrintChar");
			PrintChar((char)data);
			posCol=posCol+6;
			if((char)data=='\r' || (char)data=='\n')
			{
				posCol = 5;
				posRow = posRow + 8;
			}
			//xil_printf(".\r\n");
			break;
		}
		case EBI_MOUSEMOVE_X_MSB:		//mouse x msb
		case EBI_MOUSEMOVE_X_LSB:		//mouse x lsb
		case EBI_MOUSEMOVE_Y_MSB:		//mouse y msb
		case EBI_MOUSEMOVE_Y_LSB:		//mouse y lsb
			DrawMousePointer(cmd, data);
			break;
		case EBI_MOUSEDOWN_LEFT_X_MSB:		//mouse down left button
		case EBI_MOUSEDOWN_LEFT_X_LSB:
		case EBI_MOUSEDOWN_LEFT_Y_MSB:
		case EBI_MOUSEDOWN_LEFT_Y_LSB:
			MouseDown(cmd, data);
			break;
		case EBI_MOUSEDOWN_RIGHT:	//mouse down right button
			mouseDrawingOn = !mouseDrawingOn;
			break;
		case EBI_MOUSEDOWN_MIDDLE:	//mouse down middle button
			//toggle color
			switch(currentColor)
			{
				case(0x00FFFFFF):
				{
					currentColor = 0x000000FF;
					break;
				}
				case(0x000000FF):
				{
					currentColor = 0x0000FF00;
					break;
				}
				case(0x0000FF00):
				{
					currentColor = 0x00FF0000;
					break;
				}
				case(0x00FF0000):
				{
					currentColor = 0x0000FFFF;
					break;
				}
				case(0x0000FFFF):
				{
					currentColor = 0x00FF00FF;
					break;
				}
				case(0x00FF00FF):
				{
					currentColor = 0x00FFFF00;
					break;
				}
				case(0x00FFFF00):
				{
					currentColor = 0x00FFFFFF;
					break;
				}
				default:
				{
					currentColor = 0x00FFFFFF;
					break;
				}
			}
		case EBI_MOUSEMOVE_UP:
		{
			//mouseY--;
			DrawMousePointer(2,(mouseX&65280)>>8);		//X MSB
			DrawMousePointer(3,mouseX&255);				//X LSB
			DrawMousePointer(4,((mouseY-mouseMoveAmount)&65280)>>8);		//Y MSB
			DrawMousePointer(5,(mouseY-mouseMoveAmount)&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_RIGHT_UP:
		{
			//mouseY--;
			//mouseX++;
			DrawMousePointer(2,((mouseX+mouseMoveAmount)&65280)>>8);		//X MSB
			DrawMousePointer(3,(mouseX+mouseMoveAmount)&255);				//X LSB
			DrawMousePointer(4,((mouseY-mouseMoveAmount)&65280)>>8);		//Y MSB
			DrawMousePointer(5,(mouseY-mouseMoveAmount)&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_RIGHT:
		{
			//mouseX++;
			DrawMousePointer(2,((mouseX+mouseMoveAmount)&65280)>>8);		//X MSB
			DrawMousePointer(3,(mouseX+mouseMoveAmount)&255);				//X LSB
			DrawMousePointer(4,(mouseY&65280)>>8);		//Y MSB
			DrawMousePointer(5,mouseY&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_RIGHT_DOWN:
		{
			//mouseX++;
			//mouseY++;
			DrawMousePointer(2,((mouseX+mouseMoveAmount)&65280)>>8);		//X MSB
			DrawMousePointer(3,(mouseX+mouseMoveAmount)&255);				//X LSB
			DrawMousePointer(4,((mouseY+mouseMoveAmount)&65280)>>8);		//Y MSB
			DrawMousePointer(5,(mouseY+mouseMoveAmount)&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_DOWN:
		{
			//mouseY++;
			DrawMousePointer(2,(mouseX&65280)>>8);		//X MSB
			DrawMousePointer(3,mouseX&255);				//X LSB
			DrawMousePointer(4,((mouseY+mouseMoveAmount)&65280)>>8);		//Y MSB
			DrawMousePointer(5,(mouseY+mouseMoveAmount)&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_LEFT_DOWN:
		{
			//mouseX--;
			//mouseY++;
			DrawMousePointer(2,((mouseX-mouseMoveAmount)&65280)>>8);		//X MSB
			DrawMousePointer(3,(mouseX-mouseMoveAmount)&255);				//X LSB
			DrawMousePointer(4,((mouseY+mouseMoveAmount)&65280)>>8);		//Y MSB
			DrawMousePointer(5,(mouseY+mouseMoveAmount)&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_LEFT:
		{
			//mouseX--;
			DrawMousePointer(2,((mouseX-mouseMoveAmount)&65280)>>8);		//X MSB
			DrawMousePointer(3,(mouseX-mouseMoveAmount)&255);				//X LSB
			DrawMousePointer(4,(mouseY&65280)>>8);		//Y MSB
			DrawMousePointer(5,mouseY&255);				//Y LSB
			break;
		}
		case EBI_MOUSEMOVE_LEFT_UP:
		{
			//mouseX--;
			//mouseY--;
			DrawMousePointer(2,((mouseX-mouseMoveAmount)&65280)>>8);		//X MSB
			DrawMousePointer(3,(mouseX-mouseMoveAmount)&255);				//X LSB
			DrawMousePointer(4,((mouseY-mouseMoveAmount)&65280)>>8);		//Y MSB
			DrawMousePointer(5,(mouseY-mouseMoveAmount)&255);				//Y LSB
			break;
		}
		case EBI_MOUSEDOWN_LEFT_ONMOVE:
		{
			MouseDown(6, (mouseX&65280)>>8);
			MouseDown(7, mouseX&255);
			MouseDown(8, (mouseY&65280)>>8);
			MouseDown(9, mouseY&255);
			break;
		}
		case EBI_PLAYER_ONE_MOVE_RIGHT:
		{
			DrawPlayerOne_old(PlayerOneLastX+PLAYER_MOVE_AMOUNT, PlayerOneLastY);
			PlayerOneLastX = PlayerOneLastX+PLAYER_MOVE_AMOUNT;
			break;
		}
		case EBI_PLAYER_ONE_MOVE_DOWN:
		{
			DrawPlayerOne_old(PlayerOneLastX, PlayerOneLastY+PLAYER_MOVE_AMOUNT);
			PlayerOneLastY = PlayerOneLastY+PLAYER_MOVE_AMOUNT;
			break;
		}
		case EBI_PLAYER_ONE_MOVE_LEFT:
		{
			DrawPlayerOne_old(PlayerOneLastX-PLAYER_MOVE_AMOUNT, PlayerOneLastY);
			PlayerOneLastX = PlayerOneLastX-PLAYER_MOVE_AMOUNT;
			break;
		}
		case EBI_PLAYER_ONE_MOVE_UP:
		{
			DrawPlayerOne_old(PlayerOneLastX, PlayerOneLastY-PLAYER_MOVE_AMOUNT);
			PlayerOneLastY = PlayerOneLastY-PLAYER_MOVE_AMOUNT;
			break;
		}
		case EBI_PLAYER_ONE_FIRE_ROCKET:
			FireRocket(PlayerOneLastX, PlayerOneLastY);
			break;
		case EBI_PLAYER_ONE_MOVE_FIRE:
			PlayerOneMoveFire(data);
			break;
		default:
		{
			xil_printf("\n\r  ** Unrecognized command ***\n\r");
			Xil_DCacheFlush();
			break;
		}
	}
}

void PlayerOneMoveFire(u8 moveFireData)
{
	xil_printf("\r\nMoveFire:%d\r\n",moveFireData);
	//to do call other move/fire routines based on moveFireData
	//bit will be low if set - up/down/right/left/button
	if((~moveFireData)&128)		//fire?
	{
		FireRocket(PlayerOneLastX, PlayerOneLastY);
	}
	if((~moveFireData)&64)		//up?
	{
		DrawPlayerOne_old(PlayerOneLastX, PlayerOneLastY-PLAYER_MOVE_AMOUNT);
		PlayerOneLastY = PlayerOneLastY-PLAYER_MOVE_AMOUNT;
	}
	if((~moveFireData)&32)		//right?
	{
		DrawPlayerOne_old(PlayerOneLastX+PLAYER_MOVE_AMOUNT, PlayerOneLastY);
		PlayerOneLastX = PlayerOneLastX+PLAYER_MOVE_AMOUNT;
	}
	if((~moveFireData)&16)		//down?
	{
		DrawPlayerOne_old(PlayerOneLastX, PlayerOneLastY+PLAYER_MOVE_AMOUNT);
		PlayerOneLastY = PlayerOneLastY+PLAYER_MOVE_AMOUNT;
	}
	if((~moveFireData)&8)		//left?
	{
		DrawPlayerOne_old(PlayerOneLastX-PLAYER_MOVE_AMOUNT, PlayerOneLastY);
		PlayerOneLastX = PlayerOneLastX-PLAYER_MOVE_AMOUNT;
	}
	//bits 4,2,1 are not being used -- should always be high
}

void DrawRectangle()
{
	//assuming start in upper left, end in lower right of rectangle
	for(int y = posRectangleStartY; y < posRow+1; y++)
	{
		for(int x = posRectangleStartX; x < posCol+1; x++)
		{
			u32 *frame = dispCtrl.framePtr[dispCtrl.curFrame];
			u32 stride = dispCtrl.stride / 4;
			frame[(y)*stride + x]= currentColor;
		}
	}
	Xil_DCacheFlush();
}

void MouseDown(u8 cmd, u8 data)
{
	switch(cmd)
	{
		case(6):		//x msb
			{
				//don't draw until y lsb is received
				posCol = (data<<8) | (posCol & 255);
				break;
			}
		case(7):		//x lsb
			{
				//don't draw until y lsb is received
				posCol = (posCol & 65280) | data;
				break;
			}
		case(8):
			{
				//don't draw until y lsb is received
				posRow = (data<<8) | (posRow & 255);
				break;
			}
		case(9):
			{
				posRow = (posRow & 65280) | data;

				//shift the position just to the right of the actual location, for new text insertion location
				posCol = posCol+6;
				break;
			}
	}
}

void DrawMousePointer(u8 cmd, u8 data)
{
	switch(cmd)
	{
	case(2):		//x msb
		{
			//store color from new position
			//store current/old position
			mouseXprev = mouseX;
			mouseYprev = mouseY;

			//don't draw until y lsb is received
			mouseX = (data<<8) | (mouseX & 255);
			break;
		}
	case(3):		//x lsb
		{
			//don't draw until y lsb is received
			mouseX = (mouseX & 65280) | data;
			break;
		}
	case(4):
		{
			//don't draw until y lsb is received
			mouseY = (data<<8) | (mouseY & 255);
			break;
		}
	case(5):
		{
			mouseY = (mouseY & 65280) | data;

			if(mouseDrawingOn)
			{
				//draw trails here
				u32 *frame = dispCtrl.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl.stride / 4;
				frame[(mouseY)*stride + mouseX]= currentColor;
				frame[(mouseY+1)*stride + mouseX]= currentColor;
				frame[(mouseY-1)*stride + mouseX]= currentColor;
				frame[(mouseY)*stride + mouseX+1]= currentColor;
				frame[(mouseY)*stride + mouseX-1]= currentColor;
				frame[(mouseY+2)*stride + mouseX]= currentColor;
				frame[(mouseY-2)*stride + mouseX]= currentColor;
				frame[(mouseY)*stride + mouseX+2]= currentColor;
				frame[(mouseY)*stride + mouseX-2]= currentColor;
				frame[(mouseY+1)*stride + mouseX+1]= currentColor;
				frame[(mouseY-1)*stride + mouseX-1]= currentColor;
				frame[(mouseY+1)*stride + mouseX-1]= currentColor;
				frame[(mouseY-1)*stride + mouseX+1]= currentColor;

				Xil_DCacheFlush();
			}
			else
			{
				//draw new position
				u32 *frame = dispCtrl.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl.stride / 4;
				frame[(mouseY-4)*stride + mouseX]= 0xFFFFFFFF;
				frame[(mouseY-3)*stride + mouseX]= 0xFFFFFFFF;
				frame[(mouseY)*stride + mouseX]= 0xFFFFFFFF;
				frame[(mouseY-2)*stride + mouseX]= 0xFFFFFFFF;
				frame[(mouseY-1)*stride + mouseX]= 0xFFFFFFFF;
				frame[(mouseY-4)*stride + mouseX+1]= 0xFFFFFFFF;
				frame[(mouseY-3)*stride + mouseX+1]= 0xFFFFFFFF;
				frame[(mouseY)*stride + mouseX+1]= 0xFFFFFFFF;
				frame[(mouseY-2)*stride + mouseX+1]= 0xFFFFFFFF;
				frame[(mouseY-1)*stride + mouseX+1]= 0xFFFFFFFF;

				//clear previous pointer location
				frame[(mouseYprev-4)*stride + mouseXprev]= 0x00000000;
				frame[(mouseYprev-3)*stride + mouseXprev]= 0x00000000;
				frame[(mouseYprev)*stride + mouseXprev]= 0x00000000;
				frame[(mouseYprev-2)*stride + mouseXprev]= 0x00000000;
				frame[(mouseYprev-1)*stride + mouseXprev]= 0x00000000;
				frame[(mouseYprev-4)*stride + mouseXprev+1]= 0x00000000;
				frame[(mouseYprev-3)*stride + mouseXprev+1]= 0x00000000;
				frame[(mouseYprev)*stride + mouseXprev+1]= 0x00000000;
				frame[(mouseYprev-2)*stride + mouseXprev+1]= 0x00000000;
				frame[(mouseYprev-1)*stride + mouseXprev+1]= 0x00000000;
				Xil_DCacheFlush();
			}
			break;
		}
	}
}

void SetDisplay(DisplayCtrl *dispPtr)
{
	dispCtrl = *dispPtr;
	//SpritesSetDisplay(&dispPtr);
	posCol = 5;
	posRow = 5;
	mouseX = 401;
	mouseY = 301;
	mouseXprev=400;
	mouseYprev=300;
	currentColor = 0x00FFFFFF;
}

void ClearScreen()
{
	posCol = 5;
	posRow = 5;
	u32 *frame = dispCtrl.framePtr[dispCtrl.curFrame];
	memset(frame, 0x00, MAX_FRAME*4);	//black
}


void PrintChar(char c)
{
	u32 *frame = dispCtrl.framePtr[dispCtrl.curFrame];
	u32 stride = dispCtrl.stride / 4;

	for(u32 row = 0; row<7; row++)
	{
		for(u32 col = 0; col<5; col++)
		{
			if(charLookup[(u8)c][row][col]==1)
			{
				frame[(row+posRow)*stride + (col+posCol)]= currentColor;
			}
			else
			{
				frame[(row+posRow)*stride + (col+posCol)]= 0;		//to do : setup currentBackgroundColor
			}
		}
	}

	Xil_DCacheFlush();
}
