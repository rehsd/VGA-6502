//Track all objects
//Draw screen, simulating scanlines of old Atari
//Handling this way as both 6502 and MicroBlaze are single-threaded applications

//standard libraries
#include <stdbool.h>
#include <xil_cache.h>
#include <xil_io.h>

//other libraries
#include "eight_bit_interface.h"
#include "globals.h"
#include "screen.h"
#include "sprites.h"
#include "zybo_vga/display_ctrl.h"

bool 	gameStart					= true;
u8		score						= 0;
bool	headerHasChanges			= true;

//***

bool	PlayerOneSprite_Active		= false;
bool 	PlayerOneSprite_HasChanges	= false;
u8		PlayerOneSprite_FrameNum	= 0;
u16		PlayerOneSprite_LocationY	= 0;
u16		PlayerOneSprite_LocationX	= 0;

bool 	PlayerOneRocket1_Active		= false;
bool	PlayerOneRocket1_HasChanges	= false;
u8 		PlayerOneRocket1_FrameNum	= 0;
u16 	PlayerOneRocket1_LocationY	= 0;
u16 	PlayerOneRocket1_LocationX	= 0;

bool 	PlayerOneRocket2_Active		= false;
bool	PlayerOneRocket2_HasChanges	= false;
u8 		PlayerOneRocket2_FrameNum	= 0;
u16 	PlayerOneRocket2_LocationY	= 0;
u16 	PlayerOneRocket2_LocationX	= 0;

bool 	PlayerOneRocket3_Active		= false;
bool	PlayerOneRocket3_HasChanges = false;
u8 		PlayerOneRocket3_FrameNum	= 0;
u16 	PlayerOneRocket3_LocationY	= 0;
u16 	PlayerOneRocket3_LocationX	= 0;

bool	Cube1_Active = false;
bool	Cube1_HasChanges = false;
u8		Cube1_FrameNum=1;
u16		Cube1_LocationX;
u16		Cube1_LocationY;

bool	Cube2_Active = false;
bool	Cube2_HasChanges = false;
u8		Cube2_FrameNum=1;
u16		Cube2_LocationX;
u16		Cube2_LocationY;

bool	Cube3_Active = false;
bool	Cube3_HasChanges = false;
u8		Cube3_FrameNum=1;
u16		Cube3_LocationX;
u16		Cube3_LocationY;

void SetDisplay_forScreen(DisplayCtrl *dispPtr)
{
	dispCtrl_Sprites = *dispPtr;
}

void DrawScreen()
{
	if(gameStart)
	{
		GameSetup();
	}
	if(PlayerOneSprite_HasChanges)
	{
		DrawPlayerOne();
		PlayerOneSprite_HasChanges = false;
	}
	if(PlayerOneRocket1_HasChanges)
	{
		DrawPlayerOneRocket1();
	}
	if(PlayerOneRocket2_HasChanges)
	{
		DrawPlayerOneRocket2();
	}
	if(PlayerOneRocket3_HasChanges)
	{
		DrawPlayerOneRocket3();
	}
	if(Cube1_HasChanges && Cube1_Active)
	{
		DrawCube1();
	}
	if(Cube2_HasChanges && Cube2_Active)
	{
		DrawCube2();
	}
	if(Cube3_HasChanges && Cube3_Active)
	{
		DrawCube3();
	}

	if(headerHasChanges)
	{
		DrawHeader();
	}

	Xil_DCacheFlush();
}

void GameSetup()
{
	Cube1_LocationX = 700;
	Cube1_LocationY = 200;
	Cube2_LocationX = 700;
	Cube2_LocationY = 300;
	Cube3_LocationX = 700;
	Cube3_LocationY = 400;

	DrawCube1();
	DrawCube2();
	DrawCube3();

	//static u16 PlayerOneLastX = 20;
	//static u16 PlayerOneLastY = 240;
	PlayerOneSprite_LocationX = 20;
	PlayerOneSprite_LocationY = 240;
	PlayerOneSprite_Active = true;
	DrawPlayerOne();

	DrawHeader();

	gameStart = false;
}

void DrawPlayerOne()
{
	//clear previous sprite?

	if(PlayerOneSprite_Active)
	{
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneSprite_LocationY+y)*stride + PlayerOneSprite_LocationX+x]= playerOne[y][x];
			}
		}
	}
}

void DrawHeader()
{
	posRow = 20;
	posCol = 50;
	PrintChar('R');
	posCol=posCol+6;
	PrintChar('O');
	posCol=posCol+6;
	PrintChar('C');
	posCol=posCol+6;
	PrintChar('K');
	posCol=posCol+6;
	PrintChar('E');
	posCol=posCol+6;
	PrintChar('T');
	posCol=posCol+6;
	PrintChar('S');
	posCol=posCol+6;
	PrintChar(' ');
	posCol=posCol+6;
	PrintChar('O');
	posCol=posCol+6;
	PrintChar('N');
	posCol=posCol+6;
	PrintChar('L');
	posCol=posCol+6;
	PrintChar('I');
	posCol=posCol+6;
	PrintChar('N');
	posCol=posCol+6;
	PrintChar('E');
	posCol=posCol+6;
	PrintChar(':');
	posCol=posCol+6;
	PrintChar(' ');
	posCol=posCol+6;

	//clear spaces
	PrintChar(' ');
	//posCol=posCol-6;

	u8 rocketsOnline = 0;
	if(!PlayerOneRocket1_Active)
	{
		rocketsOnline++;
	}
	if(!PlayerOneRocket2_Active)
	{
		rocketsOnline++;
	}
	if(!PlayerOneRocket3_Active)
	{
		rocketsOnline++;
	}

	PrintChar((char)rocketsOnline+'0');

	posRow = 20;
	posCol = 300;

	PrintChar('S');
	posCol=posCol+6;
	PrintChar('C');
	posCol=posCol+6;
	PrintChar('O');
	posCol=posCol+6;
	PrintChar('R');
	posCol=posCol+6;
	PrintChar('E');
	posCol=posCol+6;
	PrintChar(':');
	posCol=posCol+6;
	PrintChar(' ');
	posCol=posCol+6;

	//clear spaces
	PrintChar(' ');
	posCol=posCol+6;
	PrintChar(' ');
	posCol=posCol+6;
	PrintChar(' ');
	posCol=posCol+6;
	PrintChar(' ');
	posCol=posCol-18;

	PrintChar((char)score+'0');
	posCol=posCol+6;
	PrintChar('0');
	posCol=posCol+6;
	PrintChar('0');
	posCol=posCol+6;

	headerHasChanges = false;
}

void DrawCube1()
{
	switch(Cube1_FrameNum)
	{
	case 4:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(200+y)*stride + 700+x]= 0;
			}
		}
		Cube1_HasChanges = false;
		Cube1_Active = false;
		break;
	case 3:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(200+y)*stride + 700+x]= cube3[y][x];
			}
		}
		Cube1_FrameNum=4;
		Cube1_HasChanges = true;
		Cube1_Active = true;
		Xil_DCacheFlush();
		for(u32 d = 0; d<500000; d++){};	//delay
		break;
	case 2:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(200+y)*stride + 700+x]= cube2[y][x];
			}
		}
		Cube1_FrameNum=3;
		Cube1_HasChanges = true;
		Cube1_Active = true;
		break;
	default:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(200+y)*stride + 700+x]= cube[y][x];
			}
		}
		Cube1_Active = true;
		break;
	}
	for(u32 d = 0; d<50000; d++){};	//delay
}

void DrawCube2()
{
	switch(Cube2_FrameNum)
	{
	case 4:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(300+y)*stride + 700+x]= 0;
			}
		}
		Cube2_HasChanges = false;
		Cube2_Active = false;
		break;
	case 3:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(300+y)*stride + 700+x]= cube3[y][x];
			}
		}
		Cube2_FrameNum=4;
		Cube2_HasChanges = true;
		Cube2_Active = true;
		Xil_DCacheFlush();
		for(u32 d = 0; d<500000; d++){};	//delay
		break;
	case 2:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(300+y)*stride + 700+x]= cube2[y][x];
			}
		}
		Cube2_FrameNum=3;
		Cube2_HasChanges = true;
		Cube2_Active = true;
		break;
	default:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(300+y)*stride + 700+x]= cube[y][x];
			}
		}
		Cube2_Active = true;
		break;
	}
	for(u32 d = 0; d<50000; d++){};	//delay
}

void DrawCube3()
{
	switch(Cube3_FrameNum)
	{
	case 4:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(400+y)*stride + 700+x]= 0;
			}
		}
		Cube3_HasChanges = false;
		Cube3_Active = false;
		break;
	case 3:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(400+y)*stride + 700+x]= cube3[y][x];
			}
		}
		Cube3_FrameNum=4;
		Cube3_HasChanges = true;
		Cube3_Active = true;
		Xil_DCacheFlush();
		for(u32 d = 0; d<500000; d++){};	//delay
		break;
	case 2:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(400+y)*stride + 700+x]= cube2[y][x];
			}
		}
		Cube3_FrameNum=3;
		Cube3_HasChanges = true;
		Cube3_Active = true;
		break;
	default:
		for(u16 y = 0; y<32; y++)
		{
			for(u16 x = 0; x<32; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(400+y)*stride + 700+x]= cube[y][x];
			}
		}
		Cube3_Active = true;
		break;
	}
	for(u32 d = 0; d<50000; d++){};	//delay
}

//to do consolidate rocket procedures
void DrawPlayerOneRocket1()
{
	headerHasChanges = true;
	if(!PlayerOneRocket1_Active)
	{
		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket1_LocationY+y+12)*stride + PlayerOneRocket1_LocationX+x]= 0;
			}
		}
		PlayerOneRocket1_HasChanges = false;
		return;
	}
	if(PlayerOneRocket1_LocationX < 780)
	{
		PlayerOneRocket1_LocationX+=8;
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket1_LocationY+y+12)*stride + PlayerOneRocket1_LocationX+x]= rocket[y][x];
			}
		}

		for(u32 d = 0; d<100000; d++){};	//delay

		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket1_LocationY+y+12)*stride + PlayerOneRocket1_LocationX-8+x]= 0;
			}
		}
		CheckForCollissions();
	}
	else
	{
		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket1_LocationY+y+12)*stride + PlayerOneRocket1_LocationX+x]= 0;
			}
		}

		PlayerOneRocket1_Active = false;
		PlayerOneRocket1_HasChanges = false;
	}
}

void DrawPlayerOneRocket2()
{
	headerHasChanges = true;
	if(!PlayerOneRocket2_Active)
	{
		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket2_LocationY+y+12)*stride + PlayerOneRocket2_LocationX+x]= 0;
			}
		}
		PlayerOneRocket2_HasChanges = false;
		return;
	}
	if(PlayerOneRocket2_LocationX < 780)
	{
		PlayerOneRocket2_LocationX+=8;
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket2_LocationY+y+12)*stride + PlayerOneRocket2_LocationX+x]= rocket[y][x];
			}
		}

		for(u32 d = 0; d<100000; d++){};	//delay

		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket2_LocationY+y+12)*stride + PlayerOneRocket2_LocationX-8+x]= 0;
			}
		}
		CheckForCollissions();
	}
	else
	{
		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket2_LocationY+y+12)*stride + PlayerOneRocket2_LocationX+x]= 0;
			}
		}

		PlayerOneRocket2_Active = false;
		PlayerOneRocket2_HasChanges = false;
	}
}

void DrawPlayerOneRocket3()
{
	headerHasChanges = true;
	if(!PlayerOneRocket3_Active)
	{
		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket3_LocationY+y+12)*stride + PlayerOneRocket3_LocationX+x]= 0;
			}
		}
		PlayerOneRocket1_HasChanges = false;
		return;
	}
	if(PlayerOneRocket3_LocationX < 780)
	{
		PlayerOneRocket3_LocationX+=8;
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket3_LocationY+y+12)*stride + PlayerOneRocket3_LocationX+x]= rocket[y][x];
			}
		}

		for(u32 d = 0; d<100000; d++){};	//delay

		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket3_LocationY+y+12)*stride + PlayerOneRocket3_LocationX-8+x]= 0;
			}
		}
		CheckForCollissions();
	}
	else
	{
		//Clear previous rocket
		for(u16 y = 0; y<8; y++)
		{
			for(u16 x = 0; x<16; x++)
			{
				u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
				u32 stride = dispCtrl_Sprites.stride / 4;
				frame[(PlayerOneRocket3_LocationY+y+12)*stride + PlayerOneRocket3_LocationX+x]= 0;
			}
		}

		PlayerOneRocket3_Active = false;
		PlayerOneRocket3_HasChanges = false;
	}
}

void CheckForCollissions()
{
	bool newCollission = false;

	//rocket1
	if(Cube1_Active && PlayerOneRocket1_LocationX>Cube1_LocationX-16 && PlayerOneRocket1_LocationY>Cube1_LocationY-18
			&& PlayerOneRocket1_LocationY<Cube1_LocationY+20)
	{
		Cube1_FrameNum = 2;
		Cube1_HasChanges = true;
		PlayerOneRocket1_Active = false;
		newCollission = true;
	}

	if(Cube2_Active && PlayerOneRocket1_LocationX>Cube2_LocationX-16 && PlayerOneRocket1_LocationY>Cube2_LocationY-18
			&& PlayerOneRocket1_LocationY<Cube2_LocationY+20)
	{
		Cube2_FrameNum = 2;
		Cube2_HasChanges = true;
		PlayerOneRocket1_Active = false;
		newCollission = true;
	}

	if(Cube3_Active && PlayerOneRocket1_LocationX>Cube3_LocationX-16 && PlayerOneRocket1_LocationY>Cube3_LocationY-18
			&& PlayerOneRocket1_LocationY<Cube3_LocationY+20)
	{
		Cube3_FrameNum = 2;
		Cube3_HasChanges = true;
		PlayerOneRocket1_Active = false;
		newCollission = true;
	}

	//rocket2
	if(Cube1_Active && PlayerOneRocket2_LocationX>Cube1_LocationX-16 && PlayerOneRocket2_LocationY>Cube1_LocationY-18
			&& PlayerOneRocket2_LocationY<Cube1_LocationY+20)
	{
		Cube1_FrameNum = 2;
		Cube1_HasChanges = true;
		PlayerOneRocket2_Active = false;
		newCollission = true;
	}

	if(Cube2_Active && PlayerOneRocket2_LocationX>Cube2_LocationX-16 && PlayerOneRocket2_LocationY>Cube2_LocationY-18
			&& PlayerOneRocket2_LocationY<Cube2_LocationY+20)
	{
		Cube2_FrameNum = 2;
		Cube2_HasChanges = true;
		PlayerOneRocket2_Active = false;
		newCollission = true;
	}

	if(Cube3_Active && PlayerOneRocket2_LocationX>Cube3_LocationX-16 && PlayerOneRocket2_LocationY>Cube3_LocationY-18
			&& PlayerOneRocket2_LocationY<Cube3_LocationY+20)
	{
		Cube3_FrameNum = 2;
		Cube3_HasChanges = true;
		PlayerOneRocket2_Active = false;
		newCollission = true;
	}

	//rocket3
	if(Cube1_Active && PlayerOneRocket3_LocationX>Cube1_LocationX-16 && PlayerOneRocket3_LocationY>Cube1_LocationY-18
			&& PlayerOneRocket3_LocationY<Cube1_LocationY+20)
	{
		Cube1_FrameNum = 2;
		Cube1_HasChanges = true;
		PlayerOneRocket3_Active = false;
		newCollission = true;
	}

	if(Cube2_Active && PlayerOneRocket3_LocationX>Cube2_LocationX-16 && PlayerOneRocket3_LocationY>Cube2_LocationY-18
			&& PlayerOneRocket3_LocationY<Cube2_LocationY+20)
	{
		Cube2_FrameNum = 2;
		Cube2_HasChanges = true;
		PlayerOneRocket3_Active = false;
		newCollission = true;
	}

	if(Cube3_Active && PlayerOneRocket3_LocationX>Cube3_LocationX-16 && PlayerOneRocket3_LocationY>Cube3_LocationY-18
			&& PlayerOneRocket3_LocationY<Cube3_LocationY+20)
	{
		Cube3_FrameNum = 2;
		Cube3_HasChanges = true;
		PlayerOneRocket3_Active = false;
		newCollission = true;
	}

	if(newCollission)
	{
		score=score+1;
		xil_printf("\r\nCollision!\r\n");
		//trigger 6502 interrupt
		XGpio_DiscreteWrite(&Gpio0, 2, 0);	//use ch.2, bring signal low
		for(u32 d = 0; d<500000; d++){};	//delay
		XGpio_DiscreteWrite(&Gpio0, 2, 1);	//bring signal high
		headerHasChanges = true;
	}
}
