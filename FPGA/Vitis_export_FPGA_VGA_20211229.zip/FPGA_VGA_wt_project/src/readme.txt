To do:
-General clean-up, consolidation, addition of safety code, performance improvements
-Add additional font sizes to chars.c
