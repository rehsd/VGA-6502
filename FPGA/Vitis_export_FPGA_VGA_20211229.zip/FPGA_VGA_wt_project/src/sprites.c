#include <stdbool.h>
#include <xil_cache.h>
#include <xil_io.h>

#include "eight_bit_interface.h"
#include "globals.h"
#include "screen.h"
#include "sprites.h"
#include "zybo_vga/display_ctrl.h"


bool PlayerOneDrawn = false;


void DrawPlayerOne_old(u16 posX, u16 posY)
{
	PlayerOneSprite_Active = true;
	PlayerOneSprite_HasChanges = true;
	PlayerOneSprite_LocationX = posX;
	PlayerOneSprite_LocationY = posY;
}

void FireRocket(u16 posX, u16 posY)
{
	if(!PlayerOneRocket1_Active)
	{
		PlayerOneRocket1_Active = true;
		PlayerOneRocket1_HasChanges = true;
		PlayerOneRocket1_LocationX = posX+32;
		PlayerOneRocket1_LocationY = posY;
	}
	else if (!PlayerOneRocket2_Active)
	{
		PlayerOneRocket2_Active = true;
		PlayerOneRocket2_HasChanges = true;
		PlayerOneRocket2_LocationX = posX+32;
		PlayerOneRocket2_LocationY = posY;
	}
	else if (!PlayerOneRocket3_Active)
	{
		PlayerOneRocket3_Active = true;
		PlayerOneRocket3_HasChanges = true;
		PlayerOneRocket3_LocationX = posX+32;
		PlayerOneRocket3_LocationY = posY;
	}
	else //out of rockets
	{

	}
}

void ClearPlayerOne()
{
//	for(u16 y = 0; y<32; y++)
//	{
//		for(u16 x = 0; x<32; x++)
//		{
//			u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
//			u32 stride = dispCtrl_Sprites.stride / 4;
//			frame[(PlayerOneLastY+y)*stride + PlayerOneLastX+x]= 0;
//		}
//	}

//	u32 *frame = dispCtrl_Sprites.framePtr[dispCtrl.curFrame];
//	u32 stride = dispCtrl_Sprites.stride / 4;
//	memset(frame, 0xFF, 32);
//	Xil_DCacheFlush();
}

void SpritesSetDisplay(DisplayCtrl *dispPtr)
{
	dispCtrl_Sprites = *dispPtr;
}
