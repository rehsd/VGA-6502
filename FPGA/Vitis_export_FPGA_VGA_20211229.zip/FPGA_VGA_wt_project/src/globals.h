//extern  bool 	PlayerOneSprite_HasChanges;//	= false;
#include <xgpio.h>
#include <xil_io.h>

extern 	XGpio Gpio0;

//change these to structs
extern 	u16 	posCol;
extern 	u16 	posRow;

extern  bool	PlayerOneSprite_Active;
extern  bool 	PlayerOneSprite_HasChanges;
extern  u8		PlayerOneSprite_FrameNum;
extern  u16		PlayerOneSprite_LocationY;
extern  u16		PlayerOneSprite_LocationX;

extern  bool 	PlayerOneRocket1_Active;
extern  bool	PlayerOneRocket1_HasChanges;
extern  u8 		PlayerOneRocket1_FrameNum;
extern  u16 	PlayerOneRocket1_LocationY;
extern  u16 	PlayerOneRocket1_LocationX;

extern  bool 	PlayerOneRocket2_Active;
extern  bool	PlayerOneRocket2_HasChanges;
extern  u8 		PlayerOneRocket2_FrameNum;
extern  u16 	PlayerOneRocket2_LocationY;
extern  u16 	PlayerOneRocket2_LocationX;

extern  bool 	PlayerOneRocket3_Active;
extern  bool	PlayerOneRocket3_HasChanges;
extern  u8 		PlayerOneRocket3_FrameNum;
extern  u16 	PlayerOneRocket3_LocationY;
extern  u16 	PlayerOneRocket3_LocationX;

extern	bool	Cube1_Active;
extern 	bool	Cube1_HasChanges;
extern	u8		Cube1_FrameNum;
extern 	u16		Cube1_LocationX;
extern 	u16		Cube1_LocationY;

extern	bool	Cube2_Active;
extern 	bool	Cube2_HasChanges;
extern	u8		Cube2_FrameNum;
extern 	u16		Cube2_LocationX;
extern 	u16		Cube2_LocationY;

extern	bool	Cube3_Active;
extern 	bool	Cube3_HasChanges;
extern	u8		Cube3_FrameNum;
extern 	u16		Cube3_LocationX;
extern 	u16		Cube3_LocationY;
