#ifndef SCREEN_H_
#define SCREEN_H_

#include <stdbool.h>
//#include "globals.h"

static DisplayCtrl dispCtrl_Sprites; // Display driver struct

void SetDisplay_forScreen(DisplayCtrl *dispPtr);
void DrawScreen();
void DrawPlayerOne();
void DrawPlayerOneRocket1();
void GameSetup();
void DrawHeader();

#endif
