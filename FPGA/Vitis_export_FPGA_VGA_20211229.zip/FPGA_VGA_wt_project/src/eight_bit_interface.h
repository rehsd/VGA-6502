#ifndef EIGHT_BIT_INTERFACE_H_
#define EIGHT_BIT_INTERFACE_H_

#define EBI_CLEAR_SCREEN 			0
#define EBI_PRINT_CHAR				1
#define EBI_MOUSEMOVE_X_MSB			2
#define EBI_MOUSEMOVE_X_LSB			3
#define EBI_MOUSEMOVE_Y_MSB			4
#define EBI_MOUSEMOVE_Y_LSB			5
#define EBI_MOUSEDOWN_LEFT_X_MSB	6
#define EBI_MOUSEDOWN_LEFT_X_LSB	7
#define EBI_MOUSEDOWN_LEFT_Y_MSB	8
#define EBI_MOUSEDOWN_LEFT_Y_LSB	9
#define EBI_MOUSEDOWN_RIGHT			10
#define EBI_MOUSEDOWN_MIDDLE		11
#define EBI_MOUSEMOVE_UP			12
#define EBI_MOUSEMOVE_RIGHT_UP   	13
#define EBI_MOUSEMOVE_RIGHT			14
#define EBI_MOUSEMOVE_RIGHT_DOWN	15
#define EBI_MOUSEMOVE_DOWN			16
#define EBI_MOUSEMOVE_LEFT_DOWN		17
#define EBI_MOUSEMOVE_LEFT			18
#define EBI_MOUSEMOVE_LEFT_UP		19
#define EBI_MOUSEDOWN_LEFT_ONMOVE	20
#define EBI_PLAYER_ONE_MOVE_RIGHT	21
#define EBI_PLAYER_ONE_MOVE_DOWN	22
#define EBI_PLAYER_ONE_MOVE_LEFT	23
#define EBI_PLAYER_ONE_MOVE_UP		24
#define EBI_PLAYER_ONE_FIRE_ROCKET	25
#define EBI_PLAYER_ONE_MOVE_FIRE	26


#include "xil_types.h"
#include "zybo_vga/display_ctrl.h"
#include "stdbool.h"

void ProcessPacket(u16 packet);
void ClearScreen();
void SetDisplay(DisplayCtrl *dispPtr);
void PrintChar(char c);
void DrawMousePointer(u8 cmd, u8 data);
void MouseDown(u8 cmd, u8 data);
void DrawRectangle();
void PlayerOneMoveRight();
void PlayerOneMoveFire(u8 moveFireData);



//static u16 posCol;
//static u16 posRow;
static DisplayCtrl dispCtrl; // Display driver struct
static u16 mouseX;
static u16 mouseY;
static bool mouseDrawingOn;

static u16 mouseXprev;
static u16 mouseYprev;
static int currentColor = 0x00FFFFFF;
static u8 mouseMoveAmount = 5;

static bool drawRectangleOn;
static u16 posRectangleStartX;
static u16 posRectangleStartY;


#endif
